// src/components/NFTGrid.js
import React, { useMemo } from 'react';
import PropTypes from 'prop-types';

const NFTGrid = ({
  burnableNFTs = [],
  selectedNFT,
  onNFTClick,
  onAssignNFT,
  onBurnNFT,            // ✅ NEW: burn handler from parent
  nftSlots = [],
  slots = [],           // ✅ NEW: equipped incinerator slots from parent
  loading = false,
}) => {
  const isNFTAssigned = (assetId) =>
    (nftSlots || []).some((slot) => String(slot?.asset_id) === String(assetId));

  const getAssignedIndex = (assetId) =>
    (nftSlots || []).findIndex((slot) => String(slot?.asset_id) === String(assetId));

  const resolveIpfsUrl = (val) => {
    if (!val) return 'default-placeholder.png';
    if (typeof val === 'string') {
      if (val.startsWith('http://') || val.startsWith('https://')) return val;
      if (val.startsWith('ipfs://')) return `https://ipfs.io/ipfs/${val.replace('ipfs://', '')}`;
    }
    return `https://ipfs.io/ipfs/${val}`;
  };

  const canIncineratorBurn = (inc, nft) => {
    if (!inc || !nft) return false;
    const requiredFuel = parseFloat(nft.trash_fee || 0);
    const requiredEnergy = parseFloat(nft.energy_cost || 0);
    const availableFuel = parseFloat(inc.fuel || 0);
    const availableEnergy = parseFloat(inc.energy || 0);
    return availableFuel >= requiredFuel && availableEnergy >= requiredEnergy && availableEnergy > 0;
  };

  const pickFirstAvailableIncinerator = (nft) => {
    for (const inc of (slots || [])) {
      if (canIncineratorBurn(inc, nft)) return inc;
    }
    return null;
  };

  const handleAssign = (nft) => {
    if (isNFTAssigned(nft.asset_id)) {
      alert('This NFT is already assigned to a slot.');
      return;
    }
    const emptySlotIndex = (nftSlots || []).findIndex((slot) => slot === null);
    if (emptySlotIndex !== -1) {
      onAssignNFT(nft, emptySlotIndex);
    } else {
      alert('All NFT slots are full.');
    }
  };

  return (
    <div className="nft-grid">
      {loading ? (
        <p className="loading-message">🔄 Fetching burnable NFTs...</p>
      ) : burnableNFTs.length === 0 ? (
        <p className="no-nfts-message">You don't have any approved NFTs available for burning.</p>
      ) : (
        burnableNFTs.map((nft) => {
          const assigned = isNFTAssigned(nft.asset_id);
          const assignedIndex = assigned ? getAssignedIndex(nft.asset_id) : -1;
          const incToUse = assigned ? pickFirstAvailableIncinerator(nft) : null;
          const canBurn = assigned && !!incToUse;

          return (
            <div
              key={nft.asset_id}
              className={`nft-card ${selectedNFT?.asset_id === nft.asset_id ? 'selected' : ''}`}
              onClick={() => onNFTClick(nft)}
            >
              <img
                src={resolveIpfsUrl(nft.img)}
                alt={nft.template_name || nft.name || 'Unnamed NFT'}
                className="nft-image"
                loading="lazy"
              />

              <div className="nft-info">
                <p className="nft-name">{nft.template_name || nft.name || 'Unnamed NFT'}</p>

                {/* Meta row */}
                <div className="nft-meta">
                  <span className="mint">Mint #{nft.template_mint ?? '—'}</span>
                  <span className={`rule-badge ${nft.rule_type}`}>
                    {nft.rule_type === 'schema' ? 'Schema Rule' : 'Template Rule'}
                  </span>
                </div>

                <div className="nft-economics">
                  <p>
                    <span className="label">Reward</span>
                    <span className="value">{nft.cinder_reward}</span>
                  </p>
                  <p>
                    <span className="label">Fee</span>
                    <span className="value">{nft.trash_fee}</span>
                  </p>
                </div>

                {nft.cap_total != null && nft.cap_remaining != null && (
                  <div className="nft-cap">
                    Cap: <strong>{nft.cap_remaining}</strong> / {nft.cap_total}
                  </div>
                )}

                <p className="nft-asset-id">Asset ID: {nft.asset_id}</p>

                {/* ✅ Primary action area */}
                {!assigned ? (
                  <button
                    className="assign-button"
                    onClick={(e) => {
                      e.stopPropagation();
                      handleAssign(nft);
                    }}
                  >
                    Assign to Slot
                  </button>
                ) : (
                  <>
                    {/* ✅ Burn button on card (auto picks first incinerator) */}
                    <button
                      className={`burn-button ${canBurn ? '' : 'disabled'}`}
                      disabled={!canBurn}
                      onClick={(e) => {
                        e.stopPropagation();
                        if (!onBurnNFT) return;
                        if (assignedIndex < 0) return;
                        if (!incToUse) {
                          alert('No equipped incinerator has enough fuel/energy. Load Fuel/Energy or equip another.');
                          return;
                        }
                        onBurnNFT(assignedIndex); // 🔥 burn uses the slot index (keeps your existing burn flow)
                      }}
                      title={
                        canBurn
                          ? `Burn using Incinerator ${incToUse?.asset_id}`
                          : 'No equipped incinerator has enough fuel/energy'
                      }
                    >
                      {canBurn ? 'Burn NFT' : 'Not enough fuel/energy'}
                    </button>

                    {/* Keep the assigned label (optional) */}
                    <button className="assign-button disabled" disabled>
                      Assigned
                    </button>
                  </>
                )}
              </div>
            </div>
          );
        })
      )}
    </div>
  );
};

NFTGrid.propTypes = {
  burnableNFTs: PropTypes.array,
  selectedNFT: PropTypes.object,
  onNFTClick: PropTypes.func.isRequired,
  onAssignNFT: PropTypes.func.isRequired,
  onBurnNFT: PropTypes.func,     // ✅ NEW
  nftSlots: PropTypes.array,
  slots: PropTypes.array,        // ✅ NEW
  loading: PropTypes.bool,
};

export default NFTGrid;

