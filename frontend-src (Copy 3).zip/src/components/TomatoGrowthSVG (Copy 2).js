// src/components/TomatoGrowthSVG.js
import React, { useId, useMemo } from "react";

export default function TomatoGrowthSVG({
  tick = 0,
  tickGoal = 21,
  weather = "sunny",
  rarity = "common",
  className = "",
  cinderTheme = true,
}) {
  const rid = useId().replace(/:/g, "");
  const ids = useMemo(() => {
    const p = `tgs-${rid}`;
    return {
      sky: `${p}-sky`,
      soil: `${p}-soil`,
      sun: `${p}-sun`,
      glow: `${p}-glow`,

      // realism
      stemGrad: `${p}-stemGrad`,
      stemHi: `${p}-stemHi`,
      leafGrad: `${p}-leafGrad`,
      leafHi: `${p}-leafHi`,
      leafShadow: `${p}-leafShadow`,

      // cinder
      cinderCore: `${p}-cinderCore`,
      steamBlur: `${p}-steamBlur`,

      // ✅ tomatoes (realistic volume + spec)
      tomatoGrad: `${p}-tomatoGrad`,
      tomatoSpec: `${p}-tomatoSpec`,
    };
  }, [rid]);

  // Safety + progress 0..1 (KEEP)
  const safeGoal = Math.max(1, tickGoal || 1);
  const clampedTick = Math.max(0, Math.min(tick || 0, safeGoal));
  const progress = clampedTick / safeGoal;

  // Map progress → stage (KEEP)
  let stage = { key: "seed", label: "Germination" };
  if (progress >= 0.15 && progress < 0.35) stage = { key: "seedling", label: "Seedling" };
  else if (progress >= 0.35 && progress < 0.6) stage = { key: "foliage", label: "Vegetative Growth" };
  else if (progress >= 0.6 && progress < 0.8) stage = { key: "flower", label: "Flowering" };
  else if (progress >= 0.8) stage = { key: "fruit", label: "Fruit & Ripening" };

  const rarityGlowMap = { common: 0.0, rare: 0.3, epic: 0.55, legendary: 0.8 };
  const rarityGlow = rarityGlowMap[rarity] ?? 0.0;

  const isCloudy = weather === "cloudy";
  const isWindy = weather === "windy";
  const isStormy = weather === "stormy";

  // Plant height (stem top Y) (KEEP)
  const stemTopY = 78 - 48 * Math.pow(progress, 0.7);

  // Branch levels (KEEP)
  const branchLevels = [stemTopY + 20, stemTopY + 10, stemTopY].map((y) => Math.min(74, y));

  const leafDensity =
    stage.key === "seed" ? 0 :
    stage.key === "seedling" ? 0.4 :
    stage.key === "foliage" ? 1 :
    stage.key === "flower" ? 1.1 : 1.2;

  const totalLeaves = Math.round(18 * leafDensity);

  const fruitRipeness = Math.max(0, progress - 0.8) / 0.2;
  const tomatoColor = lerpColor("#4CAF50", "#FF3D00", fruitRipeness);

  const clouds = [
    { x: 18, y: 20, w: 22, h: 10 },
    { x: 65, y: 16, w: 26, h: 12 },
  ];

  const swayDur = isWindy ? "1.2s" : "3s";
  const cloudOpacity = (isCloudy || isStormy) ? 0.7 : 0.35;

  // --------------------------
  // CINDER intensity
  // --------------------------
  const isCinder = !!cinderTheme;
  const hot = isCinder ? (0.18 + 0.62 * progress) : 0;
  const coreOpacity = isCinder ? Math.min(0.92, 0.22 + hot + 0.18 * rarityGlow) : 0;

  // ✅ Steam: move origin ABOVE soil line so it always shows
  const steamCount = isCinder ? Math.round(5 + 9 * progress + 6 * rarityGlow) : 0;
  const steamOpacity = isCinder ? Math.min(0.65, 0.22 + 0.38 * progress + 0.12 * rarityGlow) : 0;
  const steamBaseY = 78.5; // ✅ soil starts at y=80, so start steam above it

  // deterministic RNG
  const seed = useMemo(() => hashStringToInt(rid), [rid]);
  const rng = useMemo(() => mulberry32(seed), [seed]);

  const steamLanes = useMemo(() => {
    const lanes = [];
    for (let i = 0; i < steamCount; i++) {
      const x = 20 + rng() * 60;               // 20..80
      const drift = (rng() * 2 - 1) * 12;      // -12..12
      const height = 18 + rng() * 24;          // 18..42
      const width = 7 + rng() * 10;            // 7..17
      const dur = 1.8 + rng() * 2.1;           // 1.8..3.9
      const delay = rng() * 1.3;               // 0..1.3
      const wobble = 2 + rng() * 5;            // 2..7
      const puff = 0.9 + rng() * 0.9;          // 0.9..1.8
      lanes.push({ x, drift, height, width, dur, delay, wobble, puff });
    }
    return lanes;
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [steamCount, seed]);

  const plantFilter = rarityGlow > 0 ? `url(#${ids.glow})` : undefined;

  return (
    <div className={"tomato-growth-wrapper " + className}>
      <svg
        viewBox="0 0 100 100"
        className="tomato-growth-svg"
        role="img"
        aria-label={"Tomato growth — " + stage.label}
      >
        <defs>
          {/* Sky */}
          <linearGradient id={ids.sky} x1="0" y1="0" x2="0" y2="1">
            <stop
              offset="0%"
              stopColor={
                isStormy ? "#3a4763" :
                isCloudy ? (isCinder ? "#9bb6ff" : "#7fb0ff") :
                (isCinder ? "#a8dcff" : "#87CEEB")
              }
            />
            <stop offset="100%" stopColor={isStormy ? "#1d2433" : (isCinder ? "#f4e6ff" : "#cfe9ff")} />
          </linearGradient>

          {/* Soil */}
          <linearGradient id={ids.soil} x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor={isCinder ? "#7b4a3e" : "#6d4c41"} />
            <stop offset="100%" stopColor={isCinder ? "#311a16" : "#4e342e"} />
          </linearGradient>

          <radialGradient id={ids.sun} cx="80%" cy="15%" r="22%">
            <stop offset="0%" stopColor="#fff8e1" stopOpacity="0.95" />
            <stop offset="70%" stopColor="#ffeb3b" stopOpacity="0.28" />
            <stop offset="100%" stopColor="#ffeb3b" stopOpacity="0.06" />
          </radialGradient>

          {/* Stem gradient + highlight */}
          <linearGradient id={ids.stemGrad} x1="0" y1="0" x2="1" y2="0">
            <stop offset="0%" stopColor="#124a18" />
            <stop offset="50%" stopColor="#2e7d32" />
            <stop offset="100%" stopColor="#1f6a28" />
          </linearGradient>

          <linearGradient id={ids.stemHi} x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor="#eaffef" stopOpacity="0.28" />
            <stop offset="100%" stopColor="#eaffef" stopOpacity="0.00" />
          </linearGradient>

          {/* Leaf gradient + highlight */}
          <linearGradient id={ids.leafGrad} x1="0" y1="0" x2="1" y2="1">
            <stop offset="0%" stopColor="#49b053" />
            <stop offset="55%" stopColor="#2e7d32" />
            <stop offset="100%" stopColor="#1b5e20" />
          </linearGradient>

          <linearGradient id={ids.leafHi} x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor="#ffffff" stopOpacity="0.22" />
            <stop offset="100%" stopColor="#ffffff" stopOpacity="0.00" />
          </linearGradient>

          <filter id={ids.leafShadow} x="-40%" y="-40%" width="180%" height="180%">
            <feDropShadow dx="0" dy="0.6" stdDeviation="0.6" floodColor="#000" floodOpacity="0.22" />
          </filter>

          {/* CINDER core */}
          <radialGradient id={ids.cinderCore} cx="50%" cy="50%" r="60%">
            <stop offset="0%" stopColor="#ffd37a" stopOpacity="0.95" />
            <stop offset="35%" stopColor="#ff7a18" stopOpacity="0.65" />
            <stop offset="70%" stopColor="#ff2a2a" stopOpacity="0.22" />
            <stop offset="100%" stopColor="#000" stopOpacity="0" />
          </radialGradient>

          <filter id={ids.steamBlur} x="-70%" y="-70%" width="240%" height="240%">
            <feGaussianBlur stdDeviation="0.85" />
          </filter>

          {/* ✅ Tomato gradients (more realistic volume) */}
          <radialGradient id={ids.tomatoGrad} cx="35%" cy="30%" r="70%">
            <stop offset="0%" stopColor="#ffb199" stopOpacity="0.95" />
            <stop offset="35%" stopColor="#ff3d00" stopOpacity="0.95" />
            <stop offset="80%" stopColor="#b31212" stopOpacity="1" />
            <stop offset="100%" stopColor="#520707" stopOpacity="1" />
          </radialGradient>

          <radialGradient id={ids.tomatoSpec} cx="25%" cy="20%" r="55%">
            <stop offset="0%" stopColor="#ffffff" stopOpacity="0.55" />
            <stop offset="35%" stopColor="#ffffff" stopOpacity="0.18" />
            <stop offset="100%" stopColor="#ffffff" stopOpacity="0.00" />
          </radialGradient>

          {rarityGlow > 0 ? (
            <filter id={ids.glow} x="-50%" y="-50%" width="200%" height="200%">
              <feGaussianBlur in="SourceGraphic" stdDeviation={Math.max(0.8, rarityGlow * 2.6)} result="blur" />
              <feMerge>
                <feMergeNode in="blur" />
                <feMergeNode in="SourceGraphic" />
              </feMerge>
            </filter>
          ) : null}
        </defs>

        {/* Sky */}
        <rect x="0" y="0" width="100" height="100" fill={`url(#${ids.sky})`} />

        {/* Sun */}
        {!isStormy && <circle cx="82" cy="13" r="9" fill={`url(#${ids.sun})`} />}

        {/* Clouds */}
        {clouds.map((c, i) => (
          <g key={i} opacity={cloudOpacity}>
            <g>
              <animateTransform
                attributeName="transform"
                type="translate"
                dur={i === 0 ? "28s" : "34s"}
                repeatCount="indefinite"
                values="-40 0; 140 0"
                begin={i === 0 ? "0s" : "3s"}
              />
              <ellipse cx={c.x} cy={c.y} rx={c.w / 2} ry={c.h / 2} fill="#fff" />
              <ellipse cx={c.x + 6} cy={c.y - 3} rx={c.w / 3} ry={c.h / 2.5} fill="#fff" />
              <ellipse cx={c.x - 6} cy={c.y - 2} rx={c.w / 3} ry={c.h / 3} fill="#fff" />
            </g>
          </g>
        ))}

        {/* Soil */}
        <rect x="0" y="80" width="100" height="20" fill={`url(#${ids.soil})`} />

        {/* CINDER core under soil */}
        {isCinder && (
          <g opacity={coreOpacity}>
            <circle cx="50" cy="86" r="18" fill={`url(#${ids.cinderCore})`}>
              <animate
                attributeName="opacity"
                values={`${coreOpacity};${Math.max(0.12, coreOpacity - 0.2)};${coreOpacity}`}
                dur="2.4s"
                repeatCount="indefinite"
              />
            </circle>
          </g>
        )}

        {/* ✅ Steam above soil (always visible now) */}
        {isCinder && steamCount > 0 && (
          <g opacity={steamOpacity} filter={`url(#${ids.steamBlur})`}>
            {steamLanes.map((s, i) => {
              const x0 = s.x;
              const y0 = steamBaseY + ((i % 3) * 0.9);
              const x1 = x0 + s.drift * 0.35;
              const y1 = y0 - s.height * 0.45;
              const x2 = x0 + s.drift;
              const y2 = y0 - s.height;

              const path = `M ${x0} ${y0}
                            C ${x0 + s.wobble} ${y0 - 6},
                              ${x1 - s.wobble} ${y1 + 6},
                              ${x1} ${y1}
                            S ${x2 + s.wobble} ${y2 + 6},
                              ${x2} ${y2}`;

              return (
                <g key={i}>
                  <path
                    d={path}
                    fill="none"
                    stroke="#ffd7b2"
                    strokeOpacity="0.62"
                    strokeWidth={Math.max(1.0, s.width * 0.085)}
                    strokeLinecap="round"
                  >
                    <animate
                      attributeName="stroke-opacity"
                      dur={`${s.dur}s`}
                      repeatCount="indefinite"
                      values="0;0.72;0"
                      begin={`${s.delay}s`}
                    />
                  </path>

                  <path
                    d={path}
                    fill="none"
                    stroke="#ff7a18"
                    strokeOpacity="0.18"
                    strokeWidth={Math.max(1.9, s.width * 0.14)}
                    strokeLinecap="round"
                  >
                    <animate
                      attributeName="stroke-opacity"
                      dur={`${s.dur}s`}
                      repeatCount="indefinite"
                      values="0;0.26;0"
                      begin={`${s.delay}s`}
                    />
                  </path>

                  <animateTransform
                    attributeName="transform"
                    type="translate"
                    dur={`${s.dur}s`}
                    repeatCount="indefinite"
                    values={`0 0; 0 ${-s.height * 0.18}`}
                    begin={`${s.delay}s`}
                  />
                  <animateTransform
                    attributeName="transform"
                    additive="sum"
                    type="scale"
                    dur={`${s.dur}s`}
                    repeatCount="indefinite"
                    values={`1; ${1 + s.puff * 0.06}; 1`}
                    begin={`${s.delay}s`}
                  />
                </g>
              );
            })}
          </g>
        )}

        {/* Seed */}
        {stage.key === "seed" && (
          <g filter={plantFilter}>
            <ellipse cx="50" cy="80" rx="2.2" ry="1.6" fill="#8D6E63" />
            <path d="M49.7,79.3 Q50,78.6 50.3,79.3" stroke="#5D4037" strokeWidth="0.25" fill="none" />
          </g>
        )}

        {/* Plant */}
        {stage.key !== "seed" && (
          <g filter={plantFilter}>
            <g>
              <animateTransform
                attributeName="transform"
                type="rotate"
                dur={swayDur}
                repeatCount="indefinite"
                values={`-0.8 50 80; 0.8 50 80; -0.8 50 80`}
              />

              {/* ✅ STEM FIX: always-visible outline first */}
              <path
                d={`M50 78 L50 ${stemTopY}`}
                stroke="#0b2f10"
                strokeWidth="3.4"
                strokeLinecap="round"
                opacity="0.55"
              />
              {/* gradient stem on top */}
              <path
                d={`M50 78 L50 ${stemTopY}`}
                stroke={`url(#${ids.stemGrad})`}
                strokeWidth="2.7"
                strokeLinecap="round"
              />
              {/* highlight */}
              <path
                d={`M49.35 78 L49.35 ${stemTopY}`}
                stroke={`url(#${ids.stemHi})`}
                strokeWidth="0.95"
                strokeLinecap="round"
                opacity="0.65"
              />

              {/* Branches */}
              {branchLevels.map((y, idx) => {
                const visibleFactor =
                  stage.key === "seedling" ? (idx === 0 ? 0.75 : 0.25) : 1;
                const length = 11 + idx * 2;
                const thickness = 1.55;
                const alpha = 0.7 + 0.1 * (2 - idx);

                return (
                  <g key={idx} opacity={alpha * visibleFactor}>
                    {/* outline */}
                    <path
                      d={`M50 ${y} Q ${50 - length / 2} ${y - 2}, ${50 - length} ${y}`}
                      stroke="#0b2f10"
                      strokeWidth={thickness + 0.9}
                      fill="none"
                      strokeLinecap="round"
                      opacity="0.35"
                    />
                    <path
                      d={`M50 ${y} Q ${50 + length / 2} ${y - 2}, ${50 + length} ${y}`}
                      stroke="#0b2f10"
                      strokeWidth={thickness + 0.9}
                      fill="none"
                      strokeLinecap="round"
                      opacity="0.35"
                    />
                    {/* colored */}
                    <path
                      d={`M50 ${y} Q ${50 - length / 2} ${y - 2}, ${50 - length} ${y}`}
                      stroke={`url(#${ids.stemGrad})`}
                      strokeWidth={thickness}
                      fill="none"
                      strokeLinecap="round"
                    />
                    <path
                      d={`M50 ${y} Q ${50 + length / 2} ${y - 2}, ${50 + length} ${y}`}
                      stroke={`url(#${ids.stemGrad})`}
                      strokeWidth={thickness}
                      fill="none"
                      strokeLinecap="round"
                    />
                  </g>
                );
              })}

              {/* Leaves */}
              {Array.from({ length: totalLeaves }).map((_, i) => {
                const levelIndex = i % branchLevels.length;
                const baseY = branchLevels[levelIndex];
                const side = i % 2 === 0 ? -1 : 1;

                const offsetX = 8 + (i % 3) * 2;
                const x = 50 + side * offsetX;
                const y = baseY + (i % 3) * 1.2 - 4;

                const scale = 0.86 + ((i * 7) % 5) * 0.05;
                const rot = side * (18 + ((i * 11) % 7));

                return (
                  <g
                    key={i}
                    transform={`translate(${x} ${y}) rotate(${rot}) scale(${scale})`}
                    opacity={0.95}
                    filter={`url(#${ids.leafShadow})`}
                  >
                    <path
                      d="M0 0
                         C 5 -2, 8 -1, 9 1
                         C 7 1.5, 6 3, 5.5 4.5
                         C 3 4.5, 1.5 5, 0 4.8
                         C -1.5 5, -3 4.5, -4.8 3.8
                         C -4.2 2, -3.5 1, -2.5 0.3
                         C -1.2 -0.5, 0 -0.4, 0 0 Z"
                      fill={`url(#${ids.leafGrad})`}
                      stroke="#144d19"
                      strokeWidth="0.28"
                    />
                    <path
                      d="M-1 -0.3
                         C 2 -2.2, 6 -1.8, 7 -0.2
                         C 5 0.2, 3 1.1, 1.3 2.4
                         C 0.2 1.6, -0.3 0.8, -1 -0.3 Z"
                      fill={`url(#${ids.leafHi})`}
                      opacity="0.7"
                    />
                    <path d="M-0.8 0.2 L 5.2 4.2" stroke="#0f3b13" strokeWidth="0.28" opacity="0.65" />
                  </g>
                );
              })}

              {/* Flowers */}
              {(stage.key === "flower" || stage.key === "fruit") &&
                branchLevels.map((y, idx) => {
                  const cx = 50 + (idx - 1) * 6;
                  const cy = y - 4;
                  const op = stage.key === "flower" ? 0.9 : 0.4;
                  return (
                    <g key={idx} opacity={op}>
                      {Array.from({ length: 3 }).map((_, j) => {
                        const angle = (j * 120 * Math.PI) / 180;
                        const fx = cx + Math.cos(angle) * 3;
                        const fy = cy + Math.sin(angle) * 3;
                        return (
                          <g key={j}>
                            <circle cx={fx} cy={fy} r="1.4" fill="#FFD54F" stroke="#F9A825" strokeWidth="0.3" />
                            <circle cx={fx} cy={fy} r="0.5" fill="#F57F17" />
                          </g>
                        );
                      })}
                    </g>
                  );
                })}

              {/* ✅ Fruit (enhanced tomatoes) */}
              {stage.key === "fruit" &&
                branchLevels.map((y, idx) => {
                  const cx = 50 + (idx - 1) * 7;
                  const cy = y + 2;
                  const fruitsHere = idx === 0 ? 2 : 3;

                  return (
                    <g key={idx}>
                      {/* hanging stem */}
                      <path
                        d={`M${cx} ${cy - 2} Q ${cx} ${cy}, ${cx} ${cy + 4}`}
                        stroke="#2e7d32"
                        strokeWidth="0.8"
                        fill="none"
                        opacity="0.95"
                      />

                      {Array.from({ length: fruitsHere }).map((_, j) => {
                        const spread = 5;
                        const fx = cx + (j - (fruitsHere - 1) / 2) * spread;
                        const fy = cy + 5 + (j % 2) * 1.6;

                        // slightly varied tomato size/shape
                        const r = 2.9 + ((j + idx) % 2) * 0.75;
                        const rx = r * (1.05 + ((j % 3) * 0.03));
                        const ry = r * (0.95 + ((idx % 2) * 0.04));

                        // deterministic pores
                        const poreCount = 6 + ((idx + j) % 3);
                        const pores = Array.from({ length: poreCount }).map((__, pi) => {
                          const a = ((pi * 137) % 360) * (Math.PI / 180);
                          const pr = r * (0.25 + ((pi * 17) % 35) / 100);
                          return {
                            x: fx + Math.cos(a) * pr * 0.9,
                            y: fy + Math.sin(a) * pr * 0.55,
                            rr: 0.12 + ((pi + j) % 3) * 0.06,
                            op: 0.10 + ((pi + idx) % 4) * 0.03,
                          };
                        });

                        return (
                          <g key={j}>
                            {/* soft shadow */}
                            <ellipse
                              cx={fx + r * 0.25}
                              cy={fy + r * 0.55}
                              rx={rx * 0.85}
                              ry={ry * 0.45}
                              fill="#000"
                              opacity="0.10"
                            />

                            {/* tomato body (use gradient when ripe enough) */}
                            <ellipse
                              cx={fx}
                              cy={fy}
                              rx={rx}
                              ry={ry}
                              fill={fruitRipeness >= 0.15 ? `url(#${ids.tomatoGrad})` : tomatoColor}
                              stroke="#5f0a0a"
                              strokeWidth="0.45"
                            />

                            {/* subtle rim shading */}
                            <ellipse
                              cx={fx + rx * 0.15}
                              cy={fy + ry * 0.15}
                              rx={rx * 0.95}
                              ry={ry * 0.8}
                              fill="#000"
                              opacity="0.06"
                            />

                            {/* spec highlight */}
                            <ellipse
                              cx={fx - rx * 0.35}
                              cy={fy - ry * 0.35}
                              rx={rx * 0.7}
                              ry={ry * 0.55}
                              fill={`url(#${ids.tomatoSpec})`}
                              opacity="0.9"
                            />

                            {/* pores */}
                            {pores.map((p, k) => (
                              <circle key={k} cx={p.x} cy={p.y} r={p.rr} fill="#fff" opacity={p.op} />
                            ))}

                            {/* calyx */}
                            <g transform={`translate(${fx} ${fy - ry * 0.95})`}>
                              <path
                                d="M0 -1.4 Q 0.3 -2.4 0 -3.1 Q -0.3 -2.4 0 -1.4 Z"
                                fill="#1b5e20"
                                opacity="0.95"
                              />
                              {Array.from({ length: 5 }).map((__, si) => {
                                const ang = (si * 72) * (Math.PI / 180);
                                const x1 = Math.cos(ang) * (r * 0.25);
                                const y1 = Math.sin(ang) * (r * 0.18);
                                const x2 = Math.cos(ang) * (r * 0.95);
                                const y2 = Math.sin(ang) * (r * 0.65);
                                return (
                                  <path
                                    key={si}
                                    d={`M 0 0 Q ${x1.toFixed(2)} ${y1.toFixed(2)} ${x2.toFixed(2)} ${y2.toFixed(2)}`}
                                    stroke="#1b5e20"
                                    strokeWidth="0.9"
                                    strokeLinecap="round"
                                    opacity="0.95"
                                  />
                                );
                              })}
                              <circle r={r * 0.32} fill="#2e7d32" opacity="0.95" />
                              <circle r={r * 0.22} fill="#1b5e20" opacity="0.75" />
                            </g>
                          </g>
                        );
                      })}
                    </g>
                  );
                })}
            </g>
          </g>
        )}

        {/* Stage label (KEEP) */}
        <g>
          <rect x="6" y="86" width="88" height="8" rx="2" fill="#fff" opacity="0.6" />
          <text x="50" y="91.5" textAnchor="middle" fontSize="3.6" fill="#1b3a2f">
            {stage.label}
          </text>
        </g>

        {/* Progress (KEEP) */}
        <g>
          <rect x="6" y="96" width="88" height="2" rx="1" fill="#e0e0e0" />
          <rect x="6" y="96" width={88 * progress} height="2" rx="1" fill="#43A047" />
        </g>
      </svg>
    </div>
  );
}

// ----------------------------
// Helpers
// ----------------------------
function lerpColor(a, b, t) {
  const ca = hexToRgb(a);
  const cb = hexToRgb(b);
  const tt = Math.max(0, Math.min(1, t));
  const r = Math.round(ca.r + (cb.r - ca.r) * tt);
  const g = Math.round(ca.g + (cb.g - ca.g) * tt);
  const bb = Math.round(ca.b + (cb.b - ca.b) * tt);
  return `rgb(${r}, ${g}, ${bb})`;
}

function hexToRgb(hex) {
  const s = hex.replace("#", "");
  const full = s.length === 3 ? s.split("").map((ch) => ch + ch).join("") : s;
  const n = parseInt(full, 16);
  return { r: (n >> 16) & 255, g: (n >> 8) & 255, b: n & 255 };
}

function mulberry32(seed) {
  return function () {
    let t = (seed += 0x6D2B79F5);
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

function hashStringToInt(str) {
  let h = 2166136261;
  for (let i = 0; i < str.length; i++) {
    h ^= str.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return h >>> 0;
}

