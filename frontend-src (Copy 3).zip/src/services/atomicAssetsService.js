// src/services/atomicAssetsService.js
export const ATOMIC_ASSETS_BASE =
  process.env.REACT_APP_ATOMIC_ASSETS_BASE ||
  'https://atomic-api.wax.cryptolions.io/atomicassets/v1';
export const ATOMIC_ASSETS_CONTRACT = 'atomicassets';
