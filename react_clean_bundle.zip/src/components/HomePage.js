// src/components/HomePage.js
import React, { useEffect } from 'react';
import { Link } from 'react-router-dom';
import useSession from '../hooks/useSession';
import logo from '../assets/cleanupcentr.png';

// If you'd like to try converting a numeric EOSIO actor to a human-readable name,
// uncomment this line (and ensure eosjs is installed and the import path is correct).
// import { uint64ToName } from 'eosjs/dist/eosjs-numeric';

const HomePage = () => {
  const { session, handleLogin, handleLogout } = useSession();

  // Log the entire session object for debugging
  useEffect(() => {
    console.log('Session object:', session);
  }, [session]);

  let actor = '';
  if (session) {
    // 1. If session has a friendly name property (e.g., session.actorName), use it
    if (session.actorName) {
      actor = session.actorName;
    }
    // 2. Otherwise, if session.actor is an object, assume .value is the numeric or string
    else if (typeof session.actor === 'object' && session.actor !== null) {
      actor = session.actor.value;
    }
    // 3. If it's a number, you can try converting it to a readable EOSIO name
    //    Uncomment the code if you'd like to attempt the numeric conversion.
    /*
    else if (typeof session.actor === 'number') {
      try {
        actor = uint64ToName(session.actor);
      } catch (e) {
        console.error('Conversion error:', e);
        actor = session.actor; // fallback to numeric
      }
    }
    */
    else {
      actor = session.actor;
    }
  }

  return (
    <div style={{ padding: '1rem', textAlign: 'center' }}>
      <header>
        <img src={logo} alt="Cleanup Logo" style={{ width: '150px' }} />
        <h1>TheCleanupCentr</h1>
      </header>
      {!session ? (
        <div style={{ marginTop: '2rem' }}>
          <button
            onClick={() => handleLogin('anchor')}
            style={{ padding: '10px 20px', fontSize: '16px' }}
          >
            Login
          </button>
        </div>
      ) : (
        <div style={{ marginTop: '2rem' }}>
          <p>Welcome, {String(actor)}!</p>
          <button
            onClick={handleLogout}
            style={{
              padding: '8px 16px',
              fontSize: '14px',
              marginBottom: '1rem'
            }}
          >
            Log out
          </button>
          <div style={{ marginTop: '2rem' }}>
            <Link to="/burn">
              <button
                style={{
                  padding: '1rem 2rem',
                  marginRight: '1rem',
                  fontSize: '1.2rem'
                }}
              >
                Cleanup Center
              </button>
            </Link>
            <Link to="/farming">
              <button
                style={{
                  padding: '1rem 2rem',
                  fontSize: '1.2rem'
                }}
              >
                Farming Section
              </button>
            </Link>
          </div>
        </div>
      )}
    </div>
  );
};

export default HomePage;
