import axios from 'axios';

const API_BASE = process.env.REACT_APP_API_BASE_URL;

/**
 * Fetch approved collections and template IDs for filtering burnable NFTs.
 * This uses the new backend route: /collections/approved
 * @returns {Promise<Array<{ collection: string, template_id: number }>>}
 */
export async function fetchApprovedCollections() {
  try {
    const response = await axios.get(`${API_BASE}/collections/approved`);
    if (response.data && response.data.success && Array.isArray(response.data.data)) {
      return response.data.data;
    } else {
      console.warn('Unexpected response format from /collections/approved:', response.data);
      return [];
    }
  } catch (error) {
    console.error('[fetchApprovedCollections] Failed to fetch approved collections:', error.message);
    return [];
  }
}
