import axios from 'axios';
import { ATOMIC_ASSETS_BASE } from './atomicAssetsService';
import { fetchApprovedCollections } from './approvedCollectionsService';

/**
 * Split an array into chunks of given size.
 */
function chunkArray(array, size) {
  const chunks = [];
  for (let i = 0; i < array.length; i += size) {
    chunks.push(array.slice(i, i + size));
  }
  return chunks;
}

/**
 * Helper that tries the AtomicAssets endpoint with fallback mirrors.
 */
async function fetchWithFallback(path, params) {
  const mirrors = [
    ATOMIC_ASSETS_BASE,
    // add more fallback bases here if needed
  ];
  let lastError;
  for (const base of mirrors) {
    try {
      const response = await axios.get(
        `${base}${path}`,
        { params, timeout: 10000 }
      );
      return response.data;
    } catch (err) {
      lastError = err;
      console.warn(`[WARN] ${base}${path} failed`, err.message);
    }
  }
  throw lastError;
}

/**
 * Fetch all burnable NFTs for a user.
 */
export async function fetchBurnableNFTs(accountName) {
  try {
    // 1. Get approved collections from backend
    const approvedNFTs = await fetchApprovedCollections();

    // 2. Load on-chain proposals
    const proposals = [];
    let lowerBound = null;
    do {
      const { data } = await axios.post(
        'https://wax.pink.gg/v1/chain/get_table_rows',
        {
          json: true,
          code: 'cleanupcentr',
          scope: 'cleanupcentr',
          table: 'proposals',
          limit: 100,
          lower_bound: lowerBound,
        },
        { timeout: 10000 }
      );
      proposals.push(...data.rows);
      lowerBound = data.more ? data.next_key : null;
    } while (lowerBound);
    const approvedProposals = proposals.filter(p => p.status === 'approved');

    // 3. Group by collection
    const grouped = approvedNFTs.reduce((acc, { collection, template_id }) => {
      acc[collection] = acc[collection] || new Set();
      acc[collection].add(template_id);
      return acc;
    }, {});

    // 4. Fetch assets in parallel, batching template IDs
    const fetchTasks = [];
    Object.entries(grouped).forEach(([collection, templates]) => {
      const ids = Array.from(templates);
      chunkArray(ids, 50).forEach(chunk => {
        const params = {
          collection_name: collection,
          owner: accountName || undefined,
          template_id: chunk.join(','),
        };
        fetchTasks.push(
          fetchWithFallback('/assets', params)
            .then(data => ({ collection, data: data.data }))
        );
      });
    });

    const responses = await Promise.all(fetchTasks);
    const results = [];

    // 5. Combine and enrich
    responses.forEach(({ collection, data }) => {
      data.forEach(asset => {
        const match = approvedProposals.find(p =>
          String(p.template_id) === String(asset.template.template_id) &&
          p.collection.toLowerCase() === asset.collection.collection_name.toLowerCase()
        );
        results.push({
          asset_id: asset.asset_id,
          collection_name: asset.collection.collection_name,
          schema_name: asset.schema.schema_name,
          template_id: asset.template.template_id,
          template_name: asset.template.immutable_data.name || null,
          img: asset.template.immutable_data.img || null,
          trash_fee: match?.trash_fee ?? null,
          cinder_reward: match?.cinder_reward ?? null,
        });
      });
    });

    return results;
  } catch (error) {
    console.error('fetchBurnableNFTs error:', error.response?.data || error.message);
    throw error;
  }
}
