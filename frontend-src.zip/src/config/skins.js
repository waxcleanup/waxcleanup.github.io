// src/config/skins.js

export const SKINS = [
  { id: 'default',    name: 'Default',          cssClass: '' },
  { id: 'mock-neon',  name: 'Neon Glow (Free)', cssClass: 'skin-mock-neon' },
  { id: 'fire',       name: 'Fire Blaze',       cssClass: 'skin-fire' },
  // → In future, just add new entries here
];
