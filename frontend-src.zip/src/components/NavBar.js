// src/components/NavBar.js
import React from 'react';
import { NavLink } from 'react-router-dom';
import './NavBar.css';

export default function NavBar() {
  return (
    <nav className="nav-bar">
      <div className="nav-logo">CleanupCentr</div>
      <ul className="nav-links">
        <li>
          <NavLink 
            to="/" 
            className={({ isActive }) => isActive ? 'nav-link active' : 'nav-link'}
          >
            Home
          </NavLink>
        </li>
        <li>
          <NavLink 
            to="/burn" 
            className={({ isActive }) => isActive ? 'nav-link active' : 'nav-link'}
          >
            Burn
          </NavLink>
        </li>
        <li>
          <NavLink 
            to="/farming" 
            className={({ isActive }) => isActive ? 'nav-link active' : 'nav-link'}
          >
            Farming
          </NavLink>
        </li>
        <li>
          <NavLink 
            to="/collections" 
            className={({ isActive }) => isActive ? 'nav-link active' : 'nav-link'}
          >
            Collections
          </NavLink>
        </li>
        <li>
          <NavLink 
            to="/dashboard" 
            className={({ isActive }) => isActive ? 'nav-link active' : 'nav-link'}
          >
            Dashboard
          </NavLink>
        </li>
      </ul>
    </nav>
  );
}
