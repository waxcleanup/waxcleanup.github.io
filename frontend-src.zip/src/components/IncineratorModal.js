import React, { useEffect, useState } from 'react';
import PropTypes from 'prop-types';
import IncineratorDetails from './IncineratorDetails';
import { repairIncinerator } from '../services/transactionActions';

const IncineratorModal = ({
  accountName,
  stakedIncinerators = [],
  unstakedIncinerators = [],
  onIncineratorSelect,
  onUnstakedStake,
  onUnstake,
  onClose,
  loadFuel,
  loadEnergy,
  repairDurability,
  assignedSlots = [],
  fetchData,
  repairTimers = {},
  onFinalizeRepair
}) => {
  const [isLoading, setIsLoading] = useState(false);
  const [message, setMessage] = useState('');
  const [loadingIncinerators, setLoadingIncinerators] = useState(true);
  const [incineratorError, setIncineratorError] = useState('');

  const availableStakedIncinerators = stakedIncinerators.filter(
    (incinerator) =>
      !assignedSlots.some((slot) => slot && slot.asset_id === incinerator.asset_id)
  );

  const normalizedStaked = availableStakedIncinerators.map((i) => ({
    ...i,
    max_fuel: i.max_fuel || i.fuelCap || 100000,
    max_energy: i.max_energy || i.energyCap || 10,
    img: i.img || i.imgCid || 'default-placeholder.png'
  }));

  const normalizedUnstaked = unstakedIncinerators.map((i) => ({
    ...i,
    img: i.img || i.imgCid || 'default-placeholder.png'
  }));

  useEffect(() => {
    setLoadingIncinerators(true);
    setIncineratorError('');
    const timeoutId = setTimeout(() => {
      if (stakedIncinerators.length === 0 && unstakedIncinerators.length === 0) {
        setIncineratorError('Failed to load incinerators. Please try again.');
        setLoadingIncinerators(false);
      }
    }, 20000);

    if (stakedIncinerators.length > 0 || unstakedIncinerators.length > 0) {
      setLoadingIncinerators(false);
      clearTimeout(timeoutId);
    }

    return () => clearTimeout(timeoutId);
  }, [stakedIncinerators, unstakedIncinerators]);

  const handleStake = async (e, incinerator) => {
    e.stopPropagation();
    setIsLoading(true);
    setMessage('Staking in progress...');
    try {
      await onUnstakedStake(incinerator);
      setMessage('Incinerator staked successfully!');
      await fetchData();
    } catch (error) {
      console.error('[ERROR] Staking failed:', error);
      setMessage(`Error staking: ${error.message || 'Unknown error'}`);
    } finally {
      setIsLoading(false);
    }
  };

  const handleUnstake = async (e, incinerator) => {
    e.stopPropagation();
    const confirmUnstake = window.confirm(
      `Are you sure you want to unstake this incinerator?\n\n⚠️ Fuel and energy will be reset to 0.\nThis action cannot be undone.`
    );
    if (!confirmUnstake) return;

    setIsLoading(true);
    setMessage('Unstaking in progress...');
    try {
      await onUnstake(incinerator);
      setMessage('Incinerator unstaked successfully!');
      await fetchData();
    } catch (error) {
      console.error('[ERROR] Unstaking failed:', error);
      setMessage(`Error unstaking: ${error.message || 'Unknown error'}`);
    } finally {
      setIsLoading(false);
    }
  };

  const handleClose = () => {
    onClose();
    fetchData();
  };

  return (
    <div className="modal-overlay">
      <div className="modal-content">
        <h3>Select an Incinerator</h3>
        <button className="close-button" onClick={handleClose}>&times;</button>

        {loadingIncinerators ? (
          <div className="loading-overlay">
            <div className="loading-message">🔄 Loading incinerators...</div>
          </div>
        ) : incineratorError ? (
          <div className="error-overlay">
            <p>{incineratorError}</p>
            <button onClick={fetchData}>Retry</button>
            <button onClick={onClose}>Close</button>
          </div>
        ) : (
          <>
            <div className="staked-section">
              <h4>Staked Incinerators</h4>
              <div className="incinerator-grid">
                {normalizedStaked.map((incinerator) => {
                  const id = incinerator.asset_id || incinerator.id;
                  const seconds = repairTimers[id];
                  const showFinalize = seconds !== undefined && seconds <= 0;

                  return (
                    <div
                      key={id}
                      className="incinerator-card"
                      onClick={() => onIncineratorSelect(incinerator)}
                    >
                      <IncineratorDetails
                        incinerator={incinerator}
                        fetchIncineratorData={fetchData}
                        showButtons={false}
                        onRepair={() => {}}
                      />
                      {seconds > 0 && (
                        <p className="repair-timer">Repair in progress: {seconds}s remaining</p>
                      )}
                      {showFinalize && (
                        <button
                          className="finalize-button"
                          onClick={(e) => {
                            e.stopPropagation();
                            onFinalizeRepair(id);
                          }}
                        >
                          Finalize Repair
                        </button>
                      )}
                      {incinerator.durability === 500 && (
                        <button
                          className="unstake-button"
                          onClick={(e) => handleUnstake(e, incinerator)}
                        >
                          Unstake
                        </button>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>

            <div className="unstaked-section">
              <h4>Unstaked Incinerators</h4>
              <div className="incinerator-grid">
                {normalizedUnstaked.map((incinerator) => (
                  <div key={incinerator.asset_id || incinerator.id} className="incinerator-card">
                    <IncineratorDetails
                      incinerator={incinerator}
                      fetchIncineratorData={fetchData}
                      showButtons={false}
                      onRepair={() => {}}
                    />
                    <button
                      className="stake-button"
                      onClick={(e) => handleStake(e, incinerator)}
                    >
                      Stake
                    </button>
                  </div>
                ))}
              </div>
            </div>
          </>
        )}
      </div>
    </div>
  );
};

IncineratorModal.propTypes = {
  accountName: PropTypes.string.isRequired,
  stakedIncinerators: PropTypes.array.isRequired,
  unstakedIncinerators: PropTypes.array.isRequired,
  onIncineratorSelect: PropTypes.func.isRequired,
  onUnstakedStake: PropTypes.func.isRequired,
  onUnstake: PropTypes.func.isRequired,
  onClose: PropTypes.func.isRequired,
  loadFuel: PropTypes.func.isRequired,
  loadEnergy: PropTypes.func,
  repairDurability: PropTypes.func,
  assignedSlots: PropTypes.array,
  fetchData: PropTypes.func.isRequired,
  repairTimers: PropTypes.object,
  onFinalizeRepair: PropTypes.func
};

export default IncineratorModal;
