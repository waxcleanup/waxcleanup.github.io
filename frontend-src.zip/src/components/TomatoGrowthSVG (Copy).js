// src/components/TomatoGrowthSVG.js
import React from "react";

/**
 * TomatoGrowthSVG
 *
 * Props:
 *  - tick: current tick (0..tickGoal or 1..tickGoal)
 *  - tickGoal: total ticks for this slot (e.g. 21, or whatever contract sets)
 *  - weather: optional string: "sunny" | "rainy" | "cloudy" | "windy" | "stormy"
 *  - rarity: optional string: "common" | "rare" | "epic" | "legendary"
 *  - className: optional wrapper class
 *
 * It internally scales your tick → a 1..21 virtual growth scale.
 */
export default function TomatoGrowthSVG({
  tick = 0,
  tickGoal = 21,
  weather = "sunny",
  rarity = "common",
  className = ""
}) {
  // Normalize input ticks
  const safeGoal = Math.max(1, tickGoal || 1);
  const clampedTick = Math.max(0, Math.min(tick || 0, safeGoal));

  // progress 0..1
  const progress = safeGoal === 1 ? 1 : clampedTick / safeGoal;

  // Map progress to a virtual 1..21 tick scale
  const VIRTUAL_TOTAL = 21;
  const virtualTick = Math.max(
    1,
    Math.min(
      VIRTUAL_TOTAL,
      Math.round(progress * (VIRTUAL_TOTAL - 1)) + 1
    )
  );

  const p = (virtualTick - 1) / (VIRTUAL_TOTAL - 1); // 0..1 for geometry

  // Stage mapping based on virtualTick (1..21)
  const stage = (function () {
    if (virtualTick <= 3) return { key: "germination", label: "Germination" };
    if (virtualTick <= 6) return { key: "seedling", label: "Seedling" };
    if (virtualTick <= 9) return { key: "vegetative", label: "Vegetative Growth" };
    if (virtualTick <= 12) return { key: "bloom", label: "Bloom / Pollination" };
    if (virtualTick <= 15) return { key: "fruit", label: "Fruit Formation" };
    if (virtualTick <= 18) return { key: "ripening", label: "Ripening" };
    return { key: "harvest", label: "Harvest" };
  })();

  // Stem height
  const stemH = 20 + p * 55; // 20 → 75

  // Leaves by stage
  const leafCount =
    stage.key === "germination" ? 0 :
    stage.key === "seedling" ? 2 :
    stage.key === "vegetative" ? 6 :
    stage.key === "bloom" ? 8 :
    stage.key === "fruit" ? 10 : 10;

  const flowerOpacity =
    stage.key === "bloom" ? 1 :
    stage.key === "fruit" ? 0.35 : 0;

  // Fruit size / color based on virtualTick
  const fruitProgress = Math.max(0, Math.min(1, (virtualTick - 13) / (21 - 13)));
  const fruitR = fruitProgress * 16; // radius up to 16
  const tomatoColor = lerpColor(
    "#4CAF50",
    "#E53935",
    Math.max(0, (virtualTick - 16) / (21 - 16)) // green → red
  );

  // rarity glow
  const rarityGlowMap = {
    common: 0.0,
    rare: 0.35,
    epic: 0.6,
    legendary: 0.9
  };
  const rarityGlow =
    rarityGlowMap[rarity] != null ? rarityGlowMap[rarity] : 0.0;

  // Weather flags
  const isCloudy = weather === "cloudy";
  const isWindy = weather === "windy";
  const isStormy = weather === "stormy";

  // Leaf positions
  const leaves = Array.from({ length: leafCount }, function (_, i) {
    const y = 80 - (stemH * ((i + 1) / (leafCount + 1)));
    const side = i % 2 === 0 ? 1 : -1;
    const x = 50 + side * (6 + (i % 3));
    const rot = side * (15 + (i % 4) * 5);
    const scale = 0.9 + (i % 5) * 0.03;
    return { x: x, y: y, rot: rot, scale: scale };
  });

  const clouds = [
    { x: 10, y: 20, w: 22, h: 10 },
    { x: 60, y: 15, w: 26, h: 12 }
  ];

  return (
    <div className={"tomato-growth-wrapper " + className}>
      <svg
        viewBox="0 0 100 100"
        className="tomato-growth-svg"
        role="img"
        aria-label={"Tomato growth — " + stage.label}
      >
        <defs>
          <linearGradient id="tgs-sky" x1="0" y1="0" x2="0" y2="1">
            <stop
              offset="0%"
              stopColor={isStormy ? "#3a4763" : isCloudy ? "#7fb0ff" : "#87CEEB"}
            />
            <stop offset="100%" stopColor={isStormy ? "#1d2433" : "#cfe9ff"} />
          </linearGradient>

          <linearGradient id="tgs-soil" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor="#6d4c41" />
            <stop offset="100%" stopColor="#4e342e" />
          </linearGradient>

          <radialGradient id="tgs-sun" cx="80%" cy="15%" r="20%">
            <stop offset="0%" stopColor="#fff8e1" stopOpacity="0.9" />
            <stop offset="100%" stopColor="#ffeb3b" stopOpacity="0.3" />
          </radialGradient>

          <filter id="tgs-glow" x="-50%" y="-50%" width="200%" height="200%">
            <feGaussianBlur
              in="SourceGraphic"
              stdDeviation={rarityGlow * 3}
              result="tgs-blur"
            />
            <feMerge>
              <feMergeNode in="tgs-blur" />
              <feMergeNode in="SourceGraphic" />
            </feMerge>
          </filter>

          <style>{`
            @keyframes tgs-drift {
              from { transform: translateX(-10%); }
              to   { transform: translateX(110%); }
            }
            @keyframes tgs-sway {
              0%   { transform: rotate(-1deg); }
              50%  { transform: rotate( 1deg); }
              100% { transform: rotate(-1deg); }
            }
            .tgs-cloud {
              animation: tgs-drift linear infinite;
              opacity: ${isCloudy || isStormy ? 0.7 : 0.35};
            }
            .tgs-cloud0 { animation-duration: 26s; animation-delay: 0s; }
            .tgs-cloud1 { animation-duration: 32s; animation-delay: 2s; }
            .tgs-stem {
              transform-origin: 50% 80%;
              animation: tgs-sway ${isWindy ? 1.2 : 3}s ease-in-out infinite;
            }
          `}</style>
        </defs>

        {/* Sky */}
        <rect x="0" y="0" width="100" height="100" fill="url(#tgs-sky)" />

        {/* Sun */}
        {!isStormy && (
          <circle cx="82" cy="13" r="10" fill="url(#tgs-sun)" />
        )}

        {/* Clouds */}
        {clouds.map(function (c, i) {
          return (
            <g
              key={i}
              className={"tgs-cloud tgs-cloud" + i}
              style={{ transformBox: "fill-box" }}
            >
              <ellipse
                cx={c.x}
                cy={c.y}
                rx={c.w / 2}
                ry={c.h / 2}
                fill="#ffffff"
              />
              <ellipse
                cx={c.x + 6}
                cy={c.y - 3}
                rx={c.w / 3}
                ry={c.h / 2.5}
                fill="#ffffff"
              />
              <ellipse
                cx={c.x - 6}
                cy={c.y - 2}
                rx={c.w / 3}
                ry={c.h / 3}
                fill="#ffffff"
              />
            </g>
          );
        })}

        {/* Soil */}
        <rect x="0" y="80" width="100" height="20" fill="url(#tgs-soil)" />

        {/* Seed (early only) */}
        {stage.key === "germination" && (
          <g filter="url(#tgs-glow)">
            <ellipse cx="50" cy="80" rx="2.5" ry="1.8" fill="#8D6E63" />
            <path
              d="M49.8,79.2 Q50,78.6 50.2,79.2"
              stroke="#5D4037"
              strokeWidth="0.3"
              fill="none"
            />
          </g>
        )}

        {/* Stem */}
        <g className="tgs-stem" filter="url(#tgs-glow)">
          <path
            d={
              "M50 80 C50 " +
              (80 - stemH * 0.35) +
              ", 50 " +
              (80 - stemH * 0.7) +
              ", 50 " +
              (80 - stemH)
            }
            stroke="#2e7d32"
            strokeWidth="1.6"
            fill="none"
            strokeLinecap="round"
          />
        </g>

        {/* Leaves */}
        {leaves.map(function (leaf, i) {
          return (
            <g
              key={i}
              transform={
                "translate(" +
                leaf.x +
                " " +
                leaf.y +
                ") rotate(" +
                leaf.rot +
                ") scale(" +
                leaf.scale +
                ")"
              }
              opacity="0.9"
            >
              <path
                d="M0 0 C 6 -3, 8 3, 0 6 C -8 3, -6 -3, 0 0 Z"
                fill="#43A047"
                stroke="#2e7d32"
                strokeWidth="0.3"
              />
              <path
                d="M0 0 L0 6"
                stroke="#2e7d32"
                strokeWidth="0.3"
              />
            </g>
          );
        })}

        {/* Flowers */}
        {Array.from({ length: 4 }).map(function (_, i) {
          const fx = 50 + (i - 1.5) * 6;
          const fy = 80 - stemH * (0.5 + i * 0.05);
          return (
            <g key={i} opacity={flowerOpacity} filter="url(#tgs-glow)">
              <circle
                cx={fx}
                cy={fy}
                r="2.2"
                fill="#FFD54F"
                stroke="#F9A825"
                strokeWidth="0.4"
              />
              <circle
                cx={fx}
                cy={fy}
                r="0.9"
                fill="#F57F17"
              />
            </g>
          );
        })}

        {/* Fruit (later stages) */}
        {virtualTick >= 13 && (
          <g filter="url(#tgs-glow)">
            <circle
              cx="50"
              cy={80 - stemH + 6}
              r={fruitR}
              fill={tomatoColor}
              stroke="#8B1A1A"
              strokeWidth={fruitR > 0 ? 0.6 : 0}
            />
            {fruitR > 6 && (
              <ellipse
                cx="46"
                cy={80 - stemH + 2}
                rx={fruitR * 0.45}
                ry={fruitR * 0.25}
                fill="#ffffff"
                opacity="0.15"
              />
            )}
            {fruitR > 3 && (
              <g>
                <circle
                  cx="50"
                  cy={80 - stemH - 4}
                  r="2"
                  fill="#2e7d32"
                />
                {Array.from({ length: 5 }).map(function (_, i) {
                  const angle = (i * 72) * Math.PI / 180;
                  const dx = Math.cos(angle) * 4;
                  const dy = Math.sin(angle) * 4;
                  return (
                    <path
                      key={i}
                      d={
                        "M50 " +
                        (80 - stemH - 4) +
                        " l " +
                        dx +
                        " " +
                        dy
                      }
                      stroke="#2e7d32"
                      strokeWidth="0.8"
                    />
                  );
                })}
              </g>
            )}
          </g>
        )}

        {/* Stage label bar */}
        <g>
          <rect
            x="6"
            y="86"
            width="88"
            height="8"
            rx="2"
            fill="#FFFFFF"
            opacity="0.6"
          />
          <text
            x="50"
            y="91.5"
            textAnchor="middle"
            fontSize="3.6"
            fill="#1b3a2f"
          >
            {stage.label}
          </text>
        </g>

        {/* Progress bar based on real ticks */}
        <g>
          <rect
            x="6"
            y="96"
            width="88"
            height="2"
            rx="1"
            fill="#e0e0e0"
          />
          <rect
            x="6"
            y="96"
            width={88 * progress}
            height="2"
            rx="1"
            fill="#43A047"
          />
        </g>
      </svg>
    </div>
  );
}

/* ----- tiny color helpers ----- */

function lerpColor(a, b, t) {
  var ca = hexToRgb(a);
  var cb = hexToRgb(b);
  var r = Math.round(ca.r + (cb.r - ca.r) * t);
  var g = Math.round(ca.g + (cb.g - ca.g) * t);
  var b2 = Math.round(ca.b + (cb.b - ca.b) * t);
  return "rgb(" + r + ", " + g + ", " + b2 + ")";
}

function hexToRgb(hex) {
  var s = hex.replace("#", "");
  var full =
    s.length === 3
      ? s.split("").map(function (ch) { return ch + ch; }).join("")
      : s;
  var n = parseInt(full, 16);
  return {
    r: (n >> 16) & 255,
    g: (n >> 8) & 255,
    b: n & 255
  };
}
