// src/components/FarmPlotsGrid.js
import React, { useEffect, useState } from 'react';
import axios from 'axios';
import './FarmPlotsGrid.css';
import FarmSlotModal from './FarmSlotModal';
import useSession from '../hooks/useSession';
import { waterPlot, harvestPlot } from '../services/plotActions';

export default function FarmPlotsGrid({ farmId }) {
  const { session } = useSession();
  const wallet = session?.actor;

  const [plots, setPlots] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  // Selected slot for details / actions
  // We store the full plot + slot so the modal has all metadata
  const [selectedSlot, setSelectedSlot] = useState(null);

  // TX state for slot-level actions
  const [slotPending, setSlotPending] = useState(null); // e.g. "water-1099..-0"
  const [txError, setTxError] = useState(null);

  // ---------------------------------------------------------------------------
  // Helper: load plots for this farm
  // ---------------------------------------------------------------------------
  const fetchPlots = async () => {
    if (!farmId) return;

    setLoading(true);
    try {
      const res = await axios.get(
        `${process.env.REACT_APP_API_BASE_URL}/api/farms/${farmId}/plots`
      );
      const newPlots = res.data.plots || [];
      setPlots(newPlots);
      setError(null);

      // 🔄 If a slot is selected, refresh its data from the updated plots
      if (selectedSlot) {
        const updatedPlot = newPlots.find(
          (p) => String(p.plot_asset_id) === String(selectedSlot.plot.plot_asset_id)
        );
        if (updatedPlot) {
          const updatedSlot = updatedPlot.slots.find(
            (s) => s.index === selectedSlot.slot.index
          );
          if (updatedSlot) {
            setSelectedSlot({
              ...selectedSlot,
              plot: updatedPlot,
              slot: updatedSlot,
            });
          }
        }
      }
    } catch (err) {
      console.error('Error loading farm plots:', err);
      setError('Could not load plots for this farm.');
    } finally {
      setLoading(false);
    }
  };

  // Initial + on farmId change
  useEffect(() => {
    fetchPlots();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [farmId]);

  // ---------------------------------------------------------------------------
  // Slot actions: water / harvest
  // ---------------------------------------------------------------------------
  const handleWater = async (plot, slot) => {
    if (!wallet) {
      setTxError('Please connect your wallet to water plots.');
      return;
    }

    const key = `water-${plot.plot_asset_id}-${slot.index}`;
    setSlotPending(key);
    setTxError(null);

    try {
      // NOTE: your service currently expects (wallet, plotAssetId, slotIndex)
      await waterPlot(wallet, plot.plot_asset_id, slot.index);

      // Refresh plots & selected slot state
      await fetchPlots();
      // We KEEP the modal open so user sees tick/state update
    } catch (err) {
      console.error('Water failed:', err);
      setTxError(err.message || 'Water action failed.');
    } finally {
      setSlotPending(null);
    }
  };

  const handleHarvest = async (plot, slot) => {
    if (!wallet) {
      setTxError('Please connect your wallet to harvest.');
      return;
    }

    const key = `harvest-${plot.plot_asset_id}-${slot.index}`;
    setSlotPending(key);
    setTxError(null);

    try {
      await harvestPlot(wallet, plot.plot_asset_id, slot.index);

      // Refresh plots & selected slot state
      await fetchPlots();
      // After harvest, we also keep modal open; state should flip to EMPTY
    } catch (err) {
      console.error('Harvest failed:', err);
      setTxError(err.message || 'Harvest action failed.');
    } finally {
      setSlotPending(null);
    }
  };

  // ---------------------------------------------------------------------------
  // Render states
  // ---------------------------------------------------------------------------
  if (loading && !plots.length) {
    return <div className="plots-grid-status">Loading plots…</div>;
  }

  if (error) {
    return <div className="plots-grid-status error">{error}</div>;
  }

  if (!plots.length) {
    return (
      <div className="plots-grid-status">
        No plots staked to this farm yet.
      </div>
    );
  }

  return (
    <>
      {txError && (
        <div className="plots-grid-status error">
          {txError}
        </div>
      )}

      <div className="farm-plots-grid">
        {plots.map((plot) => (
          <div key={plot.plot_asset_id} className="plot-card">
            <div className="plot-header">
              {plot.image && (
                <img
                  src={plot.image}
                  alt={plot.name}
                  className="plot-image"
                />
              )}
              <div className="plot-header-text">
                <div className="plot-name">{plot.name}</div>
                <div className="plot-meta">
                  Plot #{String(plot.plot_asset_id).slice(-4)} · Slots:{' '}
                  {plot.capacity}
                </div>
              </div>
            </div>

            <div className={`plot-slots plot-slots-${plot.capacity}`}>
              {plot.slots.map((slot) => (
                <div
                  key={slot.index}
                  className={`plot-slot plot-slot-${slot.state.toLowerCase()}`}
                  title={
                    slot.state === 'EMPTY'
                      ? 'Empty plot slot'
                      : `${slot.state} (${slot.tick}/${slot.tick_goal})`
                  }
                  onClick={() =>
                    setSelectedSlot({
                      farmId,
                      plot,
                      slot,
                    })
                  }
                >
                  {slot.state === 'READY'
                    ? '✨'
                    : slot.state === 'GROWING'
                    ? '🌱'
                    : ''}
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>

      {/* Slot detail modal */}
      {selectedSlot && (
        <FarmSlotModal
          farmId={selectedSlot.farmId}
          plot={selectedSlot.plot}
          slot={selectedSlot.slot}
          onClose={() => setSelectedSlot(null)}
          onWater={() => handleWater(selectedSlot.plot, selectedSlot.slot)}
          onHarvest={() => handleHarvest(selectedSlot.plot, selectedSlot.slot)}
          slotPending={slotPending}
        />
      )}
    </>
  );
}
