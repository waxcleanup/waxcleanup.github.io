// src/components/Farming.js
import React, { useState, useEffect } from 'react';
import axios from 'axios';
import './Farming.css';
import useSession from '../hooks/useSession';
import NavBar from './NavBar';
import FarmSelectionModal from './FarmSelectionModal';
import FarmCard from './FarmCard';
import { stakeFarm } from '../services/farmActions';

function Farming() {
  const [weather, setWeather] = useState(null);
  const [loading, setLoading] = useState(false);
  const [farmInfo, setFarmInfo] = useState(null);
  const [farmError, setFarmError] = useState(null);
  const [showFarmModal, setShowFarmModal] = useState(false);
  const [selectedFarm, setSelectedFarm] = useState(null);
  const [allFarms, setAllFarms] = useState([]);
  const { session } = useSession();
  const wallet = session?.actor;

  // Fetch weather & global farms on mount
  useEffect(() => {
    const fetchWeather = async () => {
      setLoading(true);
      try {
        const res = await axios.get(`${process.env.REACT_APP_API_BASE_URL}/weather/current`);
        setWeather(res.data);
      } catch (e) {
        console.error(e);
      } finally {
        setLoading(false);
      }
    };
    const fetchAllFarms = async () => {
      try {
        const res = await axios.get(`${process.env.REACT_APP_API_BASE_URL}/api/farms`);
        setAllFarms(res.data.farms || []);
      } catch (e) {
        console.error(e);
      }
    };

    fetchWeather();
    fetchAllFarms();
  }, []);

  // Fetch farms owned by the user whenever wallet changes
  useEffect(() => {
    if (!wallet) return;
    const fetchFarmInfo = async () => {
      try {
        const res = await axios.get(`${process.env.REACT_APP_API_BASE_URL}/nfts/farm/${wallet}`);
        setFarmInfo(res.data);
      } catch (e) {
        console.error(e);
        setFarmError('Failed to fetch farm data');
      }
    };
    fetchFarmInfo();
  }, [wallet]);

  // Handlers
  const handleOpenModal = farm => {
    setSelectedFarm(farm);
    setShowFarmModal(true);
  };
  const handleStakeFarm = async farm => {
    try {
      await stakeFarm(wallet, farm.asset_id, farm.template_id);
      setShowFarmModal(false);
      // refresh ownership view
      const res = await axios.get(`${process.env.REACT_APP_API_BASE_URL}/nfts/farm/${wallet}`);
      setFarmInfo(res.data);
    } catch (e) {
      console.error(e);
    }
  };

  // Weather-dependent styling
  const condition = weather?.condition || '';
  const isClear = condition.toLowerCase() === 'clear';
  const backgroundClass = getBackgroundClass(condition);

  // Prepare unstaked list
  const farmsAsObjects = (farmInfo?.unstaked || []).map(f => ({
    asset_id: f.asset_id,
    template_id: f.template_id
  }));

  return (
    <>
      <NavBar />

      <div className="farming-container">
        {isClear ? (
          <div className="sun" />
        ) : (
          <>
            <div className="cloud cloud1" />
            <div className="cloud cloud2" />
            <div className="cloud cloud3" />
          </>
        )}

        <h2 className="farming-header">🌾 Farming Weather Conditions</h2>
        {loading ? (
          <p className="farming-status">Loading weather data...</p>
        ) : weather ? (
          <div className={`weather-card ${backgroundClass}`}>
            <div className="weather-divider" />
            <div className="card-title">{condition}</div>
            <div className="temp-row">{weather.temperature}°F</div>
            <div className="weather-row"><strong>Precipitation:</strong> {weather.precip}%</div>
            <div className="weather-row"><strong>Humidity:</strong> {weather.humidity}%</div>
            <div className="weather-row"><strong>Wind Speed:</strong> {weather.wind_speed} mph</div>
            <div className="weather-row"><strong>Boost:</strong> +{weather.yield_boost}%</div>
            <div className="weather-row"><strong>Penalty:</strong> -{weather.yield_penalty}%</div>
          </div>
        ) : (
          <p className="farming-status">Unable to load weather data.</p>
        )}

        <h2 className="farming-header">🏡 Farm Ownership</h2>
        {farmError ? (
          <p className="farming-status">{farmError}</p>
        ) : farmInfo ? (
          farmInfo.count?.staked + farmInfo.count?.unstaked > 0 ? (
            <div className="farm-status-card">
              <p><strong>Template ID:</strong> {farmInfo.template_id}</p>
              <p><strong>Farms Owned:</strong> {farmInfo.count.staked + farmInfo.count.unstaked}</p>
              <p><strong>Name:</strong> {farmInfo.name}</p>
              {farmInfo.ipfs && (
                <img
                  src={farmInfo.ipfs}
                  alt="Farm"
                  className="farm-nft-image"
                />
              )}
              {farmInfo.staked.length > 0 && (
                <>
                  <p><strong>Staked:</strong></p>
                  <ul>{farmInfo.staked.map(f => <li key={f.asset_id}>{f.asset_id}</li>)}</ul>
                </>
              )}
              {farmInfo.unstaked.length > 0 && (
                <>
                  <p><strong>Unstaked:</strong></p>
                  <ul>
                    {farmsAsObjects.map(f => (
                      <li key={f.asset_id}>
                        {f.asset_id}
                        <button onClick={() => handleOpenModal(f)}>Stake Farm</button>
                      </li>
                    ))}
                  </ul>
                </>
              )}
            </div>
          ) : (
            <p className="farming-status">You do not currently own a farm NFT.</p>
          )
        ) : (
          <p className="farming-status">Checking for farm ownership...</p>
        )}

        {showFarmModal && selectedFarm && (
          <FarmSelectionModal
            assetId={selectedFarm.asset_id}
            onStake={() => handleStakeFarm(selectedFarm)}
            onClose={() => setShowFarmModal(false)}
            stakedFarms={farmInfo.staked}
            unstakedFarms={farmsAsObjects}
          />
        )}

        <h2 className="farming-header">📡 Available Farms (Global)</h2>
        <div className="farm-card-grid">
          {allFarms.map(f => (
            <FarmCard key={f.asset_id} farm={f} />
          ))}
        </div>
      </div>
    </>
  );
}

function getBackgroundClass(cond) {
  const map = {
    clear: 'weather-clear', cloudy: 'weather-cloudy', rain: 'weather-rain',
    'heavy rain': 'weather-heavy-rain', thunderstorm: 'weather-thunderstorm',
    flood: 'weather-flood', tornado: 'weather-tornado', drought: 'weather-drought',
    heatwave: 'weather-heatwave', 'chill setup': 'weather-chill-setup',
    snow: 'weather-snow', sleet: 'weather-sleet', blizzard: 'weather-blizzard',
    windy: 'weather-windy', foggy: 'weather-foggy', hail: 'weather-hail',
    'lightning strike': 'weather-lightning-strike', hurricane: 'weather-hurricane',
    'dust storm': 'weather-dust-storm', drizzle: 'weather-drizzle',
    overcast: 'weather-overcast', 'spring bloom': 'weather-spring-bloom',
    'gentle showers': 'weather-gentle-showers', 'autumn spark': 'weather-autumn-spark',
    'frigid mist': 'weather-frigid-mist', 'evening calm': 'weather-evening-calm',
    'morning dew': 'weather-morning-dew'
  };
  return map[cond.toLowerCase()] || 'weather-default';
}

export default Farming;
