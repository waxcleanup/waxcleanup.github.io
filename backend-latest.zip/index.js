// index.js
import dotenv from "dotenv";
import path from "path";
import { fileURLToPath } from "url";
import express from "express";
import bodyParser from "body-parser";
import cors from "cors";
import mongoose from "mongoose";
import fs from "fs";
import https from "https";
import cron from "node-cron";

// Import routes
import nftRoutes from "./routes/nfts.js";
import cleanupRoutes from "./routes/cleanup.js";
import collectionRoutes from "./routes/collectionRoutes.js";
import incineratorRoutes from "./routes/incinerators.js";
import burnRoutes from "./routes/burn.js";
import stakingRoutes from "./routes/staking.js";
import weatherRoutes from "./routes/weatherRoutes.js";
import farmRoutes from "./routes/farms.js";
import treeNftsRoutes from "./routes/treeNfts.js";
import inventoryRoutes from "./routes/inventory.js";
import bagRoutes from "./routes/bag.js";
import playerRoutes from "./routes/player.js";
import toolsRoutes from "./routes/toolsRoutes.js";
import userEnergyRoutes from "./routes/userEnergyRoutes.js";

import burnRecordsRoutes from "./routes/burnRecords.js";
import nftFilterRoutes from "./routes/nftFilter.js";
import { syncBurnRecordsPaginated } from "./services/burnSync.js";
import burnStatusRoutes from "./routes/burnStatus.js";

import repairRoutes from "./routes/repairRoutes.js";
import geckoRoutes from "./routes/geckoRoutes.js";

// ✅ Fix: import the function you call
import { searchAccountsByPublicKey } from "./services/blockchainService.js";

// Set up __dirname for ES modules
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Load environment variables
dotenv.config({ path: path.join(__dirname, ".env") });

// Log environment variables (be cautious with this in production)
console.log("Environment variables loaded:", Object.keys(process.env));

// Check for required environment variables
const requiredEnvVars = ["PORT", "MONGODB_URI"];
for (const envVar of requiredEnvVars) {
  if (!process.env[envVar]) {
    console.error(`Error: ${envVar} is not set in environment variables.`);
    process.exit(1);
  }
}

const app = express();
const port = process.env.PORT || 3003;

// CORS configuration
const allowedOrigins = [
  "https://192.168.1.199:3000",
  "https://192.168.1.166:3000",
  "https://localhost:3000",
  "https://maestrobeatz.github.io/TomatoFarmGame",
  "https://maestrobeatz.github.io",
  "https://maestrobeatz.servegame.com",
  "http://localhost:3000",
  "https://waxcleanup.github.io",
  "https://waxcleanup.github.io/cleanupcenter",
  "https://wagyu-stake-protocol-mvp-eight.vercel.app",
];

const corsOptions = {
  origin: function (origin, callback) {
    if (!origin || allowedOrigins.includes(origin)) callback(null, true);
    else callback(new Error("Not allowed by CORS"));
  },
  credentials: true,
  optionsSuccessStatus: 200,
};

// Middleware
app.use(cors(corsOptions));
app.use(bodyParser.json());

// MongoDB connection
mongoose
  .connect(process.env.MONGODB_URI)
  .then(() => console.log("Connected to MongoDB"))
  .catch((err) => {
    console.error("Failed to connect to MongoDB:", err);
    process.exit(1);
  });

// Burn record sync job
if (String(process.env.DISABLE_BURNREC_SYNC || "0") === "1") {
  console.log("🔥 Burn record sync DISABLED (contract-only upgrade).");
} else {
  cron.schedule("*/1 * * * *", async () => {
    console.log("Running paginated burn record sync for storage...");
    await syncBurnRecordsPaginated();
  });
}

// Routes
app.use("/staking", stakingRoutes);
app.use("/nfts", nftRoutes);
app.use("/cleanup", cleanupRoutes);
app.use("/collections", collectionRoutes);
app.use("/incinerators", incineratorRoutes);
app.use("/burn", burnRoutes);
app.use("/", repairRoutes);

app.use("/tools", toolsRoutes);
app.use("/burn-status", burnStatusRoutes);

app.use("/weather", weatherRoutes);
app.use("/api/farms", farmRoutes);
app.use("/api/nfts", treeNftsRoutes);

app.use("/inventory", inventoryRoutes);
app.use("/bag", bagRoutes);
app.use("/api/player", playerRoutes);
app.use("/userenergy", userEnergyRoutes);

app.get("/account-by-public-key/:publicKey", async (req, res) => {
  try {
    const publicKey = req.params.publicKey;
    const accounts = await searchAccountsByPublicKey(publicKey);
    res.json({ accountNames: accounts });
  } catch (error) {
    res.status(500).json({ error: "Failed to fetch account names" });
  }
});

app.use("/burnrecords", burnRecordsRoutes);
app.use("/nfts", nftFilterRoutes);
app.use("/", geckoRoutes);

// ✅ Safe error handler (no missing handleError)
app.use((err, req, res, next) => {
  console.error(err.stack || err);
  res.status(500).json({ error: err.message || "Internal Server Error" });
});

// HTTPS setup
let httpsOptions;
try {
  httpsOptions = {
    key: fs.readFileSync("/etc/letsencrypt/live/maestrobeatz.servegame.com/privkey.pem"),
    cert: fs.readFileSync("/etc/letsencrypt/live/maestrobeatz.servegame.com/fullchain.pem"),
  };
} catch (err) {
  console.error("Failed to read HTTPS certificates:", err);
  process.exit(1);
}

const server = https.createServer(httpsOptions, app);

server.listen(port, () => {
  console.log(`Server running on https://localhost:${port}`);
});

process.on("SIGTERM", () => {
  console.info("SIGTERM signal received.");
  server.close(() => {
    mongoose.connection.close(false, () => process.exit(0));
  });
});

console.log(`Server started successfully. Listening on port ${port}`);
