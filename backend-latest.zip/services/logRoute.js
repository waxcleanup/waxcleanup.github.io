import express from 'express';

const router = express.Router();

// POST route to log messages (for burn results)
router.post('/log', (req, res) => {
  const { message } = req.body;
  if (message) {
    console.log("Log message:", message); // Optionally log to server logs
    return res.status(200).json({ success: true, message });
  } else {
    return res.status(400).json({ success: false, message: 'No message provided' });
  }
});

export default router;
