import axios from 'axios';

const WAX_API = process.env.WAX_TESTNET_API || 'https://wax-testnet.eosphere.io';
const CONTRACT_NAME = 'stakingdapp1';
const TABLE_NAME = 'stakeds';

/**
 * Fetch all scopes for the `stakeds` table
 * @returns {Promise<string[]>} List of scopes (user accounts)
 */
const fetchScopes = async () => {
  try {
    const response = await axios.post(`${WAX_API}/v1/chain/get_table_by_scope`, {
      code: CONTRACT_NAME,
      table: TABLE_NAME,
      limit: 1000,
    });

    return response.data.rows.map((row) => row.scope);
  } catch (error) {
    console.error('Error fetching scopes:', error.message);
    throw new Error('Failed to fetch scopes');
  }
};

/**
 * Fetch all staking data for a specific scope
 * @param {string} scope - The user account scope
 * @returns {Promise<object[]>} List of staking records for the scope
 */
const fetchStakesForScope = async (scope) => {
  try {
    const response = await axios.post(`${WAX_API}/v1/chain/get_table_rows`, {
      json: true,
      code: CONTRACT_NAME,
      scope,
      table: TABLE_NAME,
      limit: 100,
    });

    return response.data.rows.map((stake) => ({
      pool_id: Number(stake.pool_id),
      staked_quantity: stake.staked_quantity,
      tier: stake.tier,
      last_claimed_at: stake.last_claimed_at,
      cooldown_end_at: stake.cooldown_end_at,
      owner: scope,
    }));
  } catch (error) {
    console.error(`Error fetching stakes for scope ${scope}:`, error.message);
    throw new Error(`Failed to fetch stakes for scope ${scope}`);
  }
};

/**
 * Fetch all staking data across all scopes
 * @returns {Promise<object[]>} Combined list of all staking records
 */
export const fetchAllStakes = async () => {
  try {
    const scopes = await fetchScopes();
    console.log('Scopes:', scopes);

    const allStakesPromises = scopes.map((scope) => fetchStakesForScope(scope));
    const allStakes = (await Promise.all(allStakesPromises)).flat();

    console.log('All Stakes:', allStakes);
    return allStakes;
  } catch (error) {
    console.error('Error fetching all stakes:', error.message);
    throw new Error('Failed to fetch all stakes');
  }
};
