// services/burnRecords.js
import { JsonRpc } from 'eosjs';
import fetch from 'node-fetch';
import dotenv from 'dotenv';

dotenv.config();

// Set up API endpoint
const rpc = new JsonRpc(process.env.WAX_MAINNET_API || process.env.WAX_TESTNET_API, { fetch });

/**
 * Fetch burn records for a specific user from the `burnrecs` table.
 * @param {string} user - The EOS account name of the user.
 * @param {number} limit - The number of records to fetch (default: 100).
 * @returns {Array} - An array of burn records for the user.
 */
export const fetchBurnRecords = async (user, limit = 100) => {
    try {
        if (!user) {
            throw new Error("User is required to fetch burn records.");
        }

        // Remove upper and lower bound logic; filter on application side
        const response = await rpc.get_table_rows({
            json: true,
            code: process.env.CLEANUPCENTR_ACCOUNT || 'cleanupcentr', // Contract name
            scope: process.env.CLEANUPCENTR_ACCOUNT || 'cleanupcentr', // Scope
            table: 'burnrecs', // Table name
            limit, // Limit the number of records
        });

        const filteredRecords = response.rows.filter((record) => record.user === user);

        console.log(`Fetched burn records for user ${user}:`, filteredRecords);
        return filteredRecords;
    } catch (error) {
        console.error(`Failed to fetch burn records for user ${user}:`, error.message);
        return [];
    }
};

/**
 * Fetch all burn records from the `burnrecs` table.
 * @param {number} limit - The number of records to fetch (default: 100).
 * @returns {Array} - An array of all burn records.
 */
export const fetchAllBurnRecords = async (limit = 100) => {
    try {
        const response = await rpc.get_table_rows({
            json: true,
            code: process.env.CLEANUPCENTR_ACCOUNT || 'cleanupcentr', // Contract name
            scope: process.env.CLEANUPCENTR_ACCOUNT || 'cleanupcentr', // Scope
            table: 'burnrecs', // Table name
            limit, // Limit the number of records
        });

        console.log(`Fetched all burn records:`, response.rows);
        return response.rows || [];
    } catch (error) {
        console.error(`Failed to fetch all burn records:`, error.message);
        return [];
    }
};

/**
 * Fetch burn records for a specific asset ID from the `burnrecs` table.
 * @param {string} assetId - The asset ID to search for.
 * @param {number} limit - The number of records to fetch (default: 100).
 * @returns {Array} - An array of burn records matching the asset ID.
 */
export const fetchBurnRecordsByAssetId = async (assetId, limit = 100) => {
    try {
        if (!assetId) {
            throw new Error("Asset ID is required to fetch burn records.");
        }

        // Fetch records in reverse order
        const response = await rpc.get_table_rows({
            json: true,
            code: process.env.CLEANUPCENTR_ACCOUNT || 'cleanupcentr', // Contract name
            scope: process.env.CLEANUPCENTR_ACCOUNT || 'cleanupcentr', // Scope
            table: 'burnrecs', // Table name
            limit, // Limit the number of records
            reverse: true, // Fetch in reverse order
        });

        // Filter records by assetId
        const filteredRecords = response.rows.filter((record) => record.asset_id === assetId);

        console.log(`Fetched burn records for asset ID ${assetId} in reverse order:`, filteredRecords);
        return filteredRecords;
    } catch (error) {
        console.error(`Failed to fetch burn records for asset ID ${assetId}:`, error.message);
        return [];
    }
};
