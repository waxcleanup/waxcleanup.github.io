import axios from 'axios';
import { JsonRpc } from 'eosjs';
import fetch from 'node-fetch';

const ATOMIC = 'https://atomic-api.wax.cryptolions.io/atomicassets/v1';
const rpc = new JsonRpc('https://wax.pink.gg', { fetch });

export const fetchBurnableNFTsForAccount = async (account) => {
  const [approvedNFTs, { rows: proposals }] = await Promise.all([
    axios.get('https://maestrobeatz.servegame.com:3003/collections/approved').then(r => r.data.data),
    rpc.get_table_rows({
      json: true,
      code: 'cleanupcentr',
      scope: 'cleanupcentr',
      table: 'proposals',
      limit: 1000
    }),
  ]);

  const approvedProposals = proposals.filter(p => p.status === 'approved');
  const grouped = approvedNFTs.reduce((acc, { collection, template_id }) => {
    acc[collection] = acc[collection] || new Set();
    acc[collection].add(template_id);
    return acc;
  }, {});

  const results = [];
  for (const [collection, templates] of Object.entries(grouped)) {
    const ids = Array.from(templates);
    const chunks = [];
    for (let i = 0; i < ids.length; i += 50) chunks.push(ids.slice(i, i + 50));

    for (const chunk of chunks) {
      const url = `${ATOMIC}/assets?collection_name=${collection}&owner=${account}&template_id=${chunk.join(',')}`;
      const data = await axios.get(url).then(res => res.data.data);

      for (const asset of data) {
        const match = approvedProposals.find(p =>
          String(p.template_id) === String(asset.template.template_id) &&
          p.collection.toLowerCase() === asset.collection.collection_name.toLowerCase()
        );
        results.push({
          asset_id: asset.asset_id,
          collection_name: asset.collection.collection_name,
          schema_name: asset.schema.schema_name,
          template_id: asset.template.template_id,
          template_name: asset.template.immutable_data.name || null,
          img: asset.template.immutable_data.img || null,
          trash_fee: match?.trash_fee ?? null,
          cinder_reward: match?.cinder_reward ?? null,
        });
      }
    }
  }

  return results;
};
