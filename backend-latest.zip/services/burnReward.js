import axios from 'axios';
import { fetchUserPools } from '../routes/alcorPools.js'; // Import Alcor pool functions

// WAX Blockchain RPC
const WAX_RPC = 'https://wax.pink.gg';
const CONTRACT_NAME = 'cleanupcentr';
const TABLE_NAME_APPROVED = 'approvednfts';
const TABLE_NAME_PROPOSALS = 'proposals';
const NFT_PRICE_API = 'https://maestrobeatz.servegame.com:3003/nft-prices/top5';

/**
 * Fetches approved NFT templates from the `approvednfts` table in the cleanupcentr contract.
 * @returns {Promise<number[]>} - List of approved template IDs.
 */
async function getApprovedTemplates() {
    try {
        const response = await axios.post(`${WAX_RPC}/v1/chain/get_table_rows`, {
            json: true,
            code: CONTRACT_NAME,
            scope: CONTRACT_NAME,
            table: TABLE_NAME_APPROVED,
            limit: 1000
        });

        return response.data.rows.map(row => row.template_id);
    } catch (error) {
        console.error('Error fetching approved NFTs from blockchain:', error);
        return [];
    }
}

/**
 * Fetches reward information for an NFT from the `proposals` table.
 * @param {number} templateId - The template ID of the NFT.
 * @returns {Promise<{cinder: number} | null>} - Reward values or null if not found.
 */
async function getProposalReward(templateId) {
    try {
        const response = await axios.post(`${WAX_RPC}/v1/chain/get_table_rows`, {
            json: true,
            code: CONTRACT_NAME,
            scope: CONTRACT_NAME,
            table: TABLE_NAME_PROPOSALS,
            limit: 1000
        });

        const proposal = response.data.rows.find(row => row.template_id === templateId && row.status === "approved");

        if (!proposal) {
            console.error(`No approved proposal found for template ID ${templateId}.`);
            return null;
        }

        return {
            cinder: parseFloat(proposal.cinder_reward.split(' ')[0]) // Extracts numeric value from "1.000000 CINDER"
        };
    } catch (error) {
        console.error('Error fetching proposal rewards from blockchain:', error);
        return null;
    }
}

/**
 * Fetches the latest CINDER/WAX exchange rate from Alcor liquidity pools.
 * @returns {Promise<number>} - Conversion rate of 1 CINDER to WAX.
 */
async function getCinderToWaxRate() {
    try {
        // Get all pools user has added liquidity to
        const pools = await fetchUserPools('swap.alcor'); // Query swap.alcor pools

        // Find CINDER/WAX pool
        const cinderPool = pools.find(pool => 
            pool.positions.some(pos => pos.poolId && pos.poolId.includes('CINDER'))
        );

        if (!cinderPool) {
            console.warn('⚠️ CINDER/WAX pool not found. Using fallback price.');
            return 0.035; // Default fallback price
        }

        // Extract WAX per CINDER price from liquidity positions
        const totalWax = cinderPool.positions.reduce((acc, pos) => acc + parseFloat(pos.base_reserve), 0);
        const totalCinder = cinderPool.positions.reduce((acc, pos) => acc + parseFloat(pos.quote_reserve), 0);

        if (!totalCinder || !totalWax) {
            console.warn('⚠️ Invalid CINDER/WAX liquidity data. Using fallback price.');
            return 0.035;
        }

        const price = totalWax / totalCinder;
        console.log(`✅ Found CINDER/WAX liquidity pool price: ${price} WAX per CINDER`);
        return price;
    } catch (error) {
        console.error('❌ Error fetching CINDER/WAX pool price:', error);
        return 0.035; // Use fallback price if request fails
    }
}

/**
 * Fetches the lowest market price of an NFT.
 * @param {number} templateId - The template ID of the NFT.
 * @returns {Promise<number>} - Lowest price in WAX.
 */
async function getLowestMarketPrice(templateId) {
    try {
        const response = await axios.get(`${NFT_PRICE_API}/${templateId}`);
        const prices = response.data;
        return prices.length > 0 ? parseFloat(prices[0].price) : null;
    } catch (error) {
        console.error(`Error fetching NFT price for template ${templateId}:`, error);
        return null;
    }
}

/**
 * Calculates the burn reward for an NFT based on blockchain data and market comparison.
 * @param {number} templateId - The template ID of the NFT.
 * @returns {Promise<{wax: number, cinder: number} | null>} - Burn rewards or null if error occurs.
 */
async function calculateBurnReward(templateId) {
    const approvedTemplates = await getApprovedTemplates();
    if (!approvedTemplates.includes(templateId)) {
        console.error(`Template ID ${templateId} is not approved for burning.`);
        return null;
    }

    const proposalReward = await getProposalReward(templateId);
    if (!proposalReward) {
        console.error(`No reward data found for template ID ${templateId}.`);
        return null;
    }

    const cinderToWaxRate = await getCinderToWaxRate();
    if (!cinderToWaxRate) {
        console.error('Failed to fetch CINDER/WAX conversion rate.');
        return null;
    }

    const marketPriceWax = await getLowestMarketPrice(templateId);
    if (!marketPriceWax) {
        console.error(`No market price found for template ID ${templateId}.`);
        return null;
    }

    // Convert CINDER reward to WAX
    const burnRewardWax = proposalReward.cinder * cinderToWaxRate;

    // Compare WAX reward with market price (80% of NFT price)
    const marketRewardWax = marketPriceWax * 0.8;
    const finalWaxReward = Math.min(burnRewardWax, marketRewardWax);

    return {
        wax: parseFloat(finalWaxReward.toFixed(4)),  // Ensure 4 decimal places for WAX
        cinder: proposalReward.cinder  // Already correctly formatted
    };
}

// Export function for backend usage
export { calculateBurnReward };
