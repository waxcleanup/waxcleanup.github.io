import { rpc, api } from './eosService.js';
import axios from 'axios';

// Fetch farmers from the blockchain (testnet only)
const getBlockchainFarmers = async () => {
  try {
    console.log('Fetching farmers from the blockchain (testnet)');
    const result = await rpc.testnet.get_table_rows({
      json: true,
      code: 'maestrobeatz',
      scope: 'maestrobeatz',
      table: 'farmers',
      limit: 1000,
    });
    return result.rows;
  } catch (error) {
    console.error('Error fetching farmers from the testnet blockchain:', error);
    throw error;
  }
};

// Function to search accounts by public key on testnet
const searchAccountsByPublicKey = async (publicKey) => {
  console.log(`Searching for accounts with public key (testnet): ${publicKey}`);
  if (!publicKey.startsWith('EOS') && !publicKey.startsWith('PUB_K1_')) return [];
  try {
    const result = await axios.post(`${rpc.testnet.endpoint}/v1/chain/get_accounts_by_authorizers`, {
      keys: [publicKey],
    });
    const accounts = result.data?.accounts?.map(acc => acc.account_name) || [];
    return accounts;
  } catch (error) {
    console.error('Error fetching account by public key (testnet):', error);
    return [];
  }
};

// Cleanup-related functions (mainnet only)

// Function to create a proposal on mainnet
const createProposal = async (user, description, collection, schema, templateId, trashFee, cinderReward) => {
  try {
    const result = await api.mainnet.transact({
      actions: [{
        account: 'cleanupcentr',
        name: 'createprop',
        authorization: [{ actor: user, permission: 'active' }],
        data: { proposer: user, description, collection, schema, template_id: templateId, trash_fee: trashFee, cinder_reward: cinderReward },
      }]
    }, { blocksBehind: 3, expireSeconds: 30 });
    return result;
  } catch (error) {
    console.error('Error creating proposal:', error);
    throw error;
  }
};

// Function to verify a proposal on mainnet
const verifyProposal = async (propId) => {
  try {
    const result = await api.mainnet.transact({
      actions: [{
        account: 'cleanupcentr',
        name: 'verifyprop',
        authorization: [{ actor: 'cleanuptoken', permission: 'active' }],
        data: { prop_id: propId },
      }]
    }, { blocksBehind: 3, expireSeconds: 30 });
    return result;
  } catch (error) {
    console.error('Error verifying proposal:', error);
    throw error;
  }
};

// Function to vote on a proposal on mainnet
const voteProposal = async (voter, propId, voteFor) => {
  try {
    const result = await api.mainnet.transact({
      actions: [{
        account: 'cleanupcentr',
        name: 'voteprop',
        authorization: [{ actor: voter, permission: 'active' }],
        data: { voter, prop_id: propId, vote_for: voteFor },
      }]
    }, { blocksBehind: 3, expireSeconds: 30 });
    return result;
  } catch (error) {
    console.error('Error voting on proposal:', error);
    throw error;
  }
};

// Function to execute an approved proposal on mainnet
const executeProposal = async (propId) => {
  try {
    const result = await api.mainnet.transact({
      actions: [{
        account: 'cleanupcentr',
        name: 'execprop',
        authorization: [{ actor: 'cleanupcentr', permission: 'active' }],
        data: { prop_id: propId },
      }]
    }, { blocksBehind: 3, expireSeconds: 30 });
    return result;
  } catch (error) {
    console.error('Error executing proposal:', error);
    throw error;
  }
};

// Function to burn an NFT on mainnet
const burnNFT = async (user, assetId, collection, schema, templateId) => {
  try {
    const result = await api.mainnet.transact({
      actions: [{
        account: 'cleanupcentr',
        name: 'burnnft',
        authorization: [{ actor: user, permission: 'active' }],
        data: { user, asset_id: assetId, collection, schema, template_id: templateId },
      }]
    }, { blocksBehind: 3, expireSeconds: 30 });
    return result;
  } catch (error) {
    console.error('Error burning NFT:', error);
    throw error;
  }
};

// Function to finalize NFT burn and distribute CINDER reward on mainnet
const finalizeBurn = async (burnId) => {
  try {
    const result = await api.mainnet.transact({
      actions: [{
        account: 'cleanupcentr',
        name: 'finalizeburn',
        authorization: [{ actor: 'cleanupcentr', permission: 'active' }],
        data: { burn_id: burnId },
      }]
    }, { blocksBehind: 3, expireSeconds: 30 });
    return result;
  } catch (error) {
    console.error('Error finalizing burn:', error);
    throw error;
  }
};

// Function to add an approved template for NFT burning on mainnet
const addApprovedTemplate = async (account, collection, schema, templateId) => {
  try {
    const result = await api.mainnet.transact({
      actions: [{
        account: 'cleanupcentr',
        name: 'addapproved',
        authorization: [{ actor: account, permission: 'active' }],
        data: { account, collection, schema, template_id: templateId },
      }]
    }, { blocksBehind: 3, expireSeconds: 30 });
    return result;
  } catch (error) {
    console.error('Error adding approved template:', error);
    throw error;
  }
};

// Function to fetch WAX or other token balances from mainnet
const getTokenBalance = async (accountName, tokenSymbol = 'WAX') => {
  try {
    const result = await rpc.mainnet.get_currency_balance('eosio.token', accountName, tokenSymbol);
    return result[0] || `0.00000000 ${tokenSymbol}`;
  } catch (error) {
    console.error(`Error fetching ${tokenSymbol} balance:`, error);
    throw new Error(`Failed to fetch ${tokenSymbol} balance.`);
  }
};

// Function to fetch table rows from blockchain
const getTableRows = async (code, scope, table, limit = 10, isTestnet = false) => {
  try {
    const selectedRpc = isTestnet ? rpc.testnet : rpc.mainnet;
    const result = await selectedRpc.get_table_rows({
      json: true,
      code,
      scope,
      table,
      limit,
    });
    return result.rows;
  } catch (error) {
    console.error('Error fetching table rows:', error);
    throw new Error('Failed to fetch table rows.');
  }
};
// Function to fetch approved collections from the mainnet
const getApprovedCollections = async () => {
  try {
    const result = await rpc.mainnet.get_table_rows({
      json: true,
      code: 'cleanupcentr',       // Contract that holds approved collections
      scope: 'cleanupcentr',      // Scope under the same contract
      table: 'approvednfts',      // Ensure this table name is correct
      limit: 100
    });
    return result.rows;
  } catch (error) {
    console.error('Error fetching approved collections:', error);
    throw new Error('Failed to fetch approved collections.');
  }
};

// Function to stake an incinerator on mainnet
const verifyAssetOwnership = async (user, assetId) => {
  try {
    // Query the asset from the atomicassets table
    const result = await rpc.mainnet.get_table_rows({
      json: true,
      code: 'atomicassets', // AtomicAssets contract name
      scope: user,         // User's account name
      table: 'assets',     // Table storing NFT assets
      limit: 1,
      lower_bound: assetId,
      upper_bound: assetId,
    });

    const asset = result.rows[0];
    if (!asset || asset.asset_id !== assetId.toString()) {
      throw new Error(`Asset ID ${assetId} not found or doesn't belong to user ${user}.`);
    }
    console.log(`Asset ID ${assetId} verified for user ${user}.`);
    return asset; // Return asset data if valid
  } catch (error) {
    console.error(`Error verifying asset ID ${assetId}:`, error);
    throw new Error('Failed to verify asset ownership.');
  }
};

const stakeIncinerator = async (user, assetId) => {
  try {
    if (!user || !assetId) {
      throw new Error('User and assetId are required to stake an incinerator.');
    }

    console.log(`Verifying asset ID ${assetId} for user ${user}...`);
    await verifyAssetOwnership(user, assetId);

    console.log(`Staking incinerator: user=${user}, assetId=${assetId}`);

    const result = await api.mainnet.transact({
      actions: [{
        account: 'cleanupcentr',
        name: 'stakeincin',
        authorization: [{ actor: user, permission: 'active' }],
        data: { user, incinerator_id: assetId },
      }]
    }, { blocksBehind: 3, expireSeconds: 30 });

    console.log(`Successfully staked incinerator: assetId=${assetId}`);
    return result;
  } catch (error) {
    console.error('Error staking incinerator:', error);
    throw error;
  }
};

export {
  getBlockchainFarmers,
  searchAccountsByPublicKey,
  createProposal,
  verifyProposal,
  voteProposal,
  executeProposal,
  burnNFT,
  finalizeBurn,
  addApprovedTemplate,
  getTokenBalance,
  getTableRows,
  stakeIncinerator,
  getApprovedCollections // Add this to the export
};
