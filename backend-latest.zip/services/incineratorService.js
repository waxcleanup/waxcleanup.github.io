// services/incineratorService.js
import { Api, JsonRpc, RpcError } from 'eosjs';
import { JsSignatureProvider } from 'eosjs/dist/eosjs-jssig.js';
import fetch from 'node-fetch';
import axios from 'axios';
import dotenv from 'dotenv';

dotenv.config();

// ----------------- RPC / API SETUP -----------------

const rpcEndpoint = process.env.WAX_MAINNET_API;
if (!rpcEndpoint) {
  console.warn('[incineratorService] WAX_MAINNET_API is not set in environment!');
}

const rpc = new JsonRpc(rpcEndpoint, { fetch });

const signatureProvider = new JsSignatureProvider(
  [process.env.MAINNET_PRIVATE_KEY_CLEANUPCENTR].filter(Boolean)
);

const api = new Api({
  rpc,
  signatureProvider,
  textDecoder: new TextDecoder(),
  textEncoder: new TextEncoder()
});

const ATOMIC_BASE =
  (process.env.ATOMICASSETS_MAINNET_API_ENDPOINT ||
    'https://atomic-api.wax.cryptolions.io')
    .replace(/\/+$/, '') + '/atomicassets/v1';

// ----------------- HELPERS -----------------

/**
 * Fetch *all* rows from atomicassets::assets for a given owner,
 * paginating by asset_id until there are no more pages.
 */
async function fetchAllAtomicAssetsForOwner(owner) {
  let allRows = [];
  let lower = '0';
  let page = 1;

  // console.log(`[incineratorService] Fetching atomicassets::assets for ${owner}`);

  while (true) {
    const res = await rpc.get_table_rows({
      json: true,
      code: 'atomicassets',
      scope: owner,
      table: 'assets',
      lower_bound: lower,
      limit: 1000,
      index_position: 1,
      key_type: 'i64'
    });

    const rows = res.rows || [];
    allRows = allRows.concat(rows);

    if (!res.more || rows.length === 0) {
      break;
    }

    const last = rows[rows.length - 1];
    const lastIdBigInt = BigInt(last.asset_id.toString());
    lower = (lastIdBigInt + 1n).toString();
    page += 1;
  }

  // console.log(`[incineratorService] Total rows for ${owner}: ${allRows.length}`);
  return allRows;
}

// ----------------- UNSTAKED INCINERATORS -----------------

/**
 * Fetch all *unstaked* incinerator NFTs owned by `accountName`,
 * using the on-chain atomicassets::assets table for ownership,
 * and the AtomicAssets HTTP API for template metadata.
 */
export const fetchUnstakedIncinerators = async (accountName) => {
  if (!accountName) {
    throw new Error('[incineratorService] fetchUnstakedIncinerators: missing accountName');
  }

  const rows = await fetchAllAtomicAssetsForOwner(accountName);

  // Filter to your collection & schema
  const assets = rows.filter(
    (row) =>
      row.collection_name === 'cleanupcentr' &&
      row.schema_name === 'incinerators'
  );

  if (assets.length === 0) {
    return [];
  }

  const tids = [
    ...new Set(
      assets
        .map((a) => a.template_id)
        .filter((t) => t !== null && t !== undefined)
    )
  ];

  const metas = {};
  await Promise.all(
    tids.map(async (tid) => {
      try {
        const resp = await axios.get(`${ATOMIC_BASE}/templates/cleanupcentr/${tid}`);
        const tpl = resp.data?.data;
        metas[tid] = tpl?.immutable_data || {};
      } catch (err) {
        console.error(
          `[incineratorService] unstaked tpl ${tid} meta fetch fail:`,
          err.message
        );
        metas[tid] = {};
      }
    })
  );

  return assets.map((a) => {
    const md = metas[a.template_id] || {};
    return {
      asset_id:    String(a.asset_id),
      template_id: a.template_id,
      name:        md.name || null,
      imgCid:      md.img || null,
      description: md.Description || null,
      type:        md.Type || null,
      rarity:      md.Rarity || null,
      fuelType:    md.Fuel || null,
      energyCap:   Number(md['Energy Capacity'] || 0),
      fuelCap:     Number(md['Fuel Capacity'] || 0)
    };
  });
};

/**
 * Fetch all *staked* incinerators (on-chain table) for `accountName`,
 * and hydrate them with AtomicAssets template metadata (same style as unstaked).
 */
export const fetchStakedIncinerators = async (accountName) => {
  if (!accountName) {
    throw new Error('[incineratorService] fetchStakedIncinerators: missing accountName');
  }

  // Read from your contract table
  const { rows } = await rpc.get_table_rows({
    json: true,
    code: 'cleanupcentr',
    scope: 'cleanupcentr',
    table: 'incinerators',
    index_position: 2,
    key_type: 'i64',
    lower_bound: accountName,
    upper_bound: accountName,
    limit: 100
  });

  if (!rows || rows.length === 0) {
    return [];
  }

  // Unique template IDs from the contract table
  const tids = [
    ...new Set(
      rows
        .map((r) => r.template_id)
        .filter((t) => t !== null && t !== undefined)
    ),
  ];

  const metas = {};
  await Promise.all(
    tids.map(async (tid) => {
      try {
        const tpl = (
          await axios.get(`${ATOMIC_BASE}/templates/cleanupcentr/${tid}`)
        ).data.data;

        metas[tid] = tpl?.immutable_data || {};
      } catch (err) {
        console.error(
          `[incineratorService] staked tpl ${tid} meta fetch fail:`,
          err.message
        );
        metas[tid] = {};
      }
    })
  );

  // Map rows + merged metadata into the shape the frontend expects
  return rows.map((r) => {
    const md = metas[r.template_id] || {};

    return {
      id:          r.id,
      asset_id:    String(r.id),
      owner:       r.owner,
      fuel:        r.fuel,
      energy:      r.energy,
      durability:  r.durability,
      template_id: r.template_id,
      locked:      r.locked || 0,

      // metadata – same keys as unstaked
      name:        md.name || null,
      imgCid:      md.img  || null,
      description: md.Description || null,
      type:        md.Type        || null,
      rarity:      md.Rarity      || null,
      fuelType:    md.Fuel        || null,
      energyCap:   Number(md['Energy Capacity'] || 0),
      fuelCap:     Number(md['Fuel Capacity']   || 0),
    };
  });
};

/**
 * Push a `returnicin` action to unstake (return) an incinerator.
 */
export const unstakeIncinerator = async (owner, incineratorId) => {
  try {
    const result = await api.transact(
      {
        actions: [
          {
            account: 'cleanupcentr',
            name: 'returnicin',
            authorization: [
              {
                actor: 'cleanupcentr',
                permission: 'active'
              }
            ],
            data: {
              owner,
              incinerator_id: incineratorId
            }
          }
        ]
      },
      {
        blocksBehind: 3,
        expireSeconds: 30
      }
    );

    return result;
  } catch (error) {
    if (error instanceof RpcError && error.json?.error?.details) {
      for (const d of error.json.error.details) {
        console.error(`→ ${d.message}`);
      }
    } else {
      console.error(
        '[incineratorService] Failed to unstake incinerator:',
        error.message || error
      );
    }
    throw new Error('Transaction failed.');
  }
};
