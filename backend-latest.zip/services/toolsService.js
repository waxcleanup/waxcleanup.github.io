// /home/ubuntu/backend/services/toolsService.js
import { rpc } from '../utils/eosApi.js';
import axios from 'axios';

const CONTRACT = process.env.RHYTHM_CONTRACT || 'rhythmfarmer';

// ✅ Use your standard env var (base host) and append /atomicassets/v1
// Example env: ATOMICASSETS_MAINNET_API_ENDPOINT=https://atomic-api.wax.cryptolions.io
const ATOMIC_HOST =
  process.env.ATOMICASSETS_MAINNET_API_ENDPOINT || 'https://atomic-api.wax.cryptolions.io';
const ATOMIC_API = `${ATOMIC_HOST.replace(/\/$/, '')}/atomicassets/v1`;

// In-memory cache for asset metadata
const assetCache = new Map(); // asset_id -> meta
const assetCacheTs = new Map(); // asset_id -> timestamp ms
const CACHE_TTL_MS = 10 * 60 * 1000; // 10 minutes

function nowMs() {
  return Date.now();
}

function getCached(assetId) {
  const id = String(assetId);
  const ts = assetCacheTs.get(id);
  if (!ts) return null;
  if (nowMs() - ts > CACHE_TTL_MS) {
    assetCache.delete(id);
    assetCacheTs.delete(id);
    return null;
  }
  return assetCache.get(id) || null;
}

function setCached(assetId, data) {
  const id = String(assetId);
  assetCache.set(id, data);
  assetCacheTs.set(id, nowMs());
}

// Normalize AtomicAssets img field → URL
function normalizeImgUrl(a) {
  // CryptoLions returns useful fields inside `data` as well
  const img =
    a?.data?.img ||
    a?.data?.image ||
    a?.img ||
    a?.image ||
    a?.immutable_data?.img ||
    a?.immutable_data?.image ||
    a?.mutable_data?.img ||
    a?.mutable_data?.image ||
    a?.template?.immutable_data?.img ||
    a?.template?.immutable_data?.image ||
    null;

  if (!img) return null;

  if (typeof img === 'string' && (img.startsWith('http://') || img.startsWith('https://'))) return img;
  if (typeof img === 'string' && img.startsWith('ipfs://')) return `https://ipfs.io/ipfs/${img.slice(7)}`;
  if (typeof img === 'string' && img.startsWith('Qm')) return `https://ipfs.io/ipfs/${img}`;

  return img;
}

/**
 * AtomicAssets asset lookup by asset_id
 */
async function fetchAssetMeta(assetId) {
  const id = String(assetId);

  const cached = getCached(id);
  if (cached) return cached;

  const url = `${ATOMIC_API}/assets/${id}`;

  try {
    const resp = await axios.get(url, {
      timeout: 10_000,
      validateStatus: () => true,
    });

    if (resp.status !== 200) {
      console.log(`⚠️ AtomicAssets HTTP ${resp.status} for asset=${id} url=${url}`);
      const fallback = {
        asset_id: id,
        name: null,
        rarity: 'Unknown',
        img: null,
        immutable_data: {},
        mutable_data: {},
        collection_name: null,
        schema_name: null,
      };
      setCached(id, fallback);
      return fallback;
    }

    const payload = resp.data;
    if (!payload || payload.success !== true || !payload.data) {
      console.log(
        `⚠️ AtomicAssets bad payload for asset=${id} url=${url} resp=${JSON.stringify(payload).slice(0, 180)}`
      );
      const fallback = {
        asset_id: id,
        name: null,
        rarity: 'Unknown',
        img: null,
        immutable_data: {},
        mutable_data: {},
        collection_name: null,
        schema_name: null,
      };
      setCached(id, fallback);
      return fallback;
    }

    const a = payload.data;

    // ✅ CryptoLions puts the "real" fields in a.data (and also a.name)
    const name =
      a?.data?.name ||
      a?.name ||
      a?.template?.immutable_data?.name ||
      a?.immutable_data?.name ||
      a?.immutable_data?.title ||
      null;

    // ✅ Your schema uses "Rarity" (capital R) in template/asset data
    const rarity =
      a?.data?.Rarity ||
      a?.template?.immutable_data?.Rarity ||
      a?.immutable_data?.rarity ||
      a?.mutable_data?.rarity ||
      a?.immutable_data?.tier ||
      a?.mutable_data?.tier ||
      'Unknown';

    // Prefer `a.data` because that’s where CryptoLions puts schema fields
    const immutable_data = a?.data || a?.immutable_data || {};
    const mutable_data = a?.mutable_data || {};

    const meta = {
      asset_id: id,
      name,
      rarity,
      img: normalizeImgUrl(a),
      immutable_data,
      mutable_data,
      collection_name: a?.collection?.collection_name || a?.collection_name || null,
      schema_name: a?.schema?.schema_name || a?.schema_name || null,
      template_id: a?.template?.template_id || a?.template_id || null,
    };

    setCached(id, meta);
    return meta;
  } catch (e) {
    console.log(`❌ AtomicAssets lookup threw asset=${id} url=${url} err=${e?.message || e}`);
    const fallback = {
      asset_id: id,
      name: null,
      rarity: 'Unknown',
      img: null,
      immutable_data: {},
      mutable_data: {},
      collection_name: null,
      schema_name: null,
    };
    setCached(id, fallback);
    return fallback;
  }
}

/**
 * Fetch table rows with pagination support.
 */
async function fetchAll({
  code,
  scope,
  table,
  lower_bound,
  upper_bound,
  limit = 1000,
}) {
  const rows = [];
  let more = true;
  let next_key;

  while (more) {
    const res = await rpc.get_table_rows({
      json: true,
      code,
      scope,
      table,
      limit,
      ...(lower_bound !== undefined ? { lower_bound } : {}),
      ...(upper_bound !== undefined ? { upper_bound } : {}),
      ...(next_key ? { lower_bound: next_key } : {}),
    });

    rows.push(...(res.rows || []));
    more = !!res.more;
    next_key = res.next_key;
    if (!more) break;
    if (!next_key) break;
  }

  return rows;
}

/**
 * Tools that are staked (tools table) but NOT equipped (equipped table)
 * + enriched metadata.
 */
export async function getUnequippedStakedTools(owner) {
  // 1) Pull tools table and filter by owner
  const allTools = await fetchAll({
    code: CONTRACT,
    scope: CONTRACT,
    table: 'tools',
    limit: 1000,
  });

  const staked = (allTools || []).filter((t) => String(t.owner) === String(owner));

  // 2) Pull equipped row
  const equippedRows = await fetchAll({
    code: CONTRACT,
    scope: CONTRACT,
    table: 'equipped',
    lower_bound: owner,
    upper_bound: owner,
    limit: 10,
  });

  const equippedSet = new Set();
  if (equippedRows.length) {
    const eq = equippedRows[0];
    if (eq.watering_tool && String(eq.watering_tool) !== '0') equippedSet.add(String(eq.watering_tool));
    if (eq.harvesting_tool && String(eq.harvesting_tool) !== '0') equippedSet.add(String(eq.harvesting_tool));
  }

  // 3) Filter unequipped
  const unequipped = staked.filter((t) => !equippedSet.has(String(t.asset_id)));

  // 4) Enrich by asset_id
  const metas = await Promise.all(unequipped.map((t) => fetchAssetMeta(t.asset_id)));
  const metaByAsset = new Map(metas.map((m) => [String(m.asset_id), m]));

  return unequipped.map((t) => {
    const meta = metaByAsset.get(String(t.asset_id)) || {};
    return {
      ...t,
      name: meta.name || null,
      rarity: meta.rarity || 'Unknown',
      img: meta.img || null,
      immutable_data: meta.immutable_data || {},
      mutable_data: meta.mutable_data || {},
      collection_name: meta.collection_name || null,
      schema_name: meta.schema_name || null,
    };
  });
}
