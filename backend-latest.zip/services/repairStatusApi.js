// src/services/repairStatusApi.js
import { JsonRpc } from 'eosjs';
import fetch from 'node-fetch';

const endpoint = process.env.REACT_APP_RPC || 'https://wax.eosusa.io';
const rpc = new JsonRpc(endpoint, { fetch });

export async function getRepairStatus(incineratorId) {
  try {
    const result = await rpc.get_table_rows({
      json: true,
      code: process.env.REACT_APP_CONTRACT_NAME || 'cleanupcentr',
      scope: process.env.REACT_APP_CONTRACT_NAME || 'cleanupcentr',
      table: 'repairtrack',
      lower_bound: incineratorId,
      upper_bound: incineratorId,
      limit: 1,
    });

    const row = result.rows[0];
    if (!row || row.incinerator_id !== Number(incineratorId)) return null;

    return {
      user: row.user,
      repair_points: row.repair_points,
      repair_time: new Date(row.repair_time / 1000).toISOString(), // convert microseconds to ms
    };
  } catch (error) {
    console.error('[ERROR] Fetching repair status failed:', error);
    return null;
  }
}
