import { waxRpc } from '../utils/eosApi.js';
import AtomicAssetsDeserializer from '../services/AtomicAssetsDeserializer.js';

// simple in-memory cache (resets on restart)
const templateCache = new Map();

function cacheKey(collection, templateId) {
  return `${String(collection)}:${String(templateId)}`;
}

export async function getTemplateMeta(collection, templateId) {
  const key = cacheKey(collection, templateId);
  if (templateCache.has(key)) return templateCache.get(key);

  // 1) Get template row
  const tplRes = await waxRpc.get_table_rows({
    json: true,
    code: 'atomicassets',
    scope: collection,
    table: 'templates',
    lower_bound: String(templateId),
    upper_bound: String(templateId),
    limit: 1,
  });

  const tpl = tplRes.rows?.[0];
  if (!tpl || String(tpl.template_id) !== String(templateId)) {
    templateCache.set(key, null);
    return null;
  }

  // 2) Decode immutable data using AtomicAssetsDeserializer
  // This deserializer typically needs schema format; many projects implement a helper inside it.
  // If your deserializer expects (collection, schema, data), we can adapt.
  let decoded = {};
  try {
    decoded = await AtomicAssetsDeserializer.deserializeTemplateImmutableData({
      collection_name: collection,
      schema_name: tpl.schema_name,
      immutable_serialized_data: tpl.immutable_serialized_data,
    });
  } catch (e) {
    // If your deserializer exposes a different method name, we’ll adjust.
    decoded = {};
  }

  const meta = {
    name: decoded?.name || tpl.name || null,
    img: decoded?.img || decoded?.image || null,
    schema_name: tpl.schema_name,
  };

  templateCache.set(key, meta);
  return meta;
}
