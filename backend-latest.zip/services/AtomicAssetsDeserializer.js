// AtomicAssetsDeserializer.js

/**
 * Validates if the fields from the schema match expected types.
 * @param {Array} fields - The fields array from the schema.
 */
export const validateFields = (fields) => {
  if (!Array.isArray(fields) || fields.length === 0) {
    throw new Error('Schema fields are missing or invalid.');
  }
};

/**
 * Deserializes binary data into a readable format based on schema fields.
 * @param {Buffer} data - The serialized binary data.
 * @param {Array} fields - The schema fields array.
 * @returns {Object} - The deserialized data.
 */
export const deserialize = (data, fields) => {
  const decoded = {};
  let pointer = 0;

  for (const field of fields) {
    const { name, type } = field;

    switch (type) {
      case 'string':
        const length = data[pointer];
        decoded[name] = String.fromCharCode(...data.slice(pointer + 1, pointer + 1 + length));
        pointer += 1 + length;
        break;

      case 'uint8':
        decoded[name] = data[pointer];
        pointer += 1;
        break;

      case 'uint16':
        decoded[name] = (data[pointer] << 8) | data[pointer + 1];
        pointer += 2;
        break;

      case 'uint32':
        decoded[name] = (data[pointer] << 24) | (data[pointer + 1] << 16) | (data[pointer + 2] << 8) | data[pointer + 3];
        pointer += 4;
        break;

      case 'ipfs':
        const hashLength = 46; // Expected IPFS hash length
        decoded[name] = `https://ipfs.io/ipfs/${String.fromCharCode(...data.slice(pointer, pointer + hashLength))}`;
        pointer += hashLength;
        break;

      default:
        console.warn(`Unhandled type: ${type} for field: ${name}`);
    }
  }

  return decoded;
};
export default {
  validateFields,
  deserialize,
};
