import { rpc, api } from './eosService.js';
import axios from 'axios';

// Fetch farmers from the blockchain (testnet only)
const getBlockchainFarmers = async () => {
  try {
    console.log('Fetching farmers from the blockchain (testnet)');
    const result = await rpc.testnet.get_table_rows({
      json: true,
      code: 'maestrobeatz',
      scope: 'maestrobeatz',
      table: 'farmers',
      limit: 1000,
    });
    return result.rows;
  } catch (error) {
    console.error('Error fetching farmers from the testnet blockchain:', error);
    throw error;
  }
};

// Function to search accounts by public key on testnet
const searchAccountsByPublicKey = async (publicKey) => {
  console.log(`Searching for accounts with public key (testnet): ${publicKey}`);
  if (!publicKey.startsWith('EOS') && !publicKey.startsWith('PUB_K1_')) return [];
  try {
    const result = await axios.post(`${rpc.testnet.endpoint}/v1/chain/get_accounts_by_authorizers`, {
      keys: [publicKey],
    });
    const accounts = result.data?.accounts?.map(acc => acc.account_name) || [];
    return accounts;
  } catch (error) {
    console.error('Error fetching account by public key (testnet):', error);
    return [];
  }
};

// Cleanup-related functions (mainnet only)

// Function to create a proposal on mainnet
const createProposal = async (user, description, collection, schema, templateId, trashFee, cinderReward) => {
  try {
    const result = await api.mainnet.transact({
      actions: [{
        account: 'cleanupcentr',
        name: 'createprop',
        authorization: [{ actor: user, permission: 'active' }],
        data: { proposer: user, description, collection, schema, template_id: templateId, trash_fee: trashFee, cinder_reward: cinderReward },
      }]
    }, { blocksBehind: 3, expireSeconds: 30 });
    return result;
  } catch (error) {
    console.error('Error creating proposal:', error);
    throw error;
  }
};

// Function to verify a proposal on mainnet
const verifyProposal = async (propId) => {
  try {
    const result = await api.mainnet.transact({
      actions: [{
        account: 'cleanupcentr',
        name: 'verifyprop',
        authorization: [{ actor: 'cleanuptoken', permission: 'active' }],
        data: { prop_id: propId },
      }]
    }, { blocksBehind: 3, expireSeconds: 30 });
    return result;
  } catch (error) {
    console.error('Error verifying proposal:', error);
    throw error;
  }
};

// Function to vote on a proposal on mainnet
const voteProposal = async (voter, propId, voteFor) => {
  try {
    const result = await api.mainnet.transact({
      actions: [{
        account: 'cleanupcentr',
        name: 'voteprop',
        authorization: [{ actor: voter, permission: 'active' }],
        data: { voter, prop_id: propId, vote_for: voteFor },
      }]
    }, { blocksBehind: 3, expireSeconds: 30 });
    return result;
  } catch (error) {
    console.error('Error voting on proposal:', error);
    throw error;
  }
};

// Function to execute an approved proposal on mainnet
const executeProposal = async (propId) => {
  try {
    const result = await api.mainnet.transact({
      actions: [{
        account: 'cleanupcentr',
        name: 'execprop',
        authorization: [{ actor: 'cleanupcentr', permission: 'active' }],
        data: { prop_id: propId },
      }]
    }, { blocksBehind: 3, expireSeconds: 30 });
    return result;
  } catch (error) {
    console.error('Error executing proposal:', error);
    throw error;
  }
};

// Function to burn an NFT on mainnet
const burnNFT = async (user, assetId, collection, schema, templateId) => {
  try {
    const result = await api.mainnet.transact({
      actions: [{
        account: 'cleanupcentr',
        name: 'burnnft',
        authorization: [{ actor: user, permission: 'active' }],
        data: { user, asset_id: assetId, collection, schema, template_id: templateId },
      }]
    }, { blocksBehind: 3, expireSeconds: 30 });
    return result;
  } catch (error) {
    console.error('Error burning NFT:', error);
    throw error;
  }
};

// Function to finalize NFT burn and distribute CINDER reward on mainnet
const finalizeBurn = async (burnId) => {
  try {
    const result = await api.mainnet.transact({
      actions: [{
        account: 'cleanupcentr',
        name: 'finalizeburn',
        authorization: [{ actor: 'cleanupcentr', permission: 'active' }],
        data: { burn_id: burnId },
      }]
    }, { blocksBehind: 3, expireSeconds: 30 });
    return result;
  } catch (error) {
    console.error('Error finalizing burn:', error);
    throw error;
  }
};

// Function to add an approved template for NFT burning on mainnet
const addApprovedTemplate = async (account, collection, schema, templateId) => {
  try {
    const result = await api.mainnet.transact({
      actions: [{
        account: 'cleanupcentr',
        name: 'addapproved',
        authorization: [{ actor: account, permission: 'active' }],
        data: { account, collection, schema, template_id: templateId },
      }]
    }, { blocksBehind: 3, expireSeconds: 30 });
    return result;
  } catch (error) {
    console.error('Error adding approved template:', error);
    throw error;
  }
};

// Function to fetch WAX or other token balances from mainnet
const getTokenBalance = async (accountName, tokenSymbol = 'WAX') => {
  try {
    const result = await rpc.mainnet.get_currency_balance('eosio.token', accountName, tokenSymbol);
    return result[0] || `0.00000000 ${tokenSymbol}`;
  } catch (error) {
    console.error(`Error fetching ${tokenSymbol} balance:`, error);
    throw new Error(`Failed to fetch ${tokenSymbol} balance.`);
  }
};

// Function to fetch table rows from blockchain
const getTableRows = async (code, scope, table, limit = 1000, lowerBound = 0, isTestnet = false) => {
  try {
    const selectedRpc = isTestnet ? rpc.testnet : rpc.mainnet;
    let rows = [];
    let more = true;

    console.log(`Fetching rows for table "${table}" from contract "${code}"...`);

    while (more) {
      console.log(`Fetching rows with lower_bound=${lowerBound}, limit=${limit}`);
      const result = await selectedRpc.get_table_rows({
        json: true,
        code,
        scope,
        table,
        limit,
        lower_bound: lowerBound,
      });

      console.log("Blockchain response:", result);

      // Validate response
      if (!result || !result.rows) {
        throw new Error(`Invalid response from blockchain: ${JSON.stringify(result)}`);
      }

      rows.push(...result.rows); // Append fetched rows
      more = result.more || false; // Check if more rows are available
      lowerBound = result.next_key || null; // Update lower bound for the next query

      console.log(`Fetched ${result.rows.length} rows. More: ${more}, Next Key: ${lowerBound}`);
    }

    console.log(`Total rows fetched: ${rows.length}`);
    return rows;
  } catch (error) {
    console.error("Error in getTableRows:", error.message);
    throw new Error("Failed to fetch table rows.");
  }
};

// Function to fetch approved collections from the mainnet
// UPGRADED: merges tplcaps (cap_total/cap_remaining/enabled/prop_id) into approvednfts list
const getApprovedCollections = async () => {
  try {
    // ---------------------------
    // 1) Fetch ALL approvednfts
    // ---------------------------
    let approvedCollections = [];
    let lowerBound = 0;
    let more = true;

    while (more) {
      console.log(`[approvednfts] Fetching with lower_bound=${lowerBound}`);
      const result = await rpc.mainnet.get_table_rows({
        json: true,
        code: 'cleanupcentr',
        scope: 'cleanupcentr',
        table: 'approvednfts',
        limit: 1000,
        lower_bound: lowerBound,
      });

      if (!result || !result.rows) {
        throw new Error(`Invalid response from blockchain (approvednfts): ${JSON.stringify(result)}`);
      }

      approvedCollections.push(...result.rows);
      more = !!result.more;

      if (more && result.rows.length) {
        // approvednfts has `id` as primary key
        lowerBound = Number(result.rows[result.rows.length - 1].id) + 1;
      } else {
        more = false;
      }

      console.log(`[approvednfts] Fetched ${result.rows.length} rows. More: ${more}`);
    }

    console.log(`[approvednfts] Total fetched: ${approvedCollections.length}`);

    // ---------------------------
    // 2) Fetch ALL tplcaps
    // ---------------------------
    let tplCaps = [];
    let capLowerBound = 0;
    let capMore = true;

    while (capMore) {
      console.log(`[tplcaps] Fetching with lower_bound=${capLowerBound}`);
      const capResult = await rpc.mainnet.get_table_rows({
        json: true,
        code: 'cleanupcentr',
        scope: 'cleanupcentr',
        table: 'tplcaps',     // ✅ confirmed table name in your contract
        limit: 1000,
        lower_bound: capLowerBound,
      });

      if (!capResult || !capResult.rows) {
        throw new Error(`Invalid response from blockchain (tplcaps): ${JSON.stringify(capResult)}`);
      }

      tplCaps.push(...capResult.rows);
      capMore = !!capResult.more;

      if (capMore && capResult.rows.length) {
        // tplcaps primary key is template_id
        capLowerBound = Number(capResult.rows[capResult.rows.length - 1].template_id) + 1;
      } else {
        capMore = false;
      }

      console.log(`[tplcaps] Fetched ${capResult.rows.length} rows. More: ${capMore}`);
    }

    console.log(`[tplcaps] Total fetched: ${tplCaps.length}`);

    // ---------------------------
    // 3) Build cap lookup by template_id
    // ---------------------------
    const capByTemplateId = new Map();
    for (const c of tplCaps) {
      const tid = Number(c.template_id);
      if (!Number.isFinite(tid) || tid <= 0) continue;
      capByTemplateId.set(tid, c);
    }

    // ---------------------------
    // 4) Merge caps into approved list
    // ---------------------------
    const merged = approvedCollections.map((row) => {
      const template_id = Number(row.template_id);
      const cap = Number.isFinite(template_id) ? capByTemplateId.get(template_id) : null;

      return {
        ...row,

        // Add cap fields (null means unlimited / no cap row)
        cap_total: cap ? cap.cap_total : null,
        cap_remaining: cap ? cap.cap_remaining : null,
        enabled: cap ? !!cap.enabled : null,
        prop_id: cap ? cap.prop_id : null,
        updated_at: cap ? (cap.updated_at || null) : null,
      };
    });

    return merged;
  } catch (error) {
    console.error('Error fetching approved collections:', error);
    throw new Error('Failed to fetch approved collections.');
  }
};

// Function to verify asset ownership on mainnet
const verifyAssetOwnership = async (user, assetId) => {
  try {
    const result = await rpc.mainnet.get_table_rows({
      json: true,
      code: 'atomicassets',
      scope: user,
      table: 'assets',
      limit: 1,
      lower_bound: assetId,
      upper_bound: assetId,
    });

    const asset = result.rows[0];
    if (!asset || asset.asset_id !== assetId.toString()) {
      throw new Error(`Asset ID ${assetId} not found or doesn't belong to user ${user}.`);
    }
    console.log(`Asset ID ${assetId} verified for user ${user}.`);
    return asset;
  } catch (error) {
    console.error(`Error verifying asset ID ${assetId}:`, error);
    throw new Error('Failed to verify asset ownership.');
  }
};

const stakeIncinerator = async (user, assetId) => {
  try {
    // Validate user and assetId inputs
    if (typeof user !== 'string' || user.trim() === '') {
      throw new Error('Invalid user format. It must be a non-empty string.');
    }

    const parsedAssetId = Number(assetId);
    if (isNaN(parsedAssetId)) {
      throw new Error('Invalid assetId format. It must be a valid number.');
    }

    console.log(`Verifying ownership of assetId=${parsedAssetId} for user=${user}...`);
    await verifyAssetOwnership(user, parsedAssetId);

    console.log(`Staking incinerator: user=${user}, assetId=${parsedAssetId}`);

    // Use the cleanupcentr account's private key for signing
    const result = await api.mainnet.transact(
      {
        actions: [
          {
            account: 'cleanupcentr',
            name: 'stakeincin',
            authorization: [
              {
                actor: 'cleanupcentr', // cleanupcentr account as the signer
                permission: 'active',
              },
            ],
            data: {
              user, // User for whom the incinerator is being staked
              incinerator_id: parsedAssetId, // The asset ID being staked
            },
          },
        ],
      },
      {
        blocksBehind: 3,
        expireSeconds: 30,
      }
    );

    console.log(`Successfully staked incinerator: assetId=${parsedAssetId}`);
    return {
      transactionId: result.transaction_id,
      blockNum: result.processed.block_num,
      message: `Incinerator with assetId=${parsedAssetId} staked successfully.`,
    };
  } catch (error) {
    console.error('Error staking incinerator:', error);
    throw new Error(`Failed to stake incinerator: ${error.message || 'Unknown error'}`);
  }
};

// Function to fetch schema burn rules (global) from the mainnet
// UPGRADED: merges schemcaps (cap_total/cap_remaining/enabled/prop_id/updated_at) into schemaburns list
const getSchemaBurns = async () => {
  try {
    // ---------------------------
    // 1) Fetch ALL schemaburns
    // ---------------------------
    let rules = [];
    let lowerBound = 0;
    let more = true;

    while (more) {
      console.log(`[schemaburns] Fetching with lower_bound=${lowerBound}`);
      const result = await rpc.mainnet.get_table_rows({
        json: true,
        code: 'cleanupcentr',
        scope: 'cleanupcentr',
        table: 'schemaburns',
        limit: 1000,
        lower_bound: lowerBound,
      });

      if (!result || !result.rows) {
        throw new Error(
          `Invalid response from blockchain (schemaburns): ${JSON.stringify(result)}`
        );
      }

      rules.push(...result.rows);
      more = !!result.more;

      // schemaburns primary key is `id` (based on your table UI + data)
      if (more && result.rows.length) {
        lowerBound = Number(result.rows[result.rows.length - 1].id) + 1;
      } else {
        more = false;
      }

      console.log(`[schemaburns] Fetched ${result.rows.length} rows. More: ${more}`);
    }

    console.log(`[schemaburns] Total fetched: ${rules.length}`);

    // ---------------------------
    // 2) Fetch ALL schemcaps
    // ---------------------------
    let caps = [];
    let capLowerBound = 0;
    let capMore = true;

    while (capMore) {
      console.log(`[schemcaps] Fetching with lower_bound=${capLowerBound}`);
      const capResult = await rpc.mainnet.get_table_rows({
        json: true,
        code: 'cleanupcentr',
        scope: 'cleanupcentr',
        table: 'schemcaps',
        limit: 1000,
        lower_bound: capLowerBound,
      });

      if (!capResult || !capResult.rows) {
        throw new Error(
          `Invalid response from blockchain (schemcaps): ${JSON.stringify(capResult)}`
        );
      }

      caps.push(...capResult.rows);
      capMore = !!capResult.more;

      // schemcaps primary key is `id` (confirmed by your cleos output)
      if (capMore && capResult.rows.length) {
        capLowerBound = Number(capResult.rows[capResult.rows.length - 1].id) + 1;
      } else {
        capMore = false;
      }

      console.log(`[schemcaps] Fetched ${capResult.rows.length} rows. More: ${capMore}`);
    }

    console.log(`[schemcaps] Total fetched: ${caps.length}`);

    // ---------------------------
    // 3) Build cap lookup by "collection:schema"
    // ---------------------------
    const capByKey = new Map();
    for (const c of caps) {
      const col = String(c.collection || '').toLowerCase().trim();
      const sch = String(c.schema || '').toLowerCase().trim();
      if (!col || !sch) continue;
      capByKey.set(`${col}:${sch}`, c);
    }

    // ---------------------------
    // 4) Merge cap fields into rules
    // ---------------------------
    const merged = rules.map((r) => {
      const col = String(r.collection || '').toLowerCase().trim();
      const sch = String(r.schema || '').toLowerCase().trim();
      const cap = capByKey.get(`${col}:${sch}`) || null;

      return {
        ...r,

        // ✅ available counts left
        cap_total: cap ? cap.cap_total : null,
        cap_remaining: cap ? cap.cap_remaining : null,

        // ✅ control flags (your schemcaps uses int 0/1)
        enabled: cap ? !!cap.enabled : (r.enabled ?? null),

        // ✅ governance link + timestamp
        prop_id: cap ? cap.prop_id : null,
        updated_at: cap ? (cap.updated_at || null) : null,
      };
    });

    return merged;
  } catch (error) {
    console.error('Error fetching schema burns:', error);
    throw new Error('Failed to fetch schema burns.');
  }
};

export {
  getBlockchainFarmers,
  searchAccountsByPublicKey,
  createProposal,
  verifyProposal,
  voteProposal,
  executeProposal,
  burnNFT,
  finalizeBurn,
  addApprovedTemplate,
  getTokenBalance,
  getTableRows,
  stakeIncinerator,
  getApprovedCollections,
  getSchemaBurns,
};
