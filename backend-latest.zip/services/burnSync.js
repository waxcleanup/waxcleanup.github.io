import { JsonRpc } from 'eosjs';
import fetch from 'node-fetch';
import BurnRecord from '../models/BurnRecord.js';
import dotenv from 'dotenv';

dotenv.config();

// Blockchain and MongoDB Config
const rpc = new JsonRpc(process.env.WAX_MAINNET_API || 'https://wax.pink.gg', { fetch });

// Fetch records from the blockchain without pagination
async function fetchBurnRecords(limit = 1000) {
    try {
        const response = await rpc.get_table_rows({
            json: true,
            code: process.env.CLEANUPCENTR_ACCOUNT || 'cleanupcentr', // Contract name
            scope: process.env.CLEANUPCENTR_ACCOUNT || 'cleanupcentr', // Scope
            table: 'burnrecs', // Correct table name from ABI
            limit, // Limit the number of records
        });

        console.log(`Fetched ${response.rows.length} burn records.`);
        return response.rows || [];
    } catch (error) {
        console.error('Error fetching burn records:', error.message);
        return [];
    }
}

// Save records to MongoDB using bulk operations
async function saveBurnRecords(records) {
    try {
        if (records.length === 0) {
            console.log('No records to save.');
            return;
        }

        console.log(`Saving ${records.length} records to MongoDB...`);
        const bulkOps = records.map(record => ({
            updateOne: {
                filter: { burn_id: record.burn_id },
                update: { $setOnInsert: record },
                upsert: true, // Insert if it doesn't exist
            },
        }));

        const result = await BurnRecord.bulkWrite(bulkOps);
        console.log(`Successfully saved ${result.nUpserted} new records.`);
    } catch (error) {
        console.error('Error saving burn records to MongoDB:', error);
    }
}

// Synchronize burn records without pagination
async function syncBurnRecords() {
    console.log('Starting burn record sync...');
    const records = await fetchBurnRecords();
    console.log(`Fetched ${records.length} burn records from blockchain.`);

    if (records.length > 0) {
        await saveBurnRecords(records);
        console.log('Burn record sync completed.');
    } else {
        console.log('No new burn records to sync.');
    }
}

export { syncBurnRecords as syncBurnRecordsPaginated };
