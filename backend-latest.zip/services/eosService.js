// services/eosService.js
import { JsonRpc, Api } from 'eosjs';
import { JsSignatureProvider } from 'eosjs/dist/eosjs-jssig.js';
import fetch from 'node-fetch';
import dotenv from 'dotenv';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Load environment variables from the parent directory .env file
dotenv.config({ path: path.join(__dirname, '..', '.env') });

// Required environment variables
const requiredEnvVars = [
  'PRIVATE_KEY', 
  'WAX_TESTNET_API', 
  'WAX_MAINNET_API', 
  'MAINNET_PRIVATE_KEY_CLEANUPCENTR'
];

// Ensure all required environment variables are set
for (const envVar of requiredEnvVars) {
  if (!process.env[envVar]) {
    console.error(`Error: Missing environment variable ${envVar}`);
    throw new Error(`${envVar} is required but not found.`);
  }
}

// Initialize RPC and API instances for testnet and mainnet
let rpc = {
  testnet: null,
  mainnet: null,
};
let api = {
  testnet: null,
  mainnet: null,
};

try {
  // Setup signature providers for testnet and mainnet
  const testnetSignatureProvider = new JsSignatureProvider([process.env.PRIVATE_KEY]);
  const mainnetSignatureProvider = new JsSignatureProvider([
    process.env.MAINNET_PRIVATE_KEY_CLEANUPCENTR
  ]);

  // Initialize Testnet
  console.log(`Initializing WAX Testnet API: ${process.env.WAX_TESTNET_API}`);
  rpc.testnet = new JsonRpc(process.env.WAX_TESTNET_API, { fetch });
  api.testnet = new Api({
    rpc: rpc.testnet,
    signatureProvider: testnetSignatureProvider,
    textDecoder: new TextDecoder(),
    textEncoder: new TextEncoder(),
  });

  // Initialize Mainnet
  console.log(`Initializing WAX Mainnet API: ${process.env.WAX_MAINNET_API}`);
  rpc.mainnet = new JsonRpc(process.env.WAX_MAINNET_API, { fetch });
  api.mainnet = new Api({
    rpc: rpc.mainnet,
    signatureProvider: mainnetSignatureProvider,
    textDecoder: new TextDecoder(),
    textEncoder: new TextEncoder(),
  });

  console.log("EOS services initialized successfully for both Testnet and Mainnet");
} catch (error) {
  console.error("Error initializing EOS services:", error);
  throw error;
}

// Test network connectivity
rpc.testnet.get_info()
  .then(info => console.log("Connected to WAX Testnet. Chain ID:", info.chain_id))
  .catch(error => console.error("Failed to connect to WAX Testnet:", error));

rpc.mainnet.get_info()
  .then(info => console.log("Connected to WAX Mainnet. Chain ID:", info.chain_id))
  .catch(error => console.error("Failed to connect to WAX Mainnet:", error));

// ✅ Universal transact function using mainnet API
const transact = async (account, action, data, options = {}) => {
  try {
    const result = await api.mainnet.transact({
      actions: [{
        account,
        name: action,
        authorization: [{
          actor: account,
          permission: 'active',
        }],
        data
      }]
    }, {
      blocksBehind: 3,
      expireSeconds: 30,
      ...options
    });
    return result;
  } catch (err) {
    console.error(`[transact] ${account}::${action} failed:`, err.message);
    throw err;
  }
};

export { rpc, api, transact };
