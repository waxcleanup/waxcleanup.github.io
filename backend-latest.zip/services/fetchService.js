// fetchService.js
import fetch from "node-fetch";
import { JsonRpc } from "eosjs";
import Collection from "../models/Collection.js";
import Schema from "../models/Schema.js";
import NFTTemplate from "../models/NFTTemplate.js";

// Use WAX Mainnet
const rpc = new JsonRpc("https://wax.greymass.com", { fetch });

// Use AtomicAssets HTTP API (Cryptolions)
const ATOMIC_API = "https://atomic-api.wax.cryptolions.io";

// -----------------------------
// Safety controls (IMPORTANT)
// -----------------------------

// Limit how many AtomicAssets HTTP requests can run at once
const ATOMIC_CONCURRENCY = Number(process.env.ATOMIC_CONCURRENCY || 3);

// Request timeout (ms) for AtomicAssets HTTP calls
const ATOMIC_TIMEOUT_MS = Number(process.env.ATOMIC_TIMEOUT_MS || 8000);

// When AA is flaky/rate-limiting, back off automatically
let aaFailStreak = 0;
let aaBackoffUntil = 0;

function sleep(ms) {
  return new Promise((r) => setTimeout(r, ms));
}

async function gateAtomicAssets() {
  const now = Date.now();
  if (now < aaBackoffUntil) {
    await sleep(aaBackoffUntil - now);
  }
}

function noteAtomicFail() {
  aaFailStreak++;
  // 0.5s, 1s, 2s, 4s, 8s, 16s, then cap at 30s
  const ms = Math.min(30000, 500 * (2 ** Math.min(aaFailStreak, 6)));
  aaBackoffUntil = Date.now() + ms;
}

function noteAtomicOk() {
  aaFailStreak = 0;
  aaBackoffUntil = 0;
}

// Simple in-file concurrency limiter (no deps)
function createLimiter(max = 3) {
  let active = 0;
  const q = [];

  const next = () => {
    if (active >= max) return;
    const job = q.shift();
    if (!job) return;

    active++;
    job()
      .catch(() => {})
      .finally(() => {
        active--;
        next();
      });
  };

  return function limit(fn) {
    return new Promise((resolve) => {
      q.push(async () => resolve(await fn()));
      next();
    });
  };
}

const limitAtomic = createLimiter(ATOMIC_CONCURRENCY);

// Fetch JSON with timeout + status visibility
async function fetchJsonWithTimeout(url, ms = 8000) {
  const ctrl = new AbortController();
  const t = setTimeout(() => ctrl.abort(), ms);

  try {
    const res = await fetch(url, { signal: ctrl.signal });
    const text = await res.text();

    let json = null;
    try {
      json = JSON.parse(text);
    } catch {
      // non-json
    }

    return { ok: res.ok, status: res.status, json, text };
  } finally {
    clearTimeout(t);
  }
}

// Helper: paginate on-chain table
async function getAllRows({ code, scope, table, limit = 1000 }) {
  let rows = [];
  let lower_bound = "";
  while (true) {
    const resp = await rpc.get_table_rows({
      json: true,
      code,
      scope,
      table,
      lower_bound,
      limit,
    });
    rows.push(...resp.rows);
    if (!resp.more) break;
    lower_bound = resp.next_key || rows[rows.length - 1].template_id;
  }
  return rows;
}

// Extract only the CID from values like "CID/filename.ext"
function extractCID(str) {
  return str && typeof str === "string" && str.includes("/")
    ? str.split("/")[0]
    : str || "";
}

// 1️⃣ Sync collections (on-chain only)
export async function syncData() {
  console.log("🔄 Starting on-chain collections sync…");
  try {
    const collections = await getAllRows({
      code: "atomicassets",
      scope: "atomicassets",
      table: "collections",
    });

    for (const col of collections) {
      await Collection.findOneAndUpdate(
        { collection_name: col.collection_name },
        { ...col, updatedAt: new Date() },
        { upsert: true, new: true }
      );
      console.log(`✅ Collection saved: ${col.collection_name}`);
    }

    console.log("🎉 Collections sync completed.");
  } catch (err) {
    console.error("❌ Error syncing collections:", err.message);
  }
}

// 2️⃣ Sync schemas and templates with full IPFS media
export async function syncCollectionSchemasAndTemplates(collectionName) {
  console.log(`🔄 Syncing schemas/templates for ${collectionName}…`);

  try {
    // Fetch schemas
    const schemas = await getAllRows({
      code: "atomicassets",
      scope: collectionName,
      table: "schemas",
    });

    for (const schema of schemas) {
      await Schema.findOneAndUpdate(
        {
          collection_name: collectionName,
          schema_name: schema.schema_name,
        },
        { ...schema, updatedAt: new Date() },
        { upsert: true, new: true }
      );
      console.log(`✅ Schema saved: ${schema.schema_name}`);
    }

    // Fetch templates (on-chain list)
    const templates = await getAllRows({
      code: "atomicassets",
      scope: collectionName,
      table: "templates",
    });

    // Process templates with limited AtomicAssets concurrency
    for (const tpl of templates) {
      const templateId = tpl.template_id;

      // OPTIONAL BUT HUGE:
      // If we already have this template cached, skip AtomicAssets HTTP entirely
      const existing = await NFTTemplate.findOne({
        collection_name: collectionName,
        template_id: Number(templateId),
      }).select("template_id template_name img video updatedAt");

      let template_name = existing?.template_name || "Unnamed Template";
      let img = existing?.img || "";
      let video = existing?.video || "";
      let immutable_data = {};

      // Only fetch from AtomicAssets if missing important fields
      const shouldFetchAtomic =
        !existing || (!existing.img && !existing.video && !existing.template_name);

      if (shouldFetchAtomic) {
        await limitAtomic(async () => {
          await gateAtomicAssets();

          const url = `${ATOMIC_API}/atomicassets/v1/templates/${collectionName}/${templateId}`;
          try {
            const r = await fetchJsonWithTimeout(url, ATOMIC_TIMEOUT_MS);

            if (!r.ok) {
              console.warn(
                `⚠️ AtomicAssets HTTP ${r.status} for ${collectionName} / ${templateId}`
              );
              noteAtomicFail();
              return;
            }

            const json = r.json;
            if (json && json.success && json.data) {
              immutable_data = json.data.immutable_data || {};
              template_name = immutable_data.name || template_name;
              img = extractCID(immutable_data.img);
              video = extractCID(immutable_data.video);
              noteAtomicOk();
            } else {
              console.warn(
                `⚠️ AtomicAssets API returned no data for ${collectionName} / ${templateId}`
              );
              noteAtomicFail();
            }
          } catch (err) {
            const msg = err?.name === "AbortError" ? "timeout" : err?.message;
            console.error(
              `❌ AtomicAssets fetch failed (${msg}) for ${collectionName} / ${templateId}`
            );
            noteAtomicFail();
          }
        });
      }

      // ✅ FIX: upsert key must include collection_name + template_id
      await NFTTemplate.findOneAndUpdate(
        { collection_name: collectionName, template_id: Number(templateId) },
        {
          template_id: Number(templateId),
          collection_name: collectionName,
          schema_name: tpl.schema_name,
          template_name,
          img,
          video,
          supply: tpl.max_supply || 0,
          circulating_supply: tpl.issued_supply || 0,
          ...immutable_data,
          updatedAt: new Date(),
        },
        { upsert: true, new: true }
      );

      console.log(`✅ Template saved: ${templateId}`);
    }

    console.log(`🎉 Finished syncing templates for ${collectionName}.`);
  } catch (err) {
    console.error(
      `❌ Error syncing schemas/templates for ${collectionName}:`,
      err.message
    );
  }
}
