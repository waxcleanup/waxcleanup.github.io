import { Api, JsonRpc } from 'eosjs';
import { JsSignatureProvider } from 'eosjs/dist/eosjs-jssig.js';
import fetch from 'node-fetch';
import WalletModel from '../models/Wallet.js';
import { decryptPrivateKey } from '../utils/encryption.js';

// Setup EOSIO RPC endpoint using the testnet API
const rpc = new JsonRpc(process.env.WAX_TESTNET_API, { fetch });

export const signTransaction = async (accountName, transaction) => {
  console.log(`Attempting to sign transaction for account: ${accountName}`);
  console.log('Transaction to sign:', JSON.stringify(transaction, null, 2));

  try {
    // 1. Fetch the wallet data from MongoDB
    const wallet = await WalletModel.findOne({ accountName });
    if (!wallet) {
      throw new Error(`Wallet not found for account: ${accountName}`);
    }

    // 2. Decrypt the private key
    console.log('Decrypting private key...');
    const privateKey = decryptPrivateKey(wallet.encryptedPrivateKey);
    if (!privateKey || privateKey.length < 51) {
      throw new Error('Decrypted private key is invalid.');
    }

    // 3. Create a JsSignatureProvider with the decrypted private key
    const signatureProvider = new JsSignatureProvider([privateKey]);

    // 4. Create an API instance
    const api = new Api({ 
      rpc, 
      signatureProvider, 
      textDecoder: new TextDecoder(), 
      textEncoder: new TextEncoder(),
      chainId: process.env.CHAIN_ID // Use the chain ID from the environment
    });

    // 5. Verify the account exists on the blockchain
    console.log('Verifying account on blockchain...');
    const accountInfo = await rpc.get_account(accountName);
    console.log('Account info:', JSON.stringify(accountInfo, null, 2));

    // 6. Ensure the transaction includes correct authorization and fix quantity precision
    const actions = transaction.actions.map((action) => ({
      ...action,
      authorization: [{
        actor: accountName,
        permission: 'active',
      }],
      data: {
        ...action.data,
        quantity: `${parseFloat(action.data.quantity).toFixed(8)} WAX`, // Ensure 8 decimal places for WAX
      },
    }));

    console.log('Prepared actions:', JSON.stringify(actions, null, 2));

    // 7. Sign and broadcast the transaction
    console.log('Signing and broadcasting transaction...');
    const signedTransaction = await api.transact({ actions }, {
      blocksBehind: 3,
      expireSeconds: 30,
      broadcast: true,
      sign: true,
    });

    console.log('Transaction signed and broadcast successfully:', JSON.stringify(signedTransaction, null, 2));
    return signedTransaction;
  } catch (error) {
    console.error('Detailed error in signTransaction:', JSON.stringify(error, null, 2));
    if (error.json && error.json.error) {
      console.error('Server error details:', JSON.stringify(error.json.error, null, 2));
    }
    throw new Error(`Failed to sign transaction: ${error.message}`);
  }
};

export const verifyAccount = async (accountName) => {
  try {
    const account = await rpc.get_account(accountName);
    console.log(`Account ${accountName} exists:`, account);
    return account;
  } catch (error) {
    console.error(`Failed to verify account ${accountName}:`, error);
    return null;
  }
};
