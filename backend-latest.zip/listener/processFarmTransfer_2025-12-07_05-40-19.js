// ~/backend/listener/processFarmTransfer.js

import {
  handleFarmStake,
  handleFarmCellStake,
  handleUserCellStake,
  handleRechargeFarm,
  handleUserRecharge,
} from './handlers/farmHandler.js';

import { handleDeposit } from './handlers/nftHandler.js';

/**
 * Route a single farm-related transfer action to the correct handler based on memo
 * @param {Object} action - The EOSIO transfer action payload
 */
export async function processFarmTransfer(action) {
  const { memo, from, to } = action.data;
  console.log(`🚜 Processing farm transfer: from=${from}, to=${to}, memo="${memo}"`);

  if (!memo || typeof memo !== 'string') {
    console.log('🚫 No memo on transfer, skipping.');
    return;
  }

  // ---------------------------
  // 1) GENERIC NFT DEPOSITS
  //    e.g. "Deposit:Compost:assetId:templateId"
  //         "Deposit:Pack:assetId:templateId"
  // ---------------------------
  if (memo.startsWith('Deposit:')) {
    console.log('📦 Routing to handleDeposit (NFT processor)…');
    await handleDeposit(action);
    return;
  }

  // ---------------------------
  // 2) FARM & ENERGY OPERATIONS
  // ---------------------------
  if (memo.startsWith('Stake Farm:')) {
    await handleFarmStake(action);

  } else if (memo.startsWith('Stake Cell:')) {
    await handleFarmCellStake(action);

  } else if (memo.startsWith('Stake UserCell:')) {
    await handleUserCellStake(action);

  } else if (memo.startsWith('Recharge Farm:')) {
    await handleRechargeFarm(action);

  } else if (memo.startsWith('Recharge User')) {
    // Supports:
    // "Recharge User"
    // "Recharge User:<user>"
    await handleUserRecharge(action);

  } else {
    console.log('🚫 Unrecognized farm memo, skipping.');
  }
}
