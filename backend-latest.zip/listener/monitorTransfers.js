// ~/backend/listener/monitorTransfers.js

import dotenv from 'dotenv';
import path from 'path';
import { JsonRpc } from 'eosjs';
import fetch from 'node-fetch';

import { processFarmTransfer } from './processFarmTransfer.js';
import { dispatchTransfer as processCleanupTransfer } from './processTransfer.js';

dotenv.config({ path: path.resolve('../.env') });

const rpcEndpoints = [
  'https://api.waxsweden.org',
  'https://wax.greymass.com',
  'https://api.wax.alohaeos.com',
  'https://wax.eosphere.io',
  'https://wax.api.eosnation.io',
  'https://wax.dapplica.io',
  'https://wax.eosdac.io',
  'https://api.hivebp.io',
  'https://api2.hivebp.io',
  process.env.WAX_MAINNET_API
].filter(Boolean);

let currentRpcIndex = 0;
let rpc = new JsonRpc(rpcEndpoints[currentRpcIndex], { fetch });

async function switchRpc() {
  currentRpcIndex = (currentRpcIndex + 1) % rpcEndpoints.length;
  rpc = new JsonRpc(rpcEndpoints[currentRpcIndex], { fetch });
  console.warn(`⚠️ Switched RPC to: ${rpcEndpoints[currentRpcIndex]}`);
}

let lastBlock;

async function updateToLatestHeadBlock() {
  try {
    const info = await rpc.get_info();
    lastBlock = info.head_block_num - 1;
    console.warn(`⚠️ Updated lastBlock to latest head: ${lastBlock}`);
  } catch (err) {
    console.error('❌ Failed to fetch head block after switching RPC:', err.message);
  }
}

export async function monitorTransfers() {
  console.log('📡 Starting live transfer monitor...');
  console.log(`▶️  Initial RPC: ${rpcEndpoints[currentRpcIndex]}`);

  try {
    const info = await rpc.get_info();
    lastBlock = info.head_block_num - 1;
    console.log(`🚀 Starting at block ${lastBlock}`);
  } catch (err) {
    console.error('❌ Failed to fetch head block:', err.message);
    await switchRpc();
    return monitorTransfers();
  }

  let slowBlockCount = 0;

  while (true) {
    try {
      const info = await rpc.get_info();
      const head = info.head_block_num - 1;

      const delay = head - lastBlock;
      if (delay > 3) {
        console.warn(`⚠️ WARNING: ${delay} blocks behind real-time`);
      }

      const MAX_BLOCKS_PER_CYCLE = delay > 10 ? 500 : 10;
      if (head > lastBlock) {
        const toBlock = Math.min(head, lastBlock + MAX_BLOCKS_PER_CYCLE);
        const count = toBlock - lastBlock;
        console.log(`🔄 Detected ${count} new block${count !== 1 ? 's' : ''}: ${lastBlock + 1} → ${toBlock}`);

        for (let blk = lastBlock + 1; blk <= toBlock; blk++) {
          console.log(`⏳ Processing live block ${blk}`);
          const blockFetchStart = Date.now();
          let block;
          try {
            block = await rpc.get_block(blk);
            const fetchTime = Date.now() - blockFetchStart;
            console.log(`📡 get_block ${blk} took ${fetchTime}ms`);

            if (delay > 10 && fetchTime > 500) {
              slowBlockCount++;
              if (slowBlockCount >= 3) {
                console.warn(`⚠️ Too many slow blocks (${slowBlockCount}), switching RPC...`);
                slowBlockCount = 0;
                await switchRpc();
                await updateToLatestHeadBlock();
                break;
              }
            } else {
              slowBlockCount = 0;
            }
          } catch (err) {
            console.error(`❌ Failed to fetch block ${blk}:`, err.message);
            await switchRpc();
            await updateToLatestHeadBlock();
            break;
          }

          for (const trx of block.transactions) {
            const actions = trx.trx?.transaction?.actions || [];
            for (const act of actions) {
              if (act.name !== 'transfer') continue;
              const to = act.data?.to;

              if (to === process.env.RHYTHMFARMER_ACCOUNT) {
                await processFarmTransfer(act);
              } else if (to === process.env.CLEANUPCENTR_ACCOUNT) {
                await processCleanupTransfer(act);
              }
            }
          }

          const duration = Date.now() - blockFetchStart;
          console.log(`⏱️ Block ${blk} processed in ${duration}ms`);
          lastBlock = blk;
        }
      }
    } catch (err) {
      console.error('❌ monitorTransfers error:', err.message);
      await switchRpc();
      await updateToLatestHeadBlock();
    }

    await new Promise(resolve => setTimeout(resolve, 10));
  }
}

if (import.meta.url === `file://${process.argv[1]}`) {
  monitorTransfers();
}
