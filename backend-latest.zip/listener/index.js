// ~/backend/listener/index.js
import dotenv from 'dotenv';
import path from 'path';
import mongoose from 'mongoose';

dotenv.config({ path: path.resolve('../.env') });

async function main() {
  // ✅ Connect Mongo for THIS PM2 PROCESS (cleanup-listener)
  if (!process.env.MONGODB_URI) {
    console.error('❌ MONGODB_URI is not set for listener');
    process.exit(1);
  }

  // Optional: fail fast instead of buffering
  mongoose.set('bufferCommands', false);

  mongoose.connection.on('connected', () => console.log('✅ Listener connected to MongoDB'));
  mongoose.connection.on('error', (e) => console.error('❌ Mongo error (listener):', e.message));
  mongoose.connection.on('disconnected', () => console.warn('⚠️ Mongo disconnected (listener)'));

  await mongoose.connect(process.env.MONGODB_URI, {
    serverSelectionTimeoutMS: 10000,
  });

  // ✅ Import AFTER connect so any models used during startup are safe
  const { monitorTransfers } = await import('./monitorTransfers.js');

  console.log('📡 Starting combined transfer monitor...');
  await monitorTransfers();
}

main().catch((err) => {
  console.error('❌ Listener fatal error:', err.message || err);
  process.exit(1);
});
