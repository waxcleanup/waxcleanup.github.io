// ~/backend/listener/processTransfer.js

import config from '../utils/config.js';
import { burnHandler } from './handlers/burnHandler.js';
import { stakeHandler } from './handlers/stakeHandler.js';
import { loadFuelHandler, loadEnergyHandler } from './handlers/fuelHandler.js';
import { repairHandler } from './handlers/repairHandler.js';
import { proposalHandler } from './handlers/proposalHandler.js';

/**
 * Dispatch a single transfer action to the appropriate cleanupcentr handler
 * @param {Object} action - The EOSIO transfer action payload
 */
export async function dispatchTransfer(action) {
  const { from, to, memo } = action.data;
  console.log(`🧹 Processing cleanup transfer: from=${from}, to=${to}, memo="${memo}"`);

  // Ignore transfers not to the cleanup contract
  if (to !== config.cleanupContract) {
    console.log('🔍 Not a cleanupcentr transfer, skipping.');
    return;
  }

  if (memo.startsWith(`${config.incinerateMemo}:`)) {
    await burnHandler(action);
  } else if (memo.startsWith(`${config.stakeMemo}:`)) {
    await stakeHandler(action);
  } else if (memo.startsWith(`${config.loadFuelMemo}:`)) {
    await loadFuelHandler(action);
  } else if (memo.startsWith(`${config.loadEnergyMemo}:`)) {
    await loadEnergyHandler(action);
  } else if (memo.startsWith(`${config.repairMemo}:`)) {
    await repairHandler(action);
  } else if (memo.startsWith(`${config.proposalMemo}:`)) {
    await proposalHandler(action);
  } else {
    console.log('❓ Unrecognized cleanup memo, ignoring.');
  }
}
