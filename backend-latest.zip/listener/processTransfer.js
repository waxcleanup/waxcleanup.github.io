// ~/backend/listener/processTransfer.js

import config from '../utils/config.js';
import { encryptedBurnHandler } from './handlers/encryptedBurnHandler.js';
import { stakeHandler } from './handlers/stakeHandler.js';
import { loadFuelHandler, loadEnergyHandler } from './handlers/fuelHandler.js';
import { repairHandler } from './handlers/repairHandler.js';
import { proposalHandler } from './handlers/proposalHandler.js';

export async function dispatchTransfer(action) {
  const { from, to, memo = '' } = action.data;
  console.log(`🧹 Processing cleanup transfer: from=${from}, to=${to}, memo="${memo}"`);

  if (to !== config.cleanupContract) {
    console.log('🔍 Not a cleanupcentr transfer, skipping.');
    return;
  }

  // 🔐 ONLY encrypted burns allowed
  if (memo.startsWith('ENC:')) {
    await encryptedBurnHandler(action);
    return;
  }

  // Legacy handlers (safe)
  if (memo.startsWith(`${config.stakeMemo}:`)) {
    await stakeHandler(action);
  } else if (memo.startsWith(`${config.loadFuelMemo}:`)) {
    await loadFuelHandler(action);
  } else if (memo.startsWith(`${config.loadEnergyMemo}:`)) {
    await loadEnergyHandler(action);
  } else if (memo.startsWith(`${config.repairMemo}:`)) {
    await repairHandler(action);
  } else if (memo.startsWith(`${config.proposalMemo}:`)) {
    await proposalHandler(action);
  } else {
    console.log('❓ Unrecognized cleanup memo, ignoring.');
  }
}
