// ~/backend/listener/services/cleanupTables.js

import config from '../../utils/config.js';
import { JsonRpc } from 'eosjs';
import fetch from 'node-fetch';

// EOSJS RPC client for table queries
const rpc = new JsonRpc(process.env.WAX_MAINNET_API || process.env.WAX_TESTNET_API, { fetch });

/**
 * Fetch incinerator details by ID
 * @param {string|number} incineratorId
 * @returns {Promise<Object|null>} incinerator row or null
 */
export async function getIncinerator(incineratorId) {
  try {
    const response = await rpc.get_table_rows({
      json: true,
      code: config.cleanupContract,
      scope: config.cleanupContract,
      table: 'incinerators',
      lower_bound: incineratorId,
      limit: 1
    });
    if (response.rows.length > 0) {
      return response.rows[0];
    }
    console.error(`Incinerator ${incineratorId} not found.`);
    return null;
  } catch (err) {
    console.error(`Error fetching incinerator ${incineratorId}:`, err.message);
    return null;
  }
}

/**
 * Fetch the first approved proposal for a given template ID
 * @param {number} templateId
 * @returns {Promise<Object|null>} proposal row or null
 */
export async function getProposal(templateId) {
  let lowerBound = 0;
  const limit = 1000;
  try {
    while (true) {
      const response = await rpc.get_table_rows({
        json: true,
        code: config.cleanupContract,
        scope: config.cleanupContract,
        table: 'proposals',
        lower_bound: lowerBound,
        limit
      });
      if (!response.rows.length) break;
      // Find an approved proposal matching the template ID
      const row = response.rows.find(r => r.template_id === templateId && r.status === 'approved');
      if (row) {
        return row;
      }
      if (!response.more) break;
      lowerBound = response.next_key;
    }
    console.error(`Approved proposal for template ID ${templateId} not found.`);
    return null;
  } catch (err) {
    console.error(`Error fetching proposals for template ID ${templateId}:`, err.message);
    return null;
  }
}
