// ~/backend/listener/services/cleanupActions.js

import dotenv from 'dotenv';
import { Api, JsonRpc } from 'eosjs';
import fetch from 'node-fetch';
import { TextEncoder, TextDecoder } from 'util';
import config from '../../utils/config.js';
import { JsSignatureProvider } from 'eosjs/dist/eosjs-jssig.js';

dotenv.config();

// Initialize EOSJS RPC and API
const rpc = new JsonRpc(
  process.env.WAX_MAINNET_API || process.env.WAX_TESTNET_API,
  { fetch }
);

// Load signing key (supports MAINNET_PRIVATE_KEY_CLEANUPCENTR)
const privateKey = process.env.MAINNET_PRIVATE_KEY_CLEANUPCENTR || process.env.CLEANUPCENTR_PRIVATE_KEY || process.env.PRIVATE_KEY;
const signatureProvider = new JsSignatureProvider([privateKey]);

// Create API instance
const api = new Api({
  rpc,
  signatureProvider,
  textDecoder: new TextDecoder(),
  textEncoder: new TextEncoder(),
});

/**
 * Ensure asset string matches expected symbol and precision
 * @param {string} asset - e.g. "0.123 TRASH"
 * @param {string} expectedSymbol - e.g. "TRASH"
 * @param {number} expectedPrecision - number of decimals
 */
export function validateAsset(asset, expectedSymbol, expectedPrecision) {
  const [amount, symbol] = asset.split(' ');
  const decimals = (amount.split('.')[1] || '').length;
  if (symbol !== expectedSymbol || decimals !== expectedPrecision) {
    throw new Error(
      `Asset precision mismatch: expected ${expectedPrecision} decimal places for ${expectedSymbol}, got "${asset}"`
    );
  }
}

/**
 * Submit a burnnft action
 */
export async function burnNft(
  user,
  asset_id,
  collection,
  schema,
  template_id,
  incinerator_id,
  trash_fee,
  cinder_reward
) {
  await api.transact(
    {
      actions: [
        {
          account: config.cleanupContract,
          name: 'burnnft',
          authorization: [
            { actor: config.cleanupContract, permission: 'active' }
          ],
          data: {
            user,
            asset_id: String(asset_id),
            collection,
            schema,
            template_id,
            incinerator_id,
            trash_fee,
            cinder_reward,
          },
        },
      ],
    },
    { blocksBehind: 3, expireSeconds: 30 }
  );
}

/**
 * Submit a stakeincin action
 */
export async function stakeNft(user, incinerator_id, template_id) {
  await api.transact(
    {
      actions: [
        {
          account: config.cleanupContract,
          name: 'stakeincin',
          authorization: [
            { actor: config.cleanupContract, permission: 'active' }
          ],
          data: { user, incinerator_id: String(incinerator_id), template_id },
        },
      ],
    },
    { blocksBehind: 3, expireSeconds: 30 }
  );
}

/**
 * Submit a loadfuel action
 */
export async function loadFuel(user, incinerator_id, amount) {
  await api.transact(
    {
      actions: [
        {
          account: config.cleanupContract,
          name: 'loadfuel',
          authorization: [
            { actor: config.cleanupContract, permission: 'active' }
          ],
          data: { user, incinerator_id: String(incinerator_id), amount },
        },
      ],
    },
    { blocksBehind: 3, expireSeconds: 30 }
  );
}

/**
 * Submit a loadenergy action
 */
export async function loadEnergy(user, incinerator_id) {
  await api.transact(
    {
      actions: [
        {
          account: config.cleanupContract,
          name: 'loadenergy',
          authorization: [
            { actor: config.cleanupContract, permission: 'active' }
          ],
          data: { user, incinerator_id: String(incinerator_id) },
        },
      ],
    },
    { blocksBehind: 3, expireSeconds: 30 }
  );
}

/**
 * Submit a repairincin action
 */
export async function repairIncinerator(user, incinerator_id, repair_points) {
  await api.transact(
    {
      actions: [
        {
          account: config.cleanupContract,
          name: 'repairincin',
          authorization: [
            { actor: config.cleanupContract, permission: 'active' }
          ],
          data: { user, incinerator_id: String(incinerator_id), repair_points },
        },
      ],
    },
    { blocksBehind: 3, expireSeconds: 30 }
  );
}

/**
 * Submit a createprop action
 */
export async function createProposal(
  proposer,
  proposal_type,
  collection,
  schema,
  template_id,
  trash_fee,
  cinder_reward
) {
  await api.transact(
    {
      actions: [
        {
          account: config.cleanupContract,
          name: 'createprop',
          authorization: [
            { actor: config.cleanupContract, permission: 'active' }
          ],
          data: {
            proposer,
            proposal_type,
            collection,
            schema,
            template_id,
            trash_fee,
            cinder_reward,
          },
        },
      ],
    },
    { blocksBehind: 3, expireSeconds: 30 }
  );
}
