import axios from 'axios';
import { LRUCache } from 'lru-cache';
import dotenv from 'dotenv';

dotenv.config();

// In-memory metadata cache (5 minutes)
const cache = new LRUCache({ max: 500, ttl: 1000 * 60 * 5 });

// 🔥 Hardcoded to CryptoLions
const endpoint = 'https://atomic-api.wax.cryptolions.io';

/**
 * Fetch asset metadata from AtomicAssets API, with caching
 * @param {string|number} assetId
 * @returns {Promise<Object|null>}
 */
export async function getAssetMetadata(assetId) {
  const key = String(assetId);
  if (cache.has(key)) {
    return cache.get(key);
  }

  try {
    console.log(`Fetching metadata for asset ${assetId}`);
    const url = `${endpoint}/atomicassets/v1/assets/${assetId}`;
    const response = await axios.get(url, { headers: { 'Range': undefined } });

    if (response.data && response.data.success) {
      const data = response.data.data;
      cache.set(key, data);
      return data;
    } else {
      console.error(`AtomicAssets API error: ${response.data?.message || 'Unknown error'}`);
      return null;
    }
  } catch (err) {
    console.error(`❌ Error fetching metadata for asset ${assetId}:`, err.message);
    return null;
  }
}
