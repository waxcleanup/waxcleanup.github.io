import { JsonRpc } from 'eosjs';
import fetch from 'node-fetch';

const rpcEndpoints = [
  'https://wax.greymass.com',          // Still fastest in your tests
  'https://api.wax.alohaeos.com',      // Top-ranked by EOS Nation
  'https://api.waxsweden.org',
  'https://wax.dapplica.io',
  'https://wax.eosrio.io',
  'https://wax.eosdac.io',
  'https://wax.eosphere.io',
  'https://wax.api.eosnation.io',
  'https://api.hivebp.io',
  'https://api2.hivebp.io'
];

const testBlock = 380940000;

async function testRpc(endpoint) {
  const rpc = new JsonRpc(endpoint, { fetch });
  const start = Date.now();
  try {
    await rpc.get_block(testBlock);
    const ms = Date.now() - start;
    console.log(`✅ ${endpoint} responded in ${ms}ms`);
    return { endpoint, ms };
  } catch (err) {
    console.log(`❌ ${endpoint} failed: ${err.message}`);
    return { endpoint, ms: Infinity };
  }
}

(async () => {
  const results = await Promise.all(rpcEndpoints.map(testRpc));
  const fastest = results.sort((a, b) => a.ms - b.ms)[0];
  console.log(`🚀 Fastest RPC: ${fastest.endpoint} (${fastest.ms}ms)`);
})();
