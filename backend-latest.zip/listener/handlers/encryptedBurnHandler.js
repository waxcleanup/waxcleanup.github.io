// ~/backend/listener/handlers/encryptedBurnHandler.js

import config from '../../utils/config.js';
import { decryptMemo } from '../../utils/memoEncryption.js';
import { getAssetMetadata } from '../services/atomicAssets.js';
import { getIncinerator, getProposal } from '../services/cleanupTables.js';
import { validateAsset, burnNft } from '../services/cleanupActions.js';

import BurnDailyUsage from '../../models/BurnDailyUsage.js';

/**
 * In-memory short-term rate limiting (fine to keep in memory)
 */
const burnRate = new Map();       // user => { lastBurnMs, windowStart, count }
const incinCooldown = new Map();  // incineratorId => lastBurnMs

const USER_DAILY_CAP = 1000;
const INCIN_DAILY_CAP = 300;

/**
 * Throw a structured CAP_HIT error that a caller (route or dispatcher)
 * can convert into a 429 JSON response for the frontend.
 */
function capHit(payload) {
  const err = new Error('CAP_HIT');
  err.code = 'CAP_HIT';
  err.status = 429;
  err.payload = { error: 'CAP_HIT', ...payload };
  throw err;
}

function utcDayKey() {
  return new Date().toISOString().slice(0, 10); // UTC "YYYY-MM-DD"
}

function nextUtcMidnightIso() {
  const now = new Date();
  const next = new Date(
    Date.UTC(
      now.getUTCFullYear(),
      now.getUTCMonth(),
      now.getUTCDate() + 1,
      0, 0, 0, 0
    )
  );
  return next.toISOString();
}

/**
 * Fetch daily usage (user + incinerator) from Mongo for today.
 */
async function getDailyCounts(user, incineratorId, day) {
  const [u, i] = await Promise.all([
    BurnDailyUsage.findOne({ day, scope: 'user', key: String(user) }).lean(),
    BurnDailyUsage.findOne({ day, scope: 'incinerator', key: String(incineratorId) }).lean(),
  ]);

  return {
    userUsed: u?.count ?? 0,
    incUsed: i?.count ?? 0,
  };
}

/**
 * Increment daily usage in Mongo after successful burn.
 */
async function incrementDailyCounts(user, incineratorId, day, amount = 1) {
  await Promise.all([
    BurnDailyUsage.updateOne(
      { day, scope: 'user', key: String(user) },
      { $inc: { count: amount } },
      { upsert: true }
    ),
    BurnDailyUsage.updateOne(
      { day, scope: 'incinerator', key: String(incineratorId) },
      { $inc: { count: amount } },
      { upsert: true }
    ),
  ]);
}

/**
 * Secure burn handler:
 *  - Expects encrypted memo with ENC: prefix
 *  - Decrypts + validates payload
 *  - Applies backend cooldown + rate limiting + daily caps (Mongo)
 *  - Then runs the burn flow
 */
export async function encryptedBurnHandler(action) {
  const { from: chainUser, asset_ids, memo } = action.data;
  console.log(`🧨 encryptedBurnHandler triggered: user=${chainUser}, memo="${memo}"`);

  // 1) Decrypt memo → payload
  let payload;
  try {
    payload = decryptMemo(memo);
  } catch (err) {
    console.error(`❌ Failed to decrypt memo: ${err.message}`);
    return;
  }

  const { type, user, assetId, incineratorId, ts } = payload || {};

  // 2) Basic payload sanity
  if (type && type !== 'burn') {
    console.error(`❌ Unsupported payload type: ${type}`);
    return;
  }

  if (!user || !incineratorId) {
    console.error('❌ Decrypted payload missing user or incineratorId');
    return;
  }

  if (String(user) !== String(chainUser)) {
    console.error(`❌ User mismatch: payload=${user}, chain=${chainUser}`);
    return;
  }

  const chainAssetId = asset_ids && asset_ids.length > 0 ? String(asset_ids[0]) : null;
  if (assetId && chainAssetId && String(assetId) !== chainAssetId) {
    console.error(`❌ Asset ID mismatch: payload=${assetId}, chain=${chainAssetId}`);
    return;
  }

  // 3) Anti-replay: timestamp freshness check (5 min)
  if (ts) {
    const nowSec = Math.floor(Date.now() / 1000);
    const MAX_AGE_SEC = 5 * 60;
    if (Math.abs(nowSec - ts) > MAX_AGE_SEC) {
      console.error(`❌ Encrypted memo expired or too far in the future. ts=${ts}, now=${nowSec}`);
      return;
    }
  } else {
    console.warn('⚠️ No timestamp in decrypted payload; consider adding ts for replay protection.');
  }

  // 3.5) In-memory rate limit (user)
  const COOLDOWN_MS = 1000;
  const WINDOW_MS = 60000;
  const MAX_BURNS_PER_WINDOW = 60;

  try {
    const nowMs = Date.now();
    const key = String(user);

    let info = burnRate.get(key);
    if (!info) info = { lastBurnMs: 0, windowStart: nowMs, count: 0 };

    const sinceLastUser = nowMs - info.lastBurnMs;

    if (sinceLastUser < COOLDOWN_MS) {
      burnRate.set(key, info);
      capHit({
        scope: 'user',
        key,
        kind: 'cooldown',
        cooldownMs: COOLDOWN_MS,
        remainingMs: COOLDOWN_MS - sinceLastUser,
        resetAt: new Date(nowMs + (COOLDOWN_MS - sinceLastUser)).toISOString(),
        message: 'You are burning too fast. Please wait a moment.',
      });
    }

    if (nowMs - info.windowStart > WINDOW_MS) {
      info.windowStart = nowMs;
      info.count = 0;
    }

    info.count += 1;
    if (info.count > MAX_BURNS_PER_WINDOW) {
      burnRate.set(key, info);
      capHit({
        scope: 'user',
        key,
        kind: 'window',
        windowSeconds: WINDOW_MS / 1000,
        limit: MAX_BURNS_PER_WINDOW,
        resetAt: new Date(info.windowStart + WINDOW_MS).toISOString(),
        message: `Rate limit: max ${MAX_BURNS_PER_WINDOW} burns per ${WINDOW_MS / 1000}s.`,
      });
    }

    burnRate.set(key, info);
  } catch (e) {
    console.error('⚠️ Error in user rate limiting logic:', e.message);
    return;
  }

  // 3.6) In-memory incinerator cooldown
  const INCIN_COOLDOWN_MS = 3000;
  try {
    const nowMs = Date.now();
    const incKey = String(incineratorId);
    const lastBurnMs = incinCooldown.get(incKey) || 0;
    const sinceLastInc = nowMs - lastBurnMs;

    if (sinceLastInc < INCIN_COOLDOWN_MS) {
      capHit({
        scope: 'incinerator',
        key: incKey,
        kind: 'cooldown',
        cooldownMs: INCIN_COOLDOWN_MS,
        remainingMs: INCIN_COOLDOWN_MS - sinceLastInc,
        resetAt: new Date(nowMs + (INCIN_COOLDOWN_MS - sinceLastInc)).toISOString(),
        message: 'Incinerator cooling down.',
      });
    }

    incinCooldown.set(incKey, nowMs);
  } catch (e) {
    console.error('⚠️ Error in incinerator cooldown logic:', e.message);
    return;
  }

  // 3.7) Daily caps (Mongo, survives PM2)
  const day = utcDayKey();

  let { userUsed, incUsed } = await getDailyCounts(user, incineratorId, day);

  if (userUsed >= USER_DAILY_CAP) {
    capHit({
      scope: 'user',
      key: String(user),
      kind: 'daily',
      limit: USER_DAILY_CAP,
      used: userUsed,
      remaining: 0,
      resetAt: nextUtcMidnightIso(),
      message: `Daily user burn cap reached (${USER_DAILY_CAP}/day).`,
    });
  }

  if (incUsed >= INCIN_DAILY_CAP) {
    capHit({
      scope: 'incinerator',
      key: String(incineratorId),
      kind: 'daily',
      limit: INCIN_DAILY_CAP,
      used: incUsed,
      remaining: 0,
      resetAt: nextUtcMidnightIso(),
      message: `Daily incinerator burn cap reached (${INCIN_DAILY_CAP}/day).`,
    });
  }

  // 4) Verify incinerator belongs to user
  const inc = await getIncinerator(incineratorId);
  if (!inc) {
    console.error(`❌ Incinerator not found: ${incineratorId}`);
    return;
  }
  if (String(inc.owner) !== String(user)) {
    console.error(`❌ Incinerator owner mismatch. expected=${user}, actual=${inc.owner}`);
    return;
  }

  // 5) Process burns
  for (const aid of asset_ids) {
    // refresh cap check (in case multi-asset batch)
    if (userUsed >= USER_DAILY_CAP) {
      capHit({
        scope: 'user',
        key: String(user),
        kind: 'daily',
        limit: USER_DAILY_CAP,
        used: userUsed,
        remaining: 0,
        resetAt: nextUtcMidnightIso(),
        message: `Daily user burn cap reached (${USER_DAILY_CAP}/day).`,
      });
    }
    if (incUsed >= INCIN_DAILY_CAP) {
      capHit({
        scope: 'incinerator',
        key: String(incineratorId),
        kind: 'daily',
        limit: INCIN_DAILY_CAP,
        used: incUsed,
        remaining: 0,
        resetAt: nextUtcMidnightIso(),
        message: `Daily incinerator burn cap reached (${INCIN_DAILY_CAP}/day).`,
      });
    }

    try {
      const data = await getAssetMetadata(aid);
      if (!data) {
        console.log(`Skipping ${aid}: metadata fetch failed`);
        continue;
      }

      const templateId = Number(data.template.template_id);
      const prop = await getProposal(templateId);
      if (!prop) {
        console.error(`No approved proposal for template ID ${templateId}`);
        continue;
      }

      const trashFee = prop.trash_fee;
      const cinderReward = prop.cinder_reward;

      validateAsset(trashFee, 'TRASH', 3);
      validateAsset(cinderReward, 'CINDER', 6);

      await burnNft(
        user,
        aid,
        data.collection.collection_name,
        data.schema.schema_name,
        templateId,
        incineratorId,
        trashFee,
        cinderReward
      );

      console.log(`✅ encrypted burnnft successful for asset ${aid}`);

      // Update in-memory cooldown AFTER success
      const nowMs = Date.now();

      const uKey = String(user);
      const info = burnRate.get(uKey);
      if (info) {
        info.lastBurnMs = nowMs;
        burnRate.set(uKey, info);
      }

      incinCooldown.set(String(incineratorId), nowMs);

      // ✅ Increment Mongo usage AFTER success
      await incrementDailyCounts(user, incineratorId, day, 1);

      // keep local counters for this loop
      userUsed += 1;
      incUsed += 1;

    } catch (err) {
      if (err?.code === 'CAP_HIT') throw err;
      console.error(`❌ Error processing encrypted burn for asset ${aid}:`, err.message);
      continue;
    }
  }
}
