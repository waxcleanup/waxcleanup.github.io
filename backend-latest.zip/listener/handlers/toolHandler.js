// ~/backend/listener/handlers/toolHandler.js

import { rhythmApi } from '../../utils/eosApi.js';
import { getAssetMetadata } from '../services/atomicAssets.js';

const RHYTHM_CONTRACT =
  process.env.RHYTHMFARMER_ACCOUNT || 'rhythmfarmer';

/**
 * Handle "StakeTool:<asset_id>" memo on NFT transfers.
 *
 * FLOW:
 *   - User transfers a tool NFT TO rhythmfarmer with memo:
 *         "StakeTool:<assetId>"
 *
 *   - Listener:
 *         1) verifies the memo + destination
 *         2) loads template_id from AtomicAssets
 *         3) calls rhythmfarmer::addtool(owner, asset_id, template_id)
 *
 *   - Later, user equips via a direct contract call:
 *         rhythmfarmer::equiptool(owner, asset_id)   (signed by user, not backend)
 */
export async function handleStakeTool(action) {
  const { from, to, memo, asset_ids } = action.data || {};

  console.log(
    `🛠 handleStakeTool called: from=${from}, to=${to}, memo="${memo}", asset_ids=${JSON.stringify(
      asset_ids
    )}`
  );

  // 1) Verify memo exists
  if (!memo || typeof memo !== 'string') {
    console.error('❌ Invalid memo for StakeTool');
    return;
  }

  // 2) Transfer must go to the contract
  if (to !== RHYTHM_CONTRACT) {
    console.log(
      `↩️ Transfer not going to ${RHYTHM_CONTRACT}. Skipping StakeTool handler.`
    );
    return;
  }

  // 3) Expected memo format: "StakeTool:<assetId>"
  const parts = memo.split(':').map((s) => s.trim());
  if (parts.length < 2 || parts[0] !== 'StakeTool') {
    console.log(`ℹ️ Not a StakeTool memo: "${memo}". Skipping.`);
    return;
  }

  const assetIdStr = parts[1];
  if (!/^\d+$/.test(assetIdStr)) {
    console.error(`❌ StakeTool memo assetId invalid: "${assetIdStr}"`);
    return;
  }
  const assetIdNum = Number(assetIdStr);

  // 4) (Optional) Validate the NFT matches the transfer list
  if (Array.isArray(asset_ids)) {
    const matches = asset_ids.map(String).includes(assetIdStr);
    if (!matches) {
      console.warn(
        `⚠ StakeTool: asset_id ${assetIdStr} not in transfer payload (${asset_ids.join(
          ','
        )})`
      );
      // If you want to be strict, uncomment the next line:
      // return;
    }
  }

  // 5) Get REAL template_id from AtomicAssets
  let templateIdNum;
  try {
    const meta = await getAssetMetadata(assetIdStr);

    const tpl =
      meta?.template?.template_id ??
      meta?.template_id ??
      meta?.data?.template_id;

    if (!tpl) {
      console.error(`❌ Unable to determine template_id for ${assetIdStr}`);
      return;
    }

    templateIdNum = Number(tpl);
  } catch (err) {
    console.error(
      `❌ Failed to fetch metadata for ${assetIdStr}:`,
      err.message || err
    );
    return;
  }

  // 6) Call addtool on rhythmfarmer (contract-signed)
  try {
    console.log(
      `🚀 Sending addtool: owner=${from}, asset_id=${assetIdNum}, template_id=${templateIdNum}`
    );

    await rhythmApi.transact(
      {
        actions: [
          {
            account: RHYTHM_CONTRACT,
            name: 'addtool',
            authorization: [
              {
                actor: RHYTHM_CONTRACT,
                permission: 'active',
              },
            ],
            data: {
              owner: from,
              asset_id: assetIdNum,
              template_id: templateIdNum,
            },
          },
        ],
      },
      { blocksBehind: 3, expireSeconds: 30 }
    );

    console.log(
      `✅ addtool success: owner=${from}, asset_id=${assetIdNum}, template_id=${templateIdNum}`
    );
  } catch (err) {
    console.error(
      `❌ addtool failed for owner=${from}, asset_id=${assetIdStr}:`,
      err.message || err
    );
  }
}
