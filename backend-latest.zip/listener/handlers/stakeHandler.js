// ~/backend/listener/handlers/stakeHandler.js

import config from '../../utils/config.js';
import { getAssetMetadata } from '../services/atomicAssets.js';
import { stakeNft } from '../services/cleanupActions.js';

/**
 * Handle "Stake NFT" transfers by invoking the stakeincin action on-chain
 * @param {Object} action - EOSIO transfer action payload
 */
export async function stakeHandler(action) {
  const { from: user, asset_ids, memo } = action.data;
  console.log(`🔒 stakeHandler triggered: user=${user}, memo="${memo}"`);

  // Parse memo: expected "Stake NFT:<assetId>"
  const parts = memo.split(':').map(s => s.trim());
  const assetIdFromMemo = parts[1];
  if (String(asset_ids[0]) !== assetIdFromMemo) {
    console.warn(`Memo asset ID ${assetIdFromMemo} does not match actual ${asset_ids[0]}`);
  }

  // Stake each asset (incinerator) for the user
  for (const aid of asset_ids) {
    // Fetch metadata to get template ID
    const data = await getAssetMetadata(aid);
    if (!data) {
      console.error(`Failed to fetch metadata for asset ${aid}, skipping stake.`);
      continue;
    }

    const templateId = Number(data.template.template_id);
    try {
      await stakeNft(user, aid, templateId);
      console.log(`✅ stakeincin successful for asset ${aid}`);
    } catch (err) {
      console.error(`❌ stakeincin failed for asset ${aid}:`, err.message);
    }
  }
}

