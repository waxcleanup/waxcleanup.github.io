// ~/backend/listener/handlers/nftHandler.js

import { rhythmApi } from '../../utils/eosApi.js';

/**
 * Handle "Deposit:<Type>:<assetId>:<templateId>" for compost, packs, etc.
 *
 * This is a general-purpose NFT processor.
 * Add cases inside this file as needed for:
 *   - Compost deposits (dptcompost)
 *   - Opening packs (openpack)
 *   - Future NFT → resource conversions
 *   - etc.
 */

export async function handleDeposit(action) {
  const { from, memo } = action.data || {};

  console.log(`📥 handleDeposit called for owner=${from}, memo="${memo}"`);

  if (!memo || typeof memo !== 'string') {
    console.error('❌ handleDeposit called without a valid memo');
    return;
  }

  // Expected format: "Deposit:<Type>:<assetId>:<templateId>"
  const parts = memo.split(':').map((s) => s.trim());
  if (parts.length < 4) {
    console.error(
      `❌ Invalid deposit memo "${memo}". Expected: "Deposit:<Type>:<assetId>:<templateId>"`
    );
    return;
  }

  const [actionName, type, assetIdStr, templateIdStr] = parts;

  if (actionName !== 'Deposit') {
    console.log(
      `ℹ️ Memo "${memo}" is not a Deposit memo (actionName=${actionName}), skipping.`
    );
    return;
  }

  if (!type || !assetIdStr || !templateIdStr) {
    console.error(
      `❌ Invalid deposit memo "${memo}". Missing type/assetId/templateId.`
    );
    return;
  }

  const assetId = Number(assetIdStr);
  const templateId = Number(templateIdStr);

  if (Number.isNaN(assetId) || Number.isNaN(templateId)) {
    console.error(
      `❌ Invalid assetId or templateId in deposit memo "${memo}". Parsed assetId=${assetIdStr}, templateId=${templateIdStr}`
    );
    return;
  }

  console.log(
    `📦 Parsed deposit memo → type=${type}, owner=${from}, assetId=${assetId}, templateId=${templateId}`
  );

  // Route by <Type>
  switch (type.toLowerCase()) {
    case 'compost':
      console.log('♻️ Routing to depositCompost…');
      await depositCompost(from, assetId, templateId);
      break;

    case 'pack':
      console.log('🎁 Routing to openPack…');
      await openPack(from, assetId, templateId);
      break;

    default:
      console.log(`⚠️ Deposit type "${type}" not recognized for memo "${memo}".`);
      break;
  }
}

/**
 * Burn compost NFT + credit compost
 */
async function depositCompost(owner, assetId, templateId) {
  try {
    console.log(
      `🧪 dptcompost → owner=${owner}, assetId=${assetId}, templateId=${templateId}`
    );

    await rhythmApi.transact(
      {
        actions: [
          {
            account: process.env.RHYTHMFARMER_ACCOUNT,
            name: 'dptcompost',
            authorization: [
              {
                actor: process.env.RHYTHMFARMER_ACCOUNT,
                permission: 'active',
              },
            ],
            data: {
              owner,
              asset_ids: [assetId],
              template_ids: [templateId],
            },
          },
        ],
      },
      { blocksBehind: 3, expireSeconds: 30 }
    );

    console.log(`🗑️ Compost deposited: asset ${assetId} (tpl ${templateId}) → ${owner}`);
  } catch (error) {
    console.error(
      `❌ dptcompost failed for asset ${assetId}:`,
      error.message || error
    );
  }
}

// ~/backend/listener/handlers/nftHandler.js

async function openPack(owner, assetId, templateId) {
  try {
    console.log(
      `📦 openpack → owner=${owner}, assetId=${assetId}, templateId=${templateId}`
    );

    await rhythmApi.transact(
      {
        actions: [
          {
            account: process.env.RHYTHMFARMER_ACCOUNT,
            name: 'openpack',   // your on-chain action
            authorization: [
              {
                actor: process.env.RHYTHMFARMER_ACCOUNT,
                permission: 'active',
              },
            ],
            data: {
              owner,
              // Must match ABI field names:
              pack_asset_id: assetId,
              pack_template_id: templateId,
            },
          },
        ],
      },
      { blocksBehind: 3, expireSeconds: 30 }
    );

    console.log(`🎁 Pack opened: asset ${assetId} (tpl ${templateId}) → ${owner}`);
  } catch (error) {
    console.error(
      `❌ openpack failed for asset ${assetId}:`,
      error.message || error
    );
  }
}
