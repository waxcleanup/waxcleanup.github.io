// ~/backend/listener/handlers/repairHandler.js

import config from '../../utils/config.js';
import { repairIncinerator } from '../services/cleanupActions.js';

const CLEANUP_CONTRACT = config.cleanupContract || 'cleanupcentr';
const TOKEN_CONTRACT = config.tokenContract || 'cleanuptoken';

const CINDER_SYMBOL = 'CINDER';
const CINDER_PRECISION = 6;
const MAX_POINTS = 500;

function parseAsset(quantityStr) {
  // "12.345678 CINDER"
  const s = String(quantityStr || '').trim();
  const [num, sym] = s.split(/\s+/);
  if (!num || !sym) throw new Error(`Invalid quantity format: "${s}"`);

  const [ints, decs = ''] = num.split('.');
  const precision = decs.length;

  // Normalize to integer units (no floats)
  const intPart = (ints || '0').replace(/^0+(?=\d)/, '') || '0';
  const decPart = decs;

  const unitsStr = (intPart + decPart).replace(/^0+(?=\d)/, '') || '0';

  return { sym, precision, units: BigInt(unitsStr), decs };
}

function requireToSelf(action) {
  const to = action?.data?.to;
  if (to !== CLEANUP_CONTRACT) {
    throw new Error(`Ignoring: transfer not to ${CLEANUP_CONTRACT} (to=${to})`);
  }
}

function requireTokenContract(action) {
  // Depending on your listener payload, token contract might be here:
  const acct = action?.account || action?.act?.account;
  if (acct && acct !== TOKEN_CONTRACT) {
    throw new Error(`Ignoring: unexpected token contract ${acct}`);
  }
}

function parseIncineratorId(memo) {
  const parts = String(memo || '').split(':').map(s => s.trim());
  const incineratorId = parts[1];
  if (!incineratorId || !/^\d+$/.test(incineratorId)) {
    throw new Error(`Bad memo incinerator id: "${memo}"`);
  }
  return incineratorId;
}

function pointsFromCinder(quantityStr) {
  // 1.000000 CINDER = 1 point
  const s = String(quantityStr || '').trim();
  const [num, sym] = s.split(/\s+/);
  if (sym !== CINDER_SYMBOL) throw new Error(`Repair requires ${CINDER_SYMBOL}, got ${sym}`);

  const [ints, decs = ''] = num.split('.');
  if (decs.length !== CINDER_PRECISION) {
    throw new Error(`CINDER precision must be ${CINDER_PRECISION}, got ${decs.length} in "${s}"`);
  }

  const units = BigInt(ints || '0') * 1000000n + BigInt(decs || '0');
  const points = Number(units / 1000000n); // floor
  return points;
}

/**
 * Expected memo: "repairincin:<incineratorId>"
 */
export async function repairHandler(action) {
  const { from: user, to, quantity, memo } = action.data;
  console.log(`🛠 repairHandler triggered: from=${user}, to=${to}, memo="${memo}", quantity=${quantity}`);

  try {
    requireToSelf(action);
    requireTokenContract(action);

    if (!String(memo || '').toLowerCase().startsWith('repairincin:')) {
      throw new Error(`Bad memo prefix: "${memo}"`);
    }

    const incineratorId = parseIncineratorId(memo);

    let points = pointsFromCinder(quantity);
    if (points < 1) throw new Error(`Not enough CINDER for repair: ${quantity}`);

    if (points > MAX_POINTS) {
      console.warn(`Clamping repair points ${points}→${MAX_POINTS}`);
      points = MAX_POINTS;
    }

    await repairIncinerator(user, incineratorId, points);
    console.log(`✅ repairincin dispatched for incinerator ${incineratorId} (+${points})`);
  } catch (err) {
    console.error(`❌ repair blocked/failed:`, err.message);
  }
}
