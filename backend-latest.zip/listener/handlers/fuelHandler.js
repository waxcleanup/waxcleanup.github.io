// ~/backend/listener/handlers/fuelHandler.js

import config from '../../utils/config.js';
import { loadFuel, loadEnergy } from '../services/cleanupActions.js';

/**
 * Handle "loadfuel" transfers by invoking the loadfuel action on-chain
 * Expected memo format: "loadfuel:<incineratorId>"
 * @param {Object} action - EOSIO transfer action payload
 */
export async function loadFuelHandler(action) {
  const { from: user, quantity, memo } = action.data;
  console.log(`⛽ loadFuelHandler triggered: user=${user}, memo="${memo}", quantity=${quantity}`);

  // Parse memo to extract incinerator ID
  const parts = memo.split(':').map(s => s.trim());
  const incineratorId = parts[1];

  // Extract amount (numeric part of the quantity string)
  const amount = parseFloat(quantity.split(' ')[0]);

  // Call service to load fuel
  try {
    await loadFuel(user, incineratorId, amount);
    console.log(`✅ loadfuel successful for incinerator ${incineratorId}`);
  } catch (err) {
    console.error(`❌ loadfuel failed for incinerator ${incineratorId}:`, err.message);
  }
}

/**
 * Handle "loadenergy" transfers by invoking the loadenergy action on-chain
 * Expected memo format: "loadenergy:<incineratorId>"
 * @param {Object} action - EOSIO transfer action payload
 */
export async function loadEnergyHandler(action) {
  const { from: user, memo } = action.data;
  console.log(`⚡ loadEnergyHandler triggered: user=${user}, memo="${memo}"`);

  // Parse memo to extract incinerator ID
  const parts = memo.split(':').map(s => s.trim());
  const incineratorId = parts[1];

  // Call service to load energy
  try {
    await loadEnergy(user, incineratorId);
    console.log(`✅ loadenergy successful for incinerator ${incineratorId}`);
  } catch (err) {
    console.error(`❌ loadenergy failed for incinerator ${incineratorId}:`, err.message);
  }
}
