// ~/backend/listener/handlers/burnStatus.js

import {
  USER_DAILY_CAP,
  INCIN_DAILY_CAP,
  dailyUsageUser,
  dailyUsageIncin,
  utcDayKey,
  nextUtcMidnightIso,
} from './burnCapsStore.js';

export function getBurnStatus(user, incineratorId) {
  const today = utcDayKey();

  const userDay = dailyUsageUser.get(user);
  const incDay = incineratorId ? dailyUsageIncin.get(incineratorId) : null;

  return {
    user: {
      used: userDay?.date === today ? userDay.count : 0,
      cap: USER_DAILY_CAP,
      remaining: userDay?.date === today
        ? Math.max(0, USER_DAILY_CAP - userDay.count)
        : USER_DAILY_CAP,
      resetAt: nextUtcMidnightIso(),
    },
    incinerator: incineratorId ? {
      used: incDay?.date === today ? incDay.count : 0,
      cap: INCIN_DAILY_CAP,
      remaining: incDay?.date === today
        ? Math.max(0, INCIN_DAILY_CAP - incDay.count)
        : INCIN_DAILY_CAP,
      resetAt: nextUtcMidnightIso(),
    } : null,
  };
}
