// ~/backend/listener/handlers/burnCapsStore.js

export const USER_DAILY_CAP = 1000;
export const INCIN_DAILY_CAP = 300;

export const burnRate = new Map();
export const incinCooldown = new Map();
export const dailyUsageUser = new Map();
export const dailyUsageIncin = new Map();

export function utcDayKey() {
  return new Date().toISOString().slice(0, 10); // UTC "YYYY-MM-DD"
}

export function nextUtcMidnightIso() {
  const now = new Date();
  const next = new Date(
    Date.UTC(
      now.getUTCFullYear(),
      now.getUTCMonth(),
      now.getUTCDate() + 1,
      0, 0, 0, 0
    )
  );
  return next.toISOString();
}

export function recordBurnSuccess(user, incineratorId, amount = 1) {
  const today = utcDayKey();

  let userDay = dailyUsageUser.get(user);
  if (!userDay || userDay.date !== today) userDay = { date: today, count: 0 };
  userDay.count += amount;
  dailyUsageUser.set(user, userDay);

  let incDay = dailyUsageIncin.get(incineratorId);
  if (!incDay || incDay.date !== today) incDay = { date: today, count: 0 };
  incDay.count += amount;
  dailyUsageIncin.set(incineratorId, incDay);

  return { userDay, incDay };
}
