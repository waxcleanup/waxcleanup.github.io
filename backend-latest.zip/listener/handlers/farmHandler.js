// ~/backend/listener/handlers/farmHandler.js

import { rhythmApi } from '../../utils/eosApi.js';

/**
 * Handle "Stake Farm:<assetId>:<templateId>" transfers by creating a farm
 */
export async function handleFarmStake(action) {
  const { from, memo } = action.data;
  const parts = memo.split(':').map(s => s.trim());
  const [, assetId, templateId] = parts;

  if (!assetId || !templateId) {
    console.error("Missing farm stake parameters in memo. Format: 'Stake Farm:<assetId>:<templateId>'");
    return;
  }

  try {
    await rhythmApi.transact(
      {
        actions: [
          {
            account: process.env.RHYTHMFARMER_ACCOUNT,
            name: 'createfarm',
            authorization: [
              {
                actor: process.env.RHYTHMFARMER_ACCOUNT,
                permission: 'active',
              },
            ],
            data: {
              owner: from,
              asset_id: assetId,
              template_id: Number(templateId),
            },
          },
        ],
      },
      { blocksBehind: 3, expireSeconds: 30 }
    );
    console.log(`✅ Farm created: asset ${assetId} by ${from}`);
  } catch (error) {
    console.error(`❌ Failed to create farm for asset ${assetId}:`, error.message);
  }
}

/**
 * Handle "Stake Cell:<farmId>:<assetId>:<templateId>" transfers by adding a battery to a farm
 */
export async function handleFarmCellStake(action) {
  const { from, memo } = action.data;
  const parts = memo.split(':').map(s => s.trim());
  const [, farmId, assetId, templateId] = parts;

  if (!farmId || !assetId || !templateId) {
    console.error("Missing parameters. Format: 'Stake Cell:<farmId>:<assetId>:<templateId>'");
    return;
  }

  try {
    await rhythmApi.transact(
      {
        actions: [
          {
            account: process.env.RHYTHMFARMER_ACCOUNT,
            name: 'addfarmbat',
            authorization: [
              {
                actor: process.env.RHYTHMFARMER_ACCOUNT,
                permission: 'active',
              },
            ],
            data: {
              farm_id: farmId,
              tpl_id: Number(templateId),
              ast_id: assetId,
              owner: from,
            },
          },
        ],
      },
      { blocksBehind: 3, expireSeconds: 30 }
    );
    console.log(`✅ Battery staked to farm ${farmId}: asset ${assetId} by ${from}`);
  } catch (error) {
    console.error(`❌ Failed to stake battery ${assetId} to farm ${farmId}:`, error.message);
  }
}

/**
 * Handle "Stake UserCell" transfers by adding a battery to a user.
 *
 * Preferred memo:
 *  - "Stake UserCell:<assetId>:<templateId>"   → user = from
 *
 * Legacy memo (still supported):
 *  - "Stake UserCell:<user>:<assetId>:<templateId>"
 */
export async function handleUserCellStake(action) {
  const { from, memo } = action.data;
  const parts = memo.split(':').map(s => s.trim());

  let user = null;
  let assetId = null;
  let templateId = null;

  // Preferred: Stake UserCell:<assetId>:<templateId>
  if (parts.length >= 3 && parts[1] && parts[2] && !parts[3]) {
    user = from;
    assetId = parts[1];
    templateId = parts[2];
  } else {
    // Legacy: Stake UserCell:<user>:<assetId>:<templateId>
    [, user, assetId, templateId] = parts;
  }

  if (!user || !assetId || !templateId) {
    console.error(
      "Missing parameters. Format: 'Stake UserCell:<assetId>:<templateId>' (preferred) OR 'Stake UserCell:<user>:<assetId>:<templateId>' (legacy)"
    );
    return;
  }

  try {
    await rhythmApi.transact(
      {
        actions: [
          {
            account: process.env.RHYTHMFARMER_ACCOUNT,
            name: 'addubat',
            authorization: [
              {
                actor: process.env.RHYTHMFARMER_ACCOUNT,
                permission: 'active',
              },
            ],
            data: {
              user,
              ast_id: assetId,
              tpl_id: Number(templateId),
            },
          },
        ],
      },
      { blocksBehind: 3, expireSeconds: 30 }
    );
    console.log(`🔋 User battery staked for user ${user}: asset ${assetId}`);
  } catch (error) {
    console.error(`❌ Failed to stake user battery ${assetId} for user ${user}:`, error.message);
  }
}

/**
 * Handle "Recharge Farm:<farmId>" transfers by charging a farm battery.
 *
 * IMPORTANT CONTRACT ALIGNMENT:
 * - chargefarm(uint64_t farm_id, asset qty)
 * - require_auth(get_self()) so backend signs it
 * - farm_id is uint64 -> pass as STRING (avoid JS precision loss)
 * - param name must be `qty` (NOT `cinder`)
 */
export async function handleRechargeFarm(action) {
  const { from, memo, quantity } = action.data;
  const parts = memo.split(':').map(s => s.trim());
  const [, farmId] = parts;

  if (!farmId) {
    console.error("Missing farm ID. Format: 'Recharge Farm:<farmId>'");
    return;
  }

  try {
    await rhythmApi.transact(
      {
        actions: [
          {
            account: process.env.RHYTHMFARMER_ACCOUNT,
            name: 'chargefarm',
            authorization: [
              {
                actor: process.env.RHYTHMFARMER_ACCOUNT,
                permission: 'active',
              },
            ],
            data: {
              farm_id: String(farmId), // ✅ uint64 safe
              qty: quantity,           // ✅ correct param name
            },
          },
        ],
      },
      { blocksBehind: 3, expireSeconds: 30 }
    );
    console.log(`⚡ Recharged farm ${farmId} with ${quantity} from ${from}`);
  } catch (error) {
    console.error(`❌ Failed to recharge farm ${farmId}:`, error.message);
  }
}

/**
 * Handle "Recharge User" transfers by calling chguser.
 *
 * Memo formats supported:
 *  - "Recharge User"                → recharge the `from` account
 *  - "Recharge User:<user>"         → explicitly specify the user
 *
 * quantity is passed as `qty` into chguser (asset string).
 * chguser enforces config & symbol/precision checks.
 */
export async function handleUserRecharge(action) {
  const { from, memo, quantity } = action.data;

  const parts = memo.split(':').map(s => s.trim());
  let user = from;

  // Optional override: "Recharge User:someuser"
  if (parts.length > 1 && parts[1]) {
    user = parts[1];
  }

  if (!user) {
    console.error("Missing user for Recharge User memo");
    return;
  }

  try {
    await rhythmApi.transact(
      {
        actions: [
          {
            account: process.env.RHYTHMFARMER_ACCOUNT,
            name: 'chguser',
            authorization: [
              {
                actor: process.env.RHYTHMFARMER_ACCOUNT,
                permission: 'active',
              },
            ],
            data: {
              user,
              qty: quantity, // asset string "X.XXXXXX CINDER"
            },
          },
        ],
      },
      { blocksBehind: 3, expireSeconds: 30 }
    );
    console.log(`💚 Recharged user ${user} with ${quantity}`);
  } catch (error) {
    console.error(`❌ Failed to recharge user ${user} with ${quantity}:`, error.message);
  }
}
/**
 * Handle "Stake Plot:<farmId>:<assetId>:<templateId>" transfers
 * Creates a plot entry in the contract.
 */
/**
 * Handle "Stake Plot:<farmId>:<assetId>:<templateId>" transfers by creating a plot
 * Contract action: createplot(owner, farm_id, plot_asset_id, plot_tpl_id)
 */
export async function handlePlotStake(action) {
  const { from, memo } = action.data;
  const parts = memo.split(':').map((s) => s.trim());
  const [, farmId, assetId, templateId] = parts;

  if (!farmId || !assetId || !templateId) {
    console.error("Missing parameters. Format: 'Stake Plot:<farmId>:<assetId>:<templateId>'");
    return;
  }

  try {
    await rhythmApi.transact(
      {
        actions: [
          {
            account: process.env.RHYTHMFARMER_ACCOUNT,
            name: 'createplot',
            authorization: [
              {
                actor: process.env.RHYTHMFARMER_ACCOUNT,
                permission: 'active',
              },
            ],
            data: {
              owner: from,
              farm_id: String(farmId),
              plot_asset_id: String(assetId),
              plot_tpl_id: Number(templateId),
            },
          },
        ],
      },
      { blocksBehind: 3, expireSeconds: 30 }
    );

    console.log(`✅ Plot created: plot ${assetId} -> farm ${farmId} (owner ${from})`);
  } catch (error) {
    console.error(`❌ Failed to create plot ${assetId} for farm ${farmId}:`, error.message);
  }
}
