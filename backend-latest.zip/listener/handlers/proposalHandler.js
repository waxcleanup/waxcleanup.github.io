// ~/backend/listener/handlers/proposalHandler.js
import config from '../../utils/config.js';
import { createProposal } from '../services/cleanupActions.js';

// format "amount SYMBOL", auto-filling symbol + decimals if missing
function normalizeAsset(raw, decimals, symbol) {
  const decs = Number(decimals);
  const base = `0.${'0'.repeat(decs)} ${symbol}`;
  if (!raw) return base;

  let s = String(raw).trim().replace(/,/g, '');
  // if symbol is present anywhere (case-insensitive), strip and rebuild later
  s = s.replace(new RegExp(`\\s*${symbol}\\s*$`, 'i'), '').trim();

  const num = Number(s);
  const fixed = Number.isFinite(num) ? num.toFixed(decs) : `0.${'0'.repeat(decs)}`;
  return `${fixed} ${symbol}`;
}

// map common variants to chain’s canonical string
function normalizeProposalType(raw) {
  const k = String(raw || '').trim().toLowerCase().replace(/\s+/g, '');
  const aliases = new Set(['nftburn','burnnft','burn','nft-burn','nft_burn']);
  return aliases.has(k) ? 'NFT Burn' : raw;
}

export async function proposalHandler(action) {
  const { from: proposer, memo } = action.data;
  console.log(`📑 proposalHandler triggered: proposer=${proposer}, memo="${memo}"`);

  if (!memo || !memo.startsWith(`${config.proposalMemo}:`)) {
    console.error('❌ Invalid proposal memo prefix.');
    return;
  }

  const parts = memo.split(':').map(s => s.trim());
  // expected: ['proposal', type, collection, schema, templateId, trashFee, cinderReward]
  if (parts.length < 7) {
    console.error('❌ Invalid proposal memo format. Got parts:', parts);
    return;
  }

  const [_, rawType, collection, schema, rawTemplateId, rawTrashFee, rawCinderReward] = parts;

  const proposalType = normalizeProposalType(rawType);      // -> "NFT Burn"
  const templateId = Number(rawTemplateId);
  if (!Number.isFinite(templateId) || templateId <= 0) {
    console.error(`❌ templateId invalid: "${rawTemplateId}"`);
    return;
  }

  const trashFee     = normalizeAsset(rawTrashFee, 3, 'TRASH');       // "xxxxx.xxx TRASH"
  const cinderReward = normalizeAsset(rawCinderReward, 6, 'CINDER');  // "y.yyyyyy CINDER"

  console.log(`🧩 createprop payload:
    proposer     = ${proposer}
    proposalType = ${proposalType}
    collection   = ${collection}
    schema       = ${schema}
    templateId   = ${templateId}
    trashFee     = ${trashFee}
    cinderReward = ${cinderReward}
  `);

  try {
    const result = await createProposal(
      proposer,
      proposalType,
      collection,
      schema,
      templateId,
      trashFee,
      cinderReward
    );
    console.log('✅ createprop ok:', JSON.stringify(result || {}, null, 2));
  } catch (err) {
    console.error('❌ createprop failed:', err?.message || err);
  }
}
