// controllers/treeNftsController.js
import { JsonRpc } from 'eosjs';
import fetch from 'node-fetch';
import dotenv from 'dotenv';

dotenv.config();

const rpc = new JsonRpc(process.env.WAX_MAINNET_API, { fetch });
// Use CryptoLions mirror for AtomicAssets API
const ATOMICASSETS_API = process.env.ATOMICASSETS_MAINNET_API_ENDPOINT || 'https://atomic-api.wax.cryptolions.io';

// GET /api/nfts/registered
export const getRegisteredTemplates = async (req, res) => {
  try {
    const { rows } = await rpc.get_table_rows({
      json: true,
      code: 'rhythmfarmer',
      scope: 'rhythmfarmer',
      table: 'nfts',
      limit: 1000,
    });

    const enriched = await Promise.all(
      rows.map(async nft => {
        try {
          const tplRes = await fetch(
            `${ATOMICASSETS_API}/atomicassets/v1/templates/${nft.collection}/${nft.template_id}`
          );
          const tplJson = await tplRes.json();
          if (tplJson.data?.immutable_data) {
            const imm = tplJson.data.immutable_data;
            const cid = imm.image ?? imm.img;
            if (cid) {
              nft.image = cid.startsWith('http')
                ? cid
                : `https://ipfs.io/ipfs/${cid}`;
            }
            nft.name = imm.name || `Template #${nft.template_id}`;
          }
        } catch (_) {}
        return nft;
      })
    );

    res.json({ templates: enriched });
  } catch (error) {
    console.error('getRegisteredTemplates:', error);
    res.status(500).json({ error: 'Failed to fetch registered NFT templates' });
  }
};

// GET /api/nfts/user-assets/:wallet
export const getUserRegisteredNFTs = async (req, res) => {
  const { wallet } = req.params;
  try {
    const { rows } = await rpc.get_table_rows({
      json: true,
      code: 'rhythmfarmer',
      scope: 'rhythmfarmer',
      table: 'nfts',
      limit: 1000,
    });

    if (!rows.length) {
      console.log("No registered templates found in contract.");
      return res.json({ wallet, assets: [] });
    }

    const collectionGroups = {};
    for (const row of rows) {
      (collectionGroups[row.collection] ??= []).push(row.template_id);
    }

    let allAssets = [];

    for (const [collection, templateIds] of Object.entries(collectionGroups)) {
      const templateWhitelistParams = templateIds
        .map(tid => `template_whitelist=${tid}`)
        .join('&');

      const apiUrl = `${ATOMICASSETS_API}/atomicassets/v1/assets?owner=${wallet}&collection_name=${collection}&${templateWhitelistParams}&page=1&limit=1000`;
      console.log(`Fetching from AtomicAssets API: ${apiUrl}`);

      const response = await fetch(apiUrl);
      const json = await response.json();

      if (!json.success) {
        console.error(`Failed to fetch assets for collection ${collection}:`, json);
        continue;
      }

      const data = json.data || [];
      const assets = data.map(asset => {
        const cid = asset.data.image ?? asset.data.img;
        const imageUrl = cid
          ? (cid.startsWith('http') ? cid : `https://ipfs.io/ipfs/${cid}`)
          : '';
        return {
          asset_id: asset.asset_id,
          template_id: asset.template.template_id,
          collection_name: asset.collection.collection_name,
          name: asset.data.name,
          image: imageUrl,
        };
      });

      allAssets = allAssets.concat(assets);
    }

    res.json({ wallet, assets: allAssets });
  } catch (error) {
    console.error('getUserRegisteredNFTs Error:', error);
    res.status(500).json({ error: 'Failed to fetch user registered NFTs' });
  }
};

// GET /api/nfts/collection/:collection/:wallet[?templateId=...]
export const getNFTsByCollection = async (req, res) => {
  const { collection, wallet } = req.params;
  const { templateId } = req.query;

  try {
    let apiUrl = `${ATOMICASSETS_API}/atomicassets/v1/assets?owner=${wallet}&collection_name=${collection}&page=1&limit=1000`;
    if (templateId) apiUrl += `&template_id=${templateId}`;

    const response = await fetch(apiUrl);
    const { data } = await response.json();

    const assets = data.map(asset => {
      const cid = asset.data.image ?? asset.data.img;
      const imageUrl = cid
        ? (cid.startsWith('http') ? cid : `https://ipfs.io/ipfs/${cid}`)
        : '';
      return {
        asset_id: asset.asset_id,
        template_id: asset.template.template_id,
        collection_name: asset.collection.collection_name,
        name: asset.data.name,
        image: imageUrl,
      };
    });

    res.json({
      collection,
      wallet,
      count: assets.length,
      nfts: assets,
    });
  } catch (error) {
    console.error('getNFTsByCollection:', error);
    res.status(500).json({ error: 'Failed to fetch NFTs by collection' });
  }
};

// GET /api/nfts/registered/:collection
export const getRegisteredTemplatesByCollection = async (req, res) => {
  const { collection } = req.params;
  try {
    const { rows } = await rpc.get_table_rows({
      json: true,
      code: 'rhythmfarmer',
      scope: 'rhythmfarmer',
      table: 'nfts',
      limit: 1000,
    });

    const filtered = rows.filter(r => r.collection === collection);
    const enriched = await Promise.all(
      filtered.map(async nft => {
        try {
          const tplRes = await fetch(
            `${ATOMICASSETS_API}/atomicassets/v1/templates/${nft.collection}/${nft.template_id}`
          );
          const tplJson = await tplRes.json();
          if (tplJson.data?.immutable_data) {
            const imm = tplJson.data.immutable_data;
            const cid = imm.image ?? imm.img;
            if (cid) {
              nft.image = cid.startsWith('http')
                ? cid
                : `https://ipfs.io/ipfs/${cid}`;
            }
            nft.name = imm.name || `Template #${nft.template_id}`;
          }
        } catch (_) {}
        return nft;
      })
    );

    res.json({ collection, templates: enriched });
  } catch (error) {
    console.error('getRegisteredTemplatesByCollection:', error);
    res.status(500).json({ error: 'Failed to fetch templates by collection' });
  }
};
