// controllers/userEnergyController.js
import dotenv from "dotenv";
import { JsonRpc } from "eosjs";
import fetch from "node-fetch";

dotenv.config();

const RPC_ENDPOINT =
  process.env.RPC_ENDPOINT ||
  process.env.WAX_MAINNET_API ||
  process.env.WAX_TESTNET_API ||
  "https://wax.greymass.com";

const CONTRACT_ACCOUNT = process.env.RHYTHMFARMER_ACCOUNT || "rhythmfarmer";
const COLLECTION = process.env.COLLECTION || "cleanupcentr";

// Prefer multiple mirrors like bagController does
const ATOMIC_ENDPOINTS = [
  process.env.ATOMICASSETS_MAINNET_API_ENDPOINT || "https://wax.api.atomicassets.io",
  "https://atomic-api.wax.cryptolions.io",
  "https://atomic.3dkrender.com",
];

const rpc = new JsonRpc(RPC_ENDPOINT, { fetch });

// -------------------------------------------------------------
// CID normalizer (same idea as bagController)
// -------------------------------------------------------------
function normalizeImgToCid(img) {
  if (!img) return null;
  const s = String(img).trim();

  // ipfs://CID or ipfs://ipfs/CID
  if (s.startsWith("ipfs://")) {
    return s.replace("ipfs://", "").replace(/^ipfs\//, "");
  }

  // URL containing /ipfs/CID
  const match = s.match(/\/ipfs\/([a-zA-Z0-9]+)/);
  if (match?.[1]) return match[1];

  // already CID-ish
  if (s.startsWith("Qm") || s.length > 40) return s;

  return null;
}

// -------------------------------------------------------------
// Tiny template meta cache
// -------------------------------------------------------------
const templateCache = new Map();

async function fetchTemplateMetaCached(templateId) {
  const key = `${COLLECTION}:${String(templateId)}`;
  if (templateCache.has(key)) return templateCache.get(key);

  let lastErr;

  for (const base of ATOMIC_ENDPOINTS) {
    try {
      // AtomicAssets REST template endpoint
      const url = `${base.replace(/\/$/, "")}/atomicassets/v1/templates/${COLLECTION}/${templateId}`;
      const res = await fetch(url);
      const json = await res.json();

      if (!json?.success || !json?.data) {
        lastErr = new Error("Atomic template not found");
        continue;
      }

      const imm = json.data.immutable_data || {};
      const name = imm.name || `Template #${templateId}`;
      const img = imm.img || imm.image || null;

      const meta = { name, image: normalizeImgToCid(img) };
      templateCache.set(key, meta);
      return meta;
    } catch (e) {
      lastErr = e;
      continue;
    }
  }

  const meta = { name: `Template #${templateId}`, image: null };
  templateCache.set(key, meta);
  return meta;
}

export const getUserEnergy = async (req, res) => {
  const { account } = req.params;

  if (!account) {
    return res.status(400).json({ message: "Missing account in path" });
  }

  try {
    // ✅ direct row lookup by primary key (name)
    const userEnergyRes = await rpc.get_table_rows({
      json: true,
      code: CONTRACT_ACCOUNT,
      scope: CONTRACT_ACCOUNT,
      table: "userenergy",
      lower_bound: account,
      upper_bound: account,
      limit: 1,
    });

    const row = (userEnergyRes.rows || [])[0] || null;
    const bats = row?.bats || [];

    // Collect unique template_ids (usually just 1)
    const uniqueTpls = [...new Set(bats.map((b) => Number(b.template_id)))];

    // Fetch template meta for each unique template id (cached)
    const tplMeta = new Map();
    for (const tid of uniqueTpls) {
      tplMeta.set(tid, await fetchTemplateMetaCached(tid));
    }

    const out = {
      account,
      energy: row ? Number(row.energy || 0) : 0,
      max: row ? Number(row.max || 0) : 0,
      count: row ? Number(row.count || 0) : 0,
      total_staked: bats.length,
      staked: bats.map((b) => {
        const tid = Number(b.template_id);
        const meta = tplMeta.get(tid) || {};
        return {
          asset_id: String(b.asset_id),
          template_id: tid,
          owner: b.owner,

          // ✅ display fields (CID only, no gateway)
          name: meta.name || null,
          image: meta.image || null,
        };
      }),
    };

    // Avoid caching so refresh shows immediately
    res.set("Cache-Control", "no-store");
    return res.json(out);
  } catch (error) {
    console.error("[getUserEnergy] Error:", error);
    return res.status(500).json({
      message: "Failed to load user energy",
      error: error.message || String(error),
    });
  }
};
