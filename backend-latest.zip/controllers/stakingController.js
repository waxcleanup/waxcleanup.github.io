import { api } from '../services/eosService.js';
import StakedFarm from '../models/StakedFarm.js';

export const stakeNFT = async (req, res) => {
  const { user, nft_id, power_level } = req.body;

  try {
    const action = {
      account: process.env.REACT_APP_CONTRACT_NAME,
      name: 'stakefarm',
      authorization: [{ actor: user, permission: 'active' }],
      data: { owner: user, nft_id,
