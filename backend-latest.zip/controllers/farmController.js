// controllers/farmController.js
import { Api, JsonRpc } from 'eosjs';
import { JsSignatureProvider } from 'eosjs/dist/eosjs-jssig.js';
import fetch from 'node-fetch';
import { TextEncoder, TextDecoder } from 'util';
import dotenv from 'dotenv';

dotenv.config();

// RPC + signing
const rpc = new JsonRpc(
  process.env.RPC_ENDPOINT ||
    process.env.WAX_MAINNET_API ||
    process.env.WAX_TESTNET_API ||
    'https://wax.greymass.com',
  { fetch }
);

const privateKeys = [process.env.RHYTHMFARMER_PRIVATE_KEY];
const signatureProvider = new JsSignatureProvider(privateKeys);

const api = new Api({
  rpc,
  signatureProvider,
  textDecoder: new TextDecoder(),
  textEncoder: new TextEncoder(),
});

const contractAccount = process.env.RHYTHMFARMER_ACCOUNT || 'rhythmfarmer';
const COLLECTION = process.env.COLLECTION || 'cleanupcentr';
const ATOMIC_API =
  process.env.ATOMICASSETS_MAINNET_API_ENDPOINT ||
  'https://wax.api.atomicassets.io';

// ---------------------------------------------------------------------
// GET /api/farms
//  - Returns all farms from on-chain `farms` table
//  - Enriches with AtomicAssets metadata (name, image)
//  - Enriches with farm energy info from `farmenergy` table
//  - Normalizes fields for the Farming UI (farm_energy, asset_id as string)
// ---------------------------------------------------------------------
export const getAllFarms = async (req, res) => {
  try {
    const { rows = [] } = await rpc.get_table_rows({
      json: true,
      code: contractAccount,
      scope: contractAccount,
      table: 'farms',
      limit: 1000,
    });

    const enriched = await Promise.all(
      rows.map(async (farm) => {
        // Start with a shallow copy
        const f = { ...farm };

        // Normalize ID fields for the UI
        f.asset_id = String(farm.asset_id);
        f.template_id = Number(farm.template_id);
        f.owner = farm.owner;
        f.created_at = farm.created_at;

        // Normalize reward_pool so UI doesn't show "CINDER CINDER"
        if (typeof farm.reward_pool === 'string') {
          // e.g. "12.345678 CINDER" -> "12.345678"
          f.reward_pool = farm.reward_pool.split(' ')[0];
        } else {
          f.reward_pool = farm.reward_pool;
        }

        // -----------------------------------------------------------------
        // 1) Attach image + name from AtomicAssets
        // -----------------------------------------------------------------
        try {
          const tplRes = await fetch(
            `${ATOMIC_API}/atomicassets/v1/templates/${COLLECTION}/${f.template_id}`
          );
          const tplJson = await tplRes.json();
          if (tplJson.success && tplJson.data?.immutable_data) {
            const imm = tplJson.data.immutable_data;
            const img = imm.img || imm.image;
            f.image = img
              ? img.startsWith('http')
                ? img
                : `https://ipfs.io/ipfs/${img}`
              : null;
            f.name = imm.name || `Farm #${f.asset_id.slice(-4)}`;
          }
        } catch (e) {
          console.warn(
            `AtomicAssets lookup failed for farm ${f.asset_id}:`,
            e.message
          );
        }

        // -----------------------------------------------------------------
        // 2) Attach farm energy info from `farmenergy` table
        // -----------------------------------------------------------------
        try {
          const energyRes = await rpc.get_table_rows({
            json: true,
            code: contractAccount,
            scope: contractAccount,
            table: 'farmenergy',
            lower_bound: farm.asset_id,
            upper_bound: farm.asset_id,
            limit: 1,
          });

          if (energyRes.rows.length > 0) {
            const e = energyRes.rows[0];

            // Main energy numbers
            f.farm_energy = Number(e.energy);
            f.farm_energy_max = Number(e.max);
            f.farm_cell_count = Number(e.count);

            // Full list of staked batteries (bats)
            f.farm_cells = Array.isArray(e.bats) ? e.bats : [];
          } else {
            f.farm_energy = 0;
            f.farm_energy_max = 0;
            f.farm_cell_count = 0;
            f.farm_cells = [];
          }
        } catch (err) {
          console.warn(
            `farmenergy lookup failed for farm ${farm.asset_id}:`,
            err.message
          );
          f.farm_energy = 0;
          f.farm_energy_max = 0;
          f.farm_cell_count = 0;
          f.farm_cells = [];
        }

        return f;
      })
    );

    res.json({ farms: enriched, count: enriched.length });
  } catch (error) {
    console.error('Failed to fetch farms:', error);
    res.status(500).json({
      message: 'Failed to fetch farms',
      error: error.message,
    });
  }
};

// ---------------------------------------------------------------------
// POST /api/farms/unstake
//  - Backend-signed call to rhythmfarmer::unstakefarm
//  - Used by the "Unstake Farm" button in the UI
// ---------------------------------------------------------------------
export const unstakeFarm = async (req, res) => {
  const { owner, asset_id } = req.body;

  if (!owner || !asset_id) {
    return res
      .status(400)
      .json({ success: false, message: 'Missing owner or asset_id' });
  }

  if (!process.env.RHYTHMFARMER_PRIVATE_KEY) {
    return res.status(500).json({
      success: false,
      message: 'Server misconfigured: RHYTHMFARMER_PRIVATE_KEY is not set',
    });
  }

  try {
    const result = await api.transact(
      {
        actions: [
          {
            account: contractAccount,
            name: 'unstakefarm',
            authorization: [{ actor: contractAccount, permission: 'active' }],
            data: { owner, asset_id: Number(asset_id) },
          },
        ],
      },
      { blocksBehind: 3, expireSeconds: 30 }
    );

    res.json({ success: true, transaction_id: result.transaction_id });
  } catch (error) {
    console.error('Unstake farm failed:', error);
    res
      .status(500)
      .json({ success: false, message: error.message || 'Unstake failed' });
  }
};
