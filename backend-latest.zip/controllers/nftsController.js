// controllers/nftsController.js
import dotenv from 'dotenv';
import axios from 'axios';
import { ExplorerApi } from 'atomicassets';
import { JsonRpc } from 'eosjs';
import fetch from 'node-fetch';

dotenv.config();

// Mirrors for AtomicAssets API
const ATOMIC_ENDPOINTS = [
  'https://atomic-api.wax.cryptolions.io',
  'https://atomic.3dkrender.com',
  process.env.ATOMICASSETS_MAINNET_API_ENDPOINT || 'https://wax.api.atomicassets.io'
];

// EOS RPC
const rpc = new JsonRpc('https://wax.greymass.com', { fetch });

async function callAtomic(fn) {
  let lastErr;
  for (const baseUrl of ATOMIC_ENDPOINTS) {
    try {
      const api = new ExplorerApi(baseUrl, 'atomicassets', { fetch });
      api.getConfig = async () => ({ collections: {}, schemas: {}, templates: {} });
      return await fn(api);
    } catch (error) {
      console.warn(`AtomicAssets @ ${baseUrl} failed: ${error.message}`);
      lastErr = error;
    }
  }
  throw lastErr;
}

// Simple in-memory cache for template metadata
const templateCache = new Map();

/**
 * Normalize template img field to a CID only (no gateway URL).
 */
function normalizeImgToCid(img) {
  if (!img) return null;

  const s = String(img).trim();

  // ipfs://CID
  if (s.startsWith('ipfs://')) {
    return s.replace('ipfs://', '');
  }

  // URL that contains /ipfs/CID
  const match = s.match(/ipfs\/([a-zA-Z0-9]+)/);
  if (match) return match[1];

  // Already a CID (common)
  if (s.startsWith('Qm') || s.length > 40) {
    return s;
  }

  return null;
}

/**
 * Get template metadata (name/img CID) using Atomic mirrors with caching.
 * This is used ONLY for display (Burn Room cards),
 * while ownership comes from on-chain atomicassets::assets.
 */
async function getTemplateMetaCached(collection, templateId) {
  const key = `${String(collection)}:${String(templateId)}`;
  if (templateCache.has(key)) return templateCache.get(key);

  try {
    const tpl = await callAtomic((api) => api.getTemplate(collection, templateId));

    const immutable = tpl?.immutable_data || {};
    const name = immutable?.name || null;

    // ✅ FIX: use CID normalizer (the previous code mistakenly called normalizeImgToUrl)
    const img = normalizeImgToCid(immutable?.img);

    const meta = { name, img };
    templateCache.set(key, meta);
    return meta;
  } catch (err) {
    console.warn(`Template meta fetch failed (${collection}:${templateId}): ${err.message}`);
    const meta = { name: null, img: null };
    templateCache.set(key, meta);
    return meta;
  }
}

// GET /nfts/:account
export const getNFTs = async (req, res) => {
  const { account } = req.params;
  try {
    const assets = await callAtomic(api =>
      api.getAssets({ owner: account, limit: 100 })
    );

    if (!assets || assets.length === 0) {
      return res.status(404).json({ message: 'No NFTs found for this account.' });
    }

    const nftsWithMetadata = assets.map(asset => ({
      asset_id: asset.asset_id,
      name: asset.template.immutable_data.name || null,
      image: asset.template.immutable_data.img || null,
      template_id: asset.template.template_id,
      ...asset
    }));

    res.json({ nfts: nftsWithMetadata });
  } catch (error) {
    console.error('Error fetching NFTs:', error);
    res.status(500).json({ message: 'Error fetching NFTs', error: error.message });
  }
};

// GET /nfts/status/:nftId
export const getNFTStatus = async (req, res) => {
  const { nftId } = req.params;
  try {
    const nft = await callAtomic(api => api.getAsset(nftId));
    if (!nft) return res.status(404).json({ message: 'NFT not found' });

    const nftStatus = {
      asset_id: nft.asset_id,
      name: nft.template.immutable_data.name || null,
      image: nft.template.immutable_data.img || null,
      template_id: nft.template.template_id,
      owner: nft.owner,
      ...nft
    };

    res.json(nftStatus);
  } catch (error) {
    console.error(`Error fetching NFT status for ID ${nftId}:`, error);
    res.status(500).json({ message: 'Error fetching NFT status', error: error.message });
  }
};

// GET /nfts/farm/:wallet
export const getFarmByWallet = async (req, res) => {
  const { wallet } = req.params;

  try {
    // 1) On-chain: staked farms (contract table)
    const allFarms = await rpc.get_table_rows({
      json: true,
      code: 'rhythmfarmer',
      scope: 'rhythmfarmer',
      table: 'farms',
      limit: 500,
    });

    const staked = (allFarms.rows || []).filter((farm) => farm.owner === wallet);

    // 2) On-chain config: find the Farm template config in rhythmfarmer::nfts
    const nftTemplates = await rpc.get_table_rows({
      json: true,
      code: 'rhythmfarmer',
      scope: 'rhythmfarmer',
      table: 'nfts',
      limit: 1000,
    });

    const farmEntry = (nftTemplates.rows || []).find(
      (row) =>
        String(row.nft_type || '').toLowerCase() === 'farm' &&
        String(row.collection || '').toLowerCase() === 'cleanupcentr'
    );

    // Default response fields
    let unstaked = [];
    let name = null;
    let ipfs = null; // ✅ CID ONLY
    let template_id = null;

    if (farmEntry) {
      template_id = farmEntry.template_id;

      // 3) AtomicAssets: fetch template metadata once (name/img)
      try {
        const templateData = await callAtomic((api) =>
          api.getTemplate(farmEntry.collection, farmEntry.template_id)
        );

        if (templateData?.immutable_data) {
          name = templateData.immutable_data.name || null;

          // ✅ CID ONLY (no gateway)
          const rawImg = templateData.immutable_data.img || null;
          ipfs = normalizeImgToCid(rawImg);
        }
      } catch (err) {
        console.warn('Template fetch failed:', err.message);
      }

      // 4) AtomicAssets: fetch unstaked farms owned by wallet (FILTERED QUERY)
      try {
        const assets = await callAtomic((api) =>
          api.getAssets({
            owner: wallet,
            collection_name: farmEntry.collection,
            schema_name: farmEntry.schema,
            template_id: String(farmEntry.template_id),
            limit: 100,
            page: 1,
            order: 'desc',
            sort: 'asset_id',
          })
        );

        unstaked = (assets || []).map((a) => {
          const aRawImg = a.template?.immutable_data?.img || null;
          const aCid = normalizeImgToCid(aRawImg) || ipfs;

          return {
            asset_id: String(a.asset_id),
            template_id: String(a.template?.template_id ?? farmEntry.template_id),
            collection: String(farmEntry.collection),
            schema: String(farmEntry.schema),

            name: a.template?.immutable_data?.name || name,

            // ✅ CID ONLY (no gateway)
            image: aCid || null,
          };
        });
      } catch (err) {
        console.warn('Unstaked farm assets fetch failed:', err.message);
        unstaked = [];
      }
    }

    res.json({
      staked,
      unstaked,
      cells: [],
      count: { staked: staked.length, unstaked: unstaked.length },
      template_id,
      name,
      ipfs, // ✅ CID ONLY
    });
  } catch (error) {
    console.error('Error fetching farm info:', error);
    res.status(500).json({
      message: 'Failed to fetch farm info',
      error: error.message,
    });
  }
};

// Helper: page through atomicassets::assets for a given owner
async function fetchAtomicAssetsPaged(owner, { pageLimit = 1000, maxPages = 80 } = {}) {
  const all = [];
  let lower_bound = 0;

  for (let page = 0; page < maxPages; page++) {
    const resp = await rpc.get_table_rows({
      json: true,
      code: 'atomicassets',
      scope: owner,
      table: 'assets',
      limit: pageLimit,
      lower_bound: String(lower_bound),
    });

    const rows = resp?.rows || [];
    all.push(...rows);

    // stop when chain says no more pages
    if (!resp?.more || rows.length === 0) break;

    // next page starts after last asset_id
    const last = rows[rows.length - 1];
    const lastId = Number(last.asset_id);
    if (!Number.isFinite(lastId)) break;

    lower_bound = lastId + 1;
  }

  return all;
}

// GET /nfts/burnable/:account
export const getBurnableNFTs = async (req, res) => {
  const { account } = req.params;

  try {
    // 1) Pull approved template list + proposals from your contract
    const [approvedNFTsRows, proposalsRows] = await Promise.all([
      rpc.get_table_rows({
        json: true,
        code: 'cleanupcentr',
        scope: 'cleanupcentr',
        table: 'approvednfts',
        limit: 2000, // a little safer than 1000
      }),
      rpc.get_table_rows({
        json: true,
        code: 'cleanupcentr',
        scope: 'cleanupcentr',
        table: 'proposals',
        limit: 2000,
      }),
    ]);

    const approvedNFTs = approvedNFTsRows?.rows || [];
    const proposals = proposalsRows?.rows || [];

    // NOTE: If your on-chain status is numeric, adjust this filter accordingly.
    const approvedProposals = proposals.filter((p) => p.status === 'approved');

    // 2) Build lookups
    // 2a) collection -> Set(template_id)
    const approvedByCollection = approvedNFTs.reduce((acc, row) => {
      const col = String(row.collection || '').toLowerCase().trim();
      const tid = String(row.template_id || '').trim();
      if (!col || !tid) return acc;
      if (!acc[col]) acc[col] = new Set();
      acc[col].add(tid);
      return acc;
    }, {});

    // 2b) proposal lookup by "collection:template_id"
    const proposalByKey = new Map();
    for (const p of approvedProposals) {
      const col = String(p.collection || '').toLowerCase().trim();
      const tid = String(p.template_id || '').trim();
      if (!col || !tid) continue;
      proposalByKey.set(`${col}:${tid}`, p);
    }

    // 3) Fetch user-owned NFTs from CHAIN (atomicassets::assets scoped by owner) with pagination
    const owned = await fetchAtomicAssetsPaged(account, {
      pageLimit: 1000,
      maxPages: 120, // increase if you expect mega wallets
    });

    // 4) Filter owned assets by approved templates + attach fee/reward + template display meta
    const results = [];

    for (const asset of owned) {
      const collectionLower = String(asset.collection_name || '').toLowerCase().trim();
      const templateIdStr = String(asset.template_id || '0').trim();

      if (!collectionLower || templateIdStr === '0') continue;

      const okTemplates = approvedByCollection[collectionLower];
      if (!okTemplates || !okTemplates.has(templateIdStr)) continue;

      const match = proposalByKey.get(`${collectionLower}:${templateIdStr}`) || null;

      // ✅ Add name + img (CID) for the frontend cards
      const meta = await getTemplateMetaCached(asset.collection_name, templateIdStr);

      results.push({
        asset_id: String(asset.asset_id),
        collection_name: asset.collection_name,
        schema_name: asset.schema_name,
        template_id: Number(asset.template_id),

        template_name: meta?.name || null,
        img: meta?.img || null, // ✅ CID only

        trash_fee: match?.trash_fee ?? null,
        cinder_reward: match?.cinder_reward ?? null,
      });
    }

    // Optional: basic debug info (remove if you want)
    return res.json({
      success: true,
      data: results,
      // debug: { ownedCount: owned.length, approvedCount: approvedNFTs.length }
    });
  } catch (error) {
    console.error(`[ERROR] getBurnableNFTs (on-chain):`, error.message || error);
    return res.status(500).json({ success: false, message: error.message || 'FAILED' });
  }
};
