// ~/backend/controllers/bagController.js
// Bag Controller:
// - Ownership: CHAIN ONLY (atomicassets::assets table, scoped by owner)
// - Whitelist/types: CHAIN ONLY (rhythmfarmer::nfts + rhythmfarmer::toolmeta)
// - Display meta (name/img CID): Atomic mirror REST (ExplorerApi) with caching (display-only)

import dotenv from 'dotenv';
import path from 'path';
import fetch from 'node-fetch';
import { JsonRpc } from 'eosjs';
import { ExplorerApi } from 'atomicassets';

dotenv.config({ path: path.resolve('../.env') });

// -----------------------------------------------------------------------------
// EOS RPC
// -----------------------------------------------------------------------------
const WAX_API = process.env.WAX_MAINNET_API || 'https://wax.greymass.com';
const rpc = new JsonRpc(WAX_API, { fetch });

// RhythmFarmer contract (where nfts + toolmeta live)
const RHYTHM_CONTRACT = process.env.RHYTHMFARMER_ACCOUNT || 'rhythmfarmer';

// Atomic template metadata mirrors (display-only)
const ATOMIC_ENDPOINTS = [
  'https://atomic-api.wax.cryptolions.io',
  'https://atomic.3dkrender.com',
  process.env.ATOMICASSETS_MAINNET_API_ENDPOINT || 'https://wax.api.atomicassets.io',
];

// -----------------------------------------------------------------------------
// Atomic helper w/ fallback mirrors (display-only)
// -----------------------------------------------------------------------------
async function callAtomic(fn) {
  let lastErr;
  for (const baseUrl of ATOMIC_ENDPOINTS) {
    try {
      const api = new ExplorerApi(baseUrl, 'atomicassets', { fetch });
      // avoid config calls inside lib
      api.getConfig = async () => ({ collections: {}, schemas: {}, templates: {} });
      return await fn(api);
    } catch (error) {
      console.warn(`AtomicAssets @ ${baseUrl} failed: ${error.message}`);
      lastErr = error;
    }
  }
  throw lastErr;
}

// -----------------------------------------------------------------------------
// Template meta cache (display-only)
// -----------------------------------------------------------------------------
const templateCache = new Map();

/**
 * Normalize template img to CID only (no gateway URL)
 */
function normalizeImgToCid(img) {
  if (!img) return null;
  const s = String(img).trim();

  // ipfs://CID
  if (s.startsWith('ipfs://')) {
    return s.replace('ipfs://', '').replace(/^ipfs\//, '');
  }

  // URL containing /ipfs/CID
  const match = s.match(/\/ipfs\/([a-zA-Z0-9]+)/);
  if (match) return match[1];

  // already CID-ish
  if (s.startsWith('Qm') || s.length > 40) return s;

  return null;
}

/**
 * Get template meta (name + img CID), cached
 */
async function getTemplateMetaCached(collection, templateId) {
  const key = `${String(collection)}:${String(templateId)}`;
  if (templateCache.has(key)) return templateCache.get(key);

  try {
    const tpl = await callAtomic((api) => api.getTemplate(collection, templateId));
    const immutable = tpl?.immutable_data || {};
    const meta = {
      name: immutable?.name || null,
      img: normalizeImgToCid(immutable?.img) || null,
    };
    templateCache.set(key, meta);
    return meta;
  } catch (err) {
    console.warn(`Template meta fetch failed (${collection}:${templateId}): ${err.message}`);
    const meta = { name: null, img: null };
    templateCache.set(key, meta);
    return meta;
  }
}

// -----------------------------------------------------------------------------
// Helper: load nfts config table (whitelisted templates for farming)
// -----------------------------------------------------------------------------
async function loadNftConfig() {
  const resp = await rpc.get_table_rows({
    json: true,
    code: RHYTHM_CONTRACT,
    scope: RHYTHM_CONTRACT,
    table: 'nfts',
    limit: 1000,
  });

  const rows = resp?.rows || [];
  const map = new Map();

  rows.forEach((row) => {
    const key = String(row.template_id);
    map.set(key, {
      template_id: row.template_id,
      collection: row.collection,
      schema: row.schema,
      nft_type: row.nft_type,
      created_at: row.created_at,
    });
  });

  return map;
}

// -----------------------------------------------------------------------------
// Helper: load toolmeta table
// -----------------------------------------------------------------------------
async function loadToolMeta() {
  const resp = await rpc.get_table_rows({
    json: true,
    code: RHYTHM_CONTRACT,
    scope: RHYTHM_CONTRACT,
    table: 'toolmeta',
    limit: 1000,
  });

  const rows = resp?.rows || [];
  const map = new Map();

  rows.forEach((row) => {
    const key = String(row.template_id);
    map.set(key, {
      template_id: row.template_id,
      tool_type: row.tool_type,
      rarity: row.rarity,
      cooldown_secs: row.cooldown_secs,
      resin_capacity: row.resin_capacity,
      durability: row.durability,
      energy_cost: row.energy_cost,
      reusable: !!row.reusable,
    });
  });

  return map;
}

// -----------------------------------------------------------------------------
// Helper: page through atomicassets::assets for a given owner (CHAIN TABLE)
// -----------------------------------------------------------------------------
async function fetchAtomicAssetsPaged(owner, { pageLimit = 1000, maxPages = 200 } = {}) {
  const all = [];
  let lower_bound = 0;

  for (let page = 0; page < maxPages; page++) {
    const resp = await rpc.get_table_rows({
      json: true,
      code: 'atomicassets',
      scope: owner,
      table: 'assets',
      limit: pageLimit,
      lower_bound: String(lower_bound),
    });

    const rows = resp?.rows || [];
    all.push(...rows);

    if (!resp?.more || rows.length === 0) break;

    const last = rows[rows.length - 1];
    const lastId = Number(last.asset_id);
    if (!Number.isFinite(lastId)) break;

    lower_bound = lastId + 1;
  }

  return all;
}

// -----------------------------------------------------------------------------
// Controller: GET /bag/:account
// - Ownership: chain
// - Whitelist: chain
// - Display: Atomic mirrors (template name/img CID only)
// -----------------------------------------------------------------------------
export async function getBag(req, res) {
  const { account } = req.params;

  try {
    if (!account) {
      return res.status(400).json({ message: 'Missing account parameter' });
    }

    // 1) Load whitelist + tool meta
    const [nftConfig, toolMeta] = await Promise.all([loadNftConfig(), loadToolMeta()]);

    if (!nftConfig || nftConfig.size === 0) {
      return res.json({ account, count: 0, assets: [] });
    }

    // 2) Pull ALL wallet assets from chain (atomicassets::assets scoped by owner)
    const owned = await fetchAtomicAssetsPaged(account, {
      pageLimit: 1000,
      maxPages: 200,
    });

    // 3) Filter to whitelisted templates + enrich display meta
    const out = [];
    for (const a of owned || []) {
      const tplIdStr = String(a.template_id || '0');
      if (tplIdStr === '0') continue;

      const cfg = nftConfig.get(tplIdStr);
      if (!cfg) continue;

      const collection = String(a.collection_name || cfg.collection || '');
      const schema = String(a.schema_name || cfg.schema || '');

      const toolCfg = toolMeta.get(tplIdStr);

      // display-only meta (cached)
      const meta = collection
        ? await getTemplateMetaCached(collection, tplIdStr)
        : { name: null, img: null };

      out.push({
        asset_id: String(a.asset_id),
        template_id: Number(tplIdStr),
        collection,
        schema,

        nft_type: cfg.nft_type,

        // ✅ display fields
        name: meta?.name || null,
        image: meta?.img || null, // ✅ CID ONLY

        tool: toolCfg
          ? {
              tool_type: toolCfg.tool_type,
              rarity: toolCfg.rarity,
              cooldown_secs: toolCfg.cooldown_secs,
              resin_capacity: toolCfg.resin_capacity,
              durability: toolCfg.durability,
              energy_cost: toolCfg.energy_cost,
              reusable: toolCfg.reusable,
            }
          : null,
      });
    }

    return res.json({
      account,
      count: out.length,
      assets: out,
    });
  } catch (err) {
    console.error('getBag error:', err);
    return res.status(500).json({
      message: 'Failed to load bag inventory',
      error: err.message,
    });
  }
}
