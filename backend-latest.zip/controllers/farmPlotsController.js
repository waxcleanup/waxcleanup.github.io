// controllers/farmPlotsController.js
import dotenv from 'dotenv';
import { JsonRpc } from 'eosjs';
import fetch from 'node-fetch';

dotenv.config();

const RPC_ENDPOINT =
  process.env.RPC_ENDPOINT ||
  process.env.WAX_MAINNET_API ||
  process.env.WAX_TESTNET_API ||
  'https://wax.greymass.com';

const CONTRACT_ACCOUNT = process.env.RHYTHMFARMER_ACCOUNT || 'rhythmfarmer';
const COLLECTION = process.env.COLLECTION || 'cleanupcentr';
const ATOMIC_API =
  process.env.ATOMICASSETS_MAINNET_API_ENDPOINT ||
  'https://wax.api.atomicassets.io';

const rpc = new JsonRpc(RPC_ENDPOINT, { fetch });

const STATE_LABELS = ['EMPTY', 'GROWING', 'READY'];

/* -----------------------------
   Helpers
----------------------------- */

// Return CID only (no gateway, no ipfs.io)
function extractCid(img) {
  if (!img) return null;
  const s = String(img).trim();

  // ipfs://CID or ipfs://ipfs/CID
  if (s.startsWith('ipfs://')) {
    return s.replace('ipfs://', '').replace(/^ipfs\//, '');
  }

  // .../ipfs/CID
  const m = s.match(/\/ipfs\/([^/?#]+)/);
  if (m?.[1]) return m[1];

  // already CID-ish
  if (/^[a-zA-Z0-9]{40,}$/.test(s)) return s;

  return null;
}

/* -----------------------------
   AtomicAssets template -> { name, image(CID only) }
----------------------------- */
const fetchTemplateMeta = async (templateId) => {
  try {
    const res = await fetch(
      `${ATOMIC_API}/atomicassets/v1/templates/${COLLECTION}/${templateId}`
    );
    const json = await res.json();
    if (!json.success || !json.data) return null;

    const imm = json.data.immutable_data || {};
    const name = imm.name || `Template #${templateId}`;
    const image = extractCid(imm.img || imm.image);

    return { name, image };
  } catch (e) {
    console.warn(`Template fetch failed for ${templateId}:`, e.message);
    return null;
  }
};

// GET /api/farms/:farmId/plots
export const getFarmPlots = async (req, res) => {
  const { farmId } = req.params;
  if (!farmId) {
    return res.status(400).json({ message: 'Missing farmId' });
  }

  const farmAssetId = Number(farmId);

  try {
    // 1) plots (filter by farm_id)
    const plotsRes = await rpc.get_table_rows({
      json: true,
      code: CONTRACT_ACCOUNT,
      scope: CONTRACT_ACCOUNT,
      table: 'plots',
      limit: 1000,
    });

    const allPlots = plotsRes.rows || [];
    const farmPlots = allPlots.filter((p) => Number(p.farm_id) === farmAssetId);

    if (farmPlots.length === 0) {
      return res.json({ farm_id: farmId, plots: [] });
    }

    // 2) plotmeta (capacity)
    const plotmetaRes = await rpc.get_table_rows({
      json: true,
      code: CONTRACT_ACCOUNT,
      scope: CONTRACT_ACCOUNT,
      table: 'plotmeta',
      limit: 1000,
    });

    const capacityByTpl = new Map(
      (plotmetaRes.rows || []).map((m) => [
        Number(m.template_id),
        Number(m.capacity || 1),
      ])
    );

    // 3) seedmeta (timing + display text) ✅ CHAIN DATA
    // NOTE: In your seedmeta:
    // - growth_duration = seconds_per_tick (dynamic, 60 now, could be 120 later)
    // - water_ticks = ticks between watering checks (dynamic)
    const seedmetaRes = await rpc.get_table_rows({
      json: true,
      code: CONTRACT_ACCOUNT,
      scope: CONTRACT_ACCOUNT,
      table: 'seedmeta',
      limit: 1000,
    });

    const seedMetaById = new Map(
      (seedmetaRes.rows || []).map((s) => [
        Number(s.template_id),
        {
          seed_name: s.seed_name || null,
          description: s.description || null,
          seconds_per_tick: Number(s.growth_duration || 0),
          water_ticks: Number(s.water_ticks || 0),
        },
      ])
    );

    // 4) Fetch AA metadata for each unique plot_tpl_id
    const tplIds = Array.from(
      new Set(farmPlots.map((p) => Number(p.plot_tpl_id)))
    );

    const templateMetaMap = new Map();
    for (const tplId of tplIds) {
      const meta = await fetchTemplateMeta(tplId);
      if (meta) templateMetaMap.set(tplId, meta);
    }

    // 5) Build response: plots + slots (NO unix / derived timestamps)
    const plotsPayload = [];

    for (const plot of farmPlots) {
      const plotAssetId = String(plot.plot_asset_id);
      const tplIdNum = Number(plot.plot_tpl_id);
      const capacity = capacityByTpl.get(tplIdNum) || 1;
      const aaMeta = templateMetaMap.get(tplIdNum) || {};

      // slots table is scoped by plot_asset_id
      const slotsRes = await rpc.get_table_rows({
        json: true,
        code: CONTRACT_ACCOUNT,
        scope: plot.plot_asset_id,
        table: 'plotslots',
        limit: capacity,
      });

      const slotRows = slotsRes.rows || [];

      const slots = Array.from({ length: capacity }, (_, index) => {
        const sr = slotRows.find((row) => Number(row.slot_index) === index);

        if (!sr) {
          return {
            index,
            state: 'EMPTY',
            raw_state: 0,

            seed_tpl_id: null,
            seed_name: null,
            seed_description: null,

            tick: 0,
            tick_goal: 0,

            // chain timestamps (string)
            planted_at: null,
            last_action: null,

            // timing config from chain (dynamic)
            seconds_per_tick: null,
            water_ticks: null,
          };
        }

        const label = STATE_LABELS[Number(sr.state)] || `STATE_${sr.state}`;

        const seedTplId =
          sr.seed_tpl_id != null ? Number(sr.seed_tpl_id) : null;

        const tick = Number(sr.tick || 0);
        const tickGoal = Number(sr.tick_goal || 0);

        const plantedIso = sr.planted_at || null;
        const lastActionIso = sr.last_action || null;

        const seedMeta = seedTplId != null ? seedMetaById.get(seedTplId) : null;

        return {
          index,
          state: label,
          raw_state: Number(sr.state),

          seed_tpl_id: seedTplId,
          seed_name: seedMeta?.seed_name || null,
          seed_description: seedMeta?.description || null,

          tick,
          tick_goal: tickGoal,

          // chain truth anchors (frontend compares these with head_block_time)
          planted_at: plantedIso,
          last_action: lastActionIso,

          // dynamic timing config (frontend uses these to compute cooldown)
          seconds_per_tick:
            seedMeta && Number.isFinite(seedMeta.seconds_per_tick)
              ? seedMeta.seconds_per_tick
              : null,
          water_ticks:
            seedMeta && Number.isFinite(seedMeta.water_ticks)
              ? seedMeta.water_ticks
              : null,
        };
      });

      plotsPayload.push({
        plot_asset_id: plotAssetId,
        farm_id: String(plot.farm_id),

        // ✅ plot owner from chain
        owner: plot.owner || null,

        template_id: tplIdNum,
        capacity,
        name: aaMeta.name || `Plot #${plotAssetId.slice(-4)}`,

        // ✅ CID ONLY
        image: aaMeta.image || null,

        // plot-level anchors (string timestamps)
        created_at: plot.created_at || null,
        last_action: plot.last_action || null,

        slots,
      });
    }

    return res.json({
      farm_id: farmId,
      plots: plotsPayload,
    });
  } catch (error) {
    console.error('[getFarmPlots] Error:', error);
    return res.status(500).json({
      message: 'Failed to load farm plots',
      error: error.message || String(error),
    });
  }
};
