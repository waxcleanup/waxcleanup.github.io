// controllers/playerStatusController.js
import fetch from 'node-fetch';
import { JsonRpc } from 'eosjs';

const rpcEndpoint = process.env.RPC_ENDPOINT || 'https://wax.greymass.com';
const rpc = new JsonRpc(rpcEndpoint, { fetch });

const RHYTHM_CONTRACT =
  process.env.RHYTHMFARMER_ACCOUNT || 'rhythmfarmer';

// Simple in-memory cache so we don't hit the chain repeatedly
const tokenMetaCache = new Map();

/**
 * Load token metadata for a given token_id from the `tokens` table.
 * Falls back to CINDER / 6 decimals if not found.
 */
async function getTokenMeta(tokenId) {
  if (tokenMetaCache.has(tokenId)) {
    return tokenMetaCache.get(tokenId);
  }

  const resp = await rpc.get_table_rows({
    code: RHYTHM_CONTRACT,
    table: 'tokens',
    scope: RHYTHM_CONTRACT,
    lower_bound: tokenId,
    upper_bound: tokenId,
    index_position: 1,
    key_type: 'i64',
    limit: 1,
    json: true,
  });

  const row = resp.rows?.[0];
  if (!row) {
    const fallback = { token_symbol: '6,CINDER', decimals: 6 };
    tokenMetaCache.set(tokenId, fallback);
    return fallback;
  }

  tokenMetaCache.set(tokenId, row);
  return row;
}

export async function getPlayerStatus(req, res) {
  const { account } = req.params;

  if (!account) {
    return res.status(400).json({ error: 'Missing account parameter' });
  }

  try {
    const [seedResp, compostResp, rewardsResp] = await Promise.all([
      // Seed inventory (seedinv)
      rpc.get_table_rows({
        code: RHYTHM_CONTRACT,
        table: 'seedinv',
        scope: RHYTHM_CONTRACT,
        index_position: 2, // byowner secondary index
        key_type: 'name',
        lower_bound: account,
        upper_bound: account,
        limit: 100,
        json: true,
      }),

      // User compost (ucomposts)
      rpc.get_table_rows({
        code: RHYTHM_CONTRACT,
        table: 'ucomposts',
        scope: RHYTHM_CONTRACT,
        lower_bound: account,
        upper_bound: account,
        index_position: 1,
        key_type: 'name',
        limit: 1,
        json: true,
      }),

      // User rewards (urewards)
      rpc.get_table_rows({
        code: RHYTHM_CONTRACT,
        table: 'urewards',
        scope: account,
        limit: 100,
        json: true,
      }),
    ]);

    // ---------------- Seeds ----------------
    const seedRows = seedResp?.rows || [];
    const seedsByTemplate = {};
    let totalSeeds = 0;

    for (const row of seedRows) {
      const tpl = row.seed_tpl_id;
      const qty = Number(row.qty || 0);
      totalSeeds += qty;
      seedsByTemplate[tpl] = (seedsByTemplate[tpl] || 0) + qty;
    }

    // ---------------- Compost ----------------
    const compostRow = compostResp?.rows?.[0];
    const compostBalance = compostRow ? Number(compostRow.balance || 0) : 0;

    // ---------------- Rewards ----------------
    const rewardRows = rewardsResp?.rows || [];
    const rewardTokens = [];

    for (const row of rewardRows) {
      const tokenId = row.token_id;
      const rawAmount = Number(row.amount || 0);

      if (rawAmount <= 0) continue; // ignore empty rewards

      // Load symbol & decimals
      const meta = await getTokenMeta(tokenId);

      let symbol = 'UNKNOWN';
      let decimals = 0;

      if (meta) {
        // Handle EOSIO-style "8,TOMATOE" strings
        if (
          typeof meta.token_symbol === 'string' &&
          meta.token_symbol.includes(',')
        ) {
          const [decStr, symStr] = meta.token_symbol.split(',');
          decimals = Number(decStr);
          symbol = symStr;
        }

        // explicit decimals field overrides
        if (!Number.isNaN(Number(meta.decimals))) {
          decimals = Number(meta.decimals);
        }
      }

      const humanAmount =
        decimals > 0 ? rawAmount / Math.pow(10, decimals) : rawAmount;

      rewardTokens.push({
        token_id: tokenId,
        symbol,
        amount: humanAmount.toFixed(decimals),
        raw: rawAmount,
      });
    }

    const pendingCount = rewardTokens.length;

    // ---------------- Response ----------------
    return res.json({
      account,

      // 🔹 Seeds: totals + per-template + raw seedinv rows (batches)
      seeds: {
        total: totalSeeds,
        byTemplate: seedsByTemplate,
        batches: seedRows, // <--- used by frontend for seed_tpl_id + seed_asset_id
      },

      // 🔹 Compost
      compost: {
        balance: compostBalance,
      },

      // 🔹 Rewards
      rewards: {
        pendingCount,
        tokens: rewardTokens, // human-readable
        items: rewardRows, // raw urewards rows (optional)
      },
    });
  } catch (err) {
    console.error('Error in getPlayerStatus:', err);
    return res.status(500).json({ error: 'Failed to load player status' });
  }
}
