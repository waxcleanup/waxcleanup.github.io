import { 
  createMaestroWalletAccount, 
  loginMaestroWallet, 
  resetMaestroWalletPassword,
  transferTokens as transferTokensService
} from '../services/maestroWalletService.js';
import { signTransaction as signTransactionService } from '../services/transactionService.js';

// Controller to create a Maestro Wallet account
export const createWallet = async (req, res) => {
  const { accountName, publicKey, password } = req.body;
  try {
    if (!accountName || !publicKey || !password) {
      return res.status(400).json({ status: 'error', message: 'All fields (accountName, publicKey, password) are required.' });
    }
    const wallet = await createMaestroWalletAccount(accountName, publicKey, password);
    return res.status(200).json({ status: 'success', message: 'Wallet created successfully', data: wallet });
  } catch (error) {
    console.error('Error creating wallet:', error);
    return res.status(500).json({ status: 'error', message: error.message });
  }
};

// Controller to login to Maestro Wallet account
export const loginWallet = async (req, res) => {
  const { accountName, password } = req.body;
  try {
    if (!accountName || !password) {
      return res.status(400).json({ status: 'error', message: 'Both accountName and password are required.' });
    }
    const loginResult = await loginMaestroWallet(accountName, password);
    return res.status(200).json({ status: 'success', data: loginResult });
  } catch (error) {
    console.error('Error logging in:', error);
    return res.status(500).json({ status: 'error', message: error.message });
  }
};

// Controller to reset Maestro Wallet password using accountName
export const resetPassword = async (req, res) => {
  const { accountName, newPassword } = req.body;
  try {
    if (!accountName || !newPassword) {
      return res.status(400).json({ status: 'error', message: 'Both accountName and newPassword are required.' });
    }
    const result = await resetMaestroWalletPassword(accountName, newPassword);
    return res.status(200).json({ status: 'success', message: 'Password reset successfully', data: result });
  } catch (error) {
    console.error('Error resetting password:', error);
    return res.status(500).json({ status: 'error', message: error.message });
  }
};

// Controller to sign transactions
export const signTransaction = async (req, res) => {
  const { accountName, transaction } = req.body;
  try {
    if (!accountName || !transaction) {
      return res.status(400).json({ status: 'error', message: 'Both accountName and transaction are required.' });
    }
    const signedTransaction = await signTransactionService(accountName, transaction);
    return res.status(200).json({ status: 'success', message: 'Transaction signed successfully', data: signedTransaction });
  } catch (error) {
    console.error('Error signing transaction:', error);
    return res.status(500).json({ status: 'error', message: error.message });
  }
};

// Controller to transfer tokens
export const transferTokens = async (req, res) => {
  const { fromAccount, toAccount, amount, memo } = req.body;
  try {
    if (!fromAccount || !toAccount || !amount) {
      return res.status(400).json({ status: 'error', message: 'fromAccount, toAccount, and amount are required.' });
    }
    if (isNaN(amount) || amount <= 0) {
      return res.status(400).json({ status: 'error', message: 'Amount must be a valid positive number.' });
    }
    const transferResult = await transferTokensService(fromAccount, toAccount, amount, memo);
    return res.status(200).json({ status: 'success', message: 'Tokens transferred successfully', data: transferResult });
  } catch (error) {
    console.error('Error transferring tokens:', error);
    return res.status(500).json({ status: 'error', message: error.message });
  }
};

