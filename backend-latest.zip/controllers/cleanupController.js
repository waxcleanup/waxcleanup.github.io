// controllers/cleanupController.js
import {
  getTableRows,
  getApprovedCollections,
  getSchemaBurns,
} from "../services/blockchainService.js";

/**
 * GET /cleanup/approved-collections
 * Returns approved template-burn rows + merged tplcaps info (cap_total/cap_remaining/enabled/etc)
 */
export const fetchApprovedCollections = async (req, res) => {
  try {
    const result = await getApprovedCollections();
    return res.status(200).json(result);
  } catch (error) {
    console.error("Error fetching approved collections:", error);
    return res.status(500).json({ error: "Failed to fetch approved collections" });
  }
};

/**
 * GET /cleanup/schema-burns
 * Returns schema-burn rules from `schemaburns`
 * + merged `schemcaps` info when present (cap_total/cap_remaining/enabled/etc)
 */
export const fetchSchemaBurns = async (req, res) => {
  try {
    const result = await getSchemaBurns();
    return res.status(200).json(result);
  } catch (error) {
    console.error("Error fetching schema burns:", error);
    return res.status(500).json({ error: "Failed to fetch schema burns" });
  }
};

/**
 * GET /cleanup/proposals?page=1&limit=10
 * Returns proposals with pagination metadata (simple list)
 */
export const fetchProposals = async (req, res) => {
  const page = Number(req.query.page || 1);
  const limit = Number(req.query.limit || 10);

  try {
    const offset = (page - 1) * limit;

    const proposals = await getTableRows(
      "cleanupcentr",
      "cleanupcentr",
      "proposals",
      Number(limit),
      Number(offset)
    );

    const totalProposals = await getTableRows(
      "cleanupcentr",
      "cleanupcentr",
      "proposals",
      1000,
      0
    );

    return res.status(200).json({
      proposals,
      pagination: {
        totalItems: totalProposals.length,
        currentPage: page,
        totalPages: Math.ceil(totalProposals.length / limit),
      },
    });
  } catch (error) {
    console.error("Error fetching proposals:", error);
    return res.status(500).json({ error: "Failed to fetch proposals" });
  }
};

/**
 * GET /cleanup/proposals/open?account=maestrobeatz
 * Returns only verified proposals + vote totals + time left
 * Optionally includes "my stake" when account is provided.
 */
export const fetchOpenProposals = async (req, res) => {
  try {
    const account = (req.query.account || "").trim(); // optional

    // 0) Pull config from chain (vote window + proposal fee)
    const govcfgRows = await getTableRows("cleanupcentr", "cleanupcentr", "govcfg", 10, 0);
    const propcfgRows = await getTableRows("cleanupcentr", "cleanupcentr", "propcfg", 10, 0);

    const govcfg = govcfgRows?.[0] || null;
    const propcfg = propcfgRows?.[0] || null;

    const vote_period_sec = govcfg?.vote_period_sec ?? 86400; // fallback 24h
    const proposal_fee = propcfg?.fee ?? null;

    // 1) Fetch proposals
    const proposals = await getTableRows("cleanupcentr", "cleanupcentr", "proposals", 2000, 0);

    // 2) Keep only verified (open) proposals
    const openProposals = (proposals || []).filter((p) => p.status === "verified");

    if (!openProposals.length) {
      return res.status(200).json({
        config: {
          vote_period_sec,
          proposal_fee,
          stake_token_id: govcfg?.stake_token_id ?? null,
          fee_token_id: propcfg?.fee_token_id ?? null,
        },
        proposals: [],
        totalVerified: 0,
      });
    }

    // 3) Fetch vote stakes
    const voteStakes = await getTableRows("cleanupcentr", "cleanupcentr", "votestakes", 5000, 0);

    const assetToNumber = (assetStr) => {
      if (!assetStr) return 0;
      const amt = String(assetStr).split(" ")[0];
      const n = Number(amt);
      return Number.isFinite(n) ? n : 0;
    };

    // WAX timestamps: treat as UTC by appending Z if missing
    const waxTimeToMs = (t) => {
      if (!t) return 0;
      const s = String(t);
      const ms = Date.parse(s.endsWith("Z") ? s : s + "Z");
      return Number.isFinite(ms) ? ms : 0;
    };

    const totalsByProp = new Map(); // prop_id -> { for, against }
    const myByProp = new Map();     // prop_id -> { staked, vote_for }

    for (const v of voteStakes || []) {
      const pid = Number(v.proposal_id);
      if (!Number.isFinite(pid)) continue;

      const amt = assetToNumber(v.staked);
      const cur = totalsByProp.get(pid) || { for: 0, against: 0 };

      if (v.vote_for) cur.for += amt;
      else cur.against += amt;

      totalsByProp.set(pid, cur);

      if (account) {
        const voterName = String(v.voter || "").trim();
        if (voterName === account) {
          myByProp.set(pid, { staked: amt, vote_for: !!v.vote_for });
        }
      }
    }

    const nowMs = Date.now();

    const merged = openProposals.map((p) => {
      const pid = Number(p.prop_id);
      const t = totalsByProp.get(pid) || { for: 0, against: 0 };

      const createdMs = waxTimeToMs(p.created_at);
      const endsMs = createdMs ? createdMs + vote_period_sec * 1000 : 0;

      const mine = myByProp.get(pid);

      return {
        ...p,
        votes_for: t.for,
        votes_against: t.against,

        vote_period_sec,
        ends_at: endsMs ? new Date(endsMs).toISOString() : null,
        seconds_left: endsMs ? Math.max(0, Math.floor((endsMs - nowMs) / 1000)) : null,

        has_my_stake: !!mine,
        my_staked: mine ? mine.staked : 0,
        my_staked_str: mine ? `${Number(mine.staked).toFixed(3)} TRASH` : "0.000 TRASH",
        my_vote_for: mine ? !!mine.vote_for : null,
      };
    });

    return res.status(200).json({
      config: {
        vote_period_sec,
        proposal_fee,
        stake_token_id: govcfg?.stake_token_id ?? null,
        fee_token_id: propcfg?.fee_token_id ?? null,
      },
      proposals: merged,
      totalVerified: merged.length,
    });
  } catch (error) {
    console.error("Error fetching open proposals:", error);
    return res.status(500).json({ error: `Failed to fetch open proposals: ${error.message}` });
  }
};
