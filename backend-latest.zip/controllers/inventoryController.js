// controllers/inventoryController.js
import dotenv from 'dotenv';
import { JsonRpc } from 'eosjs';
import fetch from 'node-fetch';

dotenv.config();

const RPC_ENDPOINT =
  process.env.RPC_ENDPOINT ||
  process.env.WAX_MAINNET_API ||
  process.env.WAX_TESTNET_API ||
  'https://wax.greymass.com';

const CONTRACT_ACCOUNT = process.env.RHYTHMFARMER_ACCOUNT || 'rhythmfarmer';
const COLLECTION = process.env.COLLECTION || 'cleanupcentr';
const ATOMIC_API =
  process.env.ATOMICASSETS_MAINNET_API_ENDPOINT ||
  'https://wax.api.atomicassets.io';

const rpc = new JsonRpc(RPC_ENDPOINT, { fetch });

/**
 * Helper: fetch template metadata from AtomicAssets
 * Returns { name, image } where image is a full IPFS gateway URL.
 */
const fetchTemplateMeta = async (templateId) => {
  try {
    const res = await fetch(
      `${ATOMIC_API}/atomicassets/v1/templates/${COLLECTION}/${templateId}`
    );
    const json = await res.json();
    if (!json.success || !json.data) return null;

    const imm = json.data.immutable_data || {};
    const name = imm.name || `Template #${templateId}`;
    const img = imm.img || imm.image;

    const image =
      img && img.startsWith('http')
        ? img
        : img
        ? `https://ipfs.io/ipfs/${img}`
        : null;

    return { name, image };
  } catch (e) {
    console.warn(`Template fetch failed for ${templateId}:`, e.message);
    return null;
  }
};

/**
 * GET /inventory/:account
 *
 * Returns an MMO-style snapshot of a player's on-chain inventory:
 * - User energy + staked cells from userenergy table
 * - Staked tools from tools table
 * - Equipped tools from equipped table (watering / harvesting)
 * - Tool meta from toolmeta table
 * - AtomicAssets metadata (name + image) for cells + tools
 */
export const getInventory = async (req, res) => {
  const { account } = req.params;

  if (!account) {
    return res.status(400).json({ message: 'Missing account in path' });
  }

  try {
    // ----------------------------------------------------------------
    // 1) USER ENERGY + STAKED USER CELLS (userenergy)
    // ----------------------------------------------------------------
    const userEnergyRes = await rpc.get_table_rows({
      json: true,
      code: CONTRACT_ACCOUNT,
      scope: CONTRACT_ACCOUNT,
      table: 'userenergy',
      limit: 1000,
    });

    const energyRow = (userEnergyRes.rows || []).find(
      (row) => row.user === account
    );

    let cellsPayload = {
      total_staked: 0,
      staked: [],
      energy: 0,
      max: 0,
      cell_count: 0,
    };

    if (energyRow) {
      const bats = energyRow.bats || [];

      cellsPayload = {
        total_staked: bats.length,
        staked: bats.map((bat) => ({
          asset_id: String(bat.asset_id),
          template_id: Number(bat.template_id),
          owner: bat.owner,
        })),
        energy: Number(energyRow.energy),
        max: Number(energyRow.max),
        cell_count: Number(energyRow.count),
      };
    }

    // ----------------------------------------------------------------
    // 2) TOOLS: staked tool NFTs for this account
    // ----------------------------------------------------------------
    const toolsRes = await rpc.get_table_rows({
      json: true,
      code: CONTRACT_ACCOUNT,
      scope: CONTRACT_ACCOUNT,
      table: 'tools',
      limit: 1000,
    });

    const allTools = toolsRes.rows || [];
    const userTools = allTools.filter((t) => t.owner === account);

    // ----------------------------------------------------------------
    // 3) TOOL META (type, rarity, cooldown, etc.)
    // ----------------------------------------------------------------
    const toolMetaRes = await rpc.get_table_rows({
      json: true,
      code: CONTRACT_ACCOUNT,
      scope: CONTRACT_ACCOUNT,
      table: 'toolmeta',
      limit: 1000,
    });

    const metaByTemplate = new Map(
      (toolMetaRes.rows || []).map((m) => [Number(m.template_id), m])
    );

    // We’ll also attach AtomicAssets img/name, so we need to know all template_ids
    const templateIdSet = new Set();

    // from cells
    cellsPayload.staked.forEach((c) =>
      templateIdSet.add(Number(c.template_id))
    );
    // from tools
    userTools.forEach((t) => templateIdSet.add(Number(t.template_id)));

    // Fetch AtomicAssets metadata for each unique template_id
    const templateMetaMap = new Map();
    for (const tplId of templateIdSet) {
      const meta = await fetchTemplateMeta(tplId);
      if (meta) {
        templateMetaMap.set(tplId, meta);
      }
    }

    const hydrateTool = (assetIdValue) => {
      if (!assetIdValue) return null;
      const assetIdStr = String(assetIdValue);

      const t = userTools.find((tool) => String(tool.asset_id) === assetIdStr);
      if (!t) return null;

      const tplIdNum = Number(t.template_id);
      const meta = metaByTemplate.get(tplIdNum);
      const aaMeta = templateMetaMap.get(tplIdNum) || {};

      return {
        asset_id: String(t.asset_id),
        owner: t.owner,
        template_id: tplIdNum,
        staked_at: t.staked_at,
        type: meta ? meta.tool_type : null,
        rarity: meta ? meta.rarity : null,
        cooldown_secs: meta ? Number(meta.cooldown_secs || 0) : null,
        resin_capacity: meta ? Number(meta.resin_capacity || 0) : null,
        durability: meta ? Number(meta.durability || 0) : null,
        energy_cost: meta ? Number(meta.energy_cost || 0) : null,
        reusable: meta ? Boolean(meta.reusable) : null,
        // AtomicAssets visual info
        name: aaMeta.name || null,
        image: aaMeta.image || null,
      };
    };

    // ----------------------------------------------------------------
    // 4) EQUIPPED: watering / harvesting slots
    // ----------------------------------------------------------------
    const equippedRes = await rpc.get_table_rows({
      json: true,
      code: CONTRACT_ACCOUNT,
      scope: CONTRACT_ACCOUNT,
      table: 'equipped',
      limit: 1000,
    });

    const eqRow = (equippedRes.rows || []).find((r) => r.owner === account);

    const equipped = {
      watering: eqRow ? hydrateTool(eqRow.watering_tool) : null,
      harvesting: eqRow ? hydrateTool(eqRow.harvesting_tool) : null,
    };

    // Build a set of equipped asset_ids so we can separate inventory
    const equippedIds = new Set(
      [equipped.watering?.asset_id, equipped.harvesting?.asset_id].filter(
        Boolean
      )
    );

    const inventoryTools = userTools
      .filter((t) => !equippedIds.has(String(t.asset_id)))
      .map((t) => hydrateTool(t.asset_id))
      .filter(Boolean);

    // ----------------------------------------------------------------
    // 5) Enrich cells with AtomicAssets name/image
    // ----------------------------------------------------------------
    const cellsEnriched = {
      ...cellsPayload,
      staked: cellsPayload.staked.map((c) => {
        const tplIdNum = Number(c.template_id);
        const aaMeta = templateMetaMap.get(tplIdNum) || {};
        return {
          ...c,
          name: aaMeta.name || null,
          image: aaMeta.image || null,
        };
      }),
    };

    // ----------------------------------------------------------------
    // 6) Assemble response payload
    // ----------------------------------------------------------------
    const response = {
      account,
      cells: cellsEnriched,
      tools: {
        equipped,
        inventory: inventoryTools,
      },
    };

    return res.json(response);
  } catch (error) {
    console.error('[getInventory] Error:', error);
    return res.status(500).json({
      message: 'Failed to load inventory',
      error: error.message || String(error),
    });
  }
};

