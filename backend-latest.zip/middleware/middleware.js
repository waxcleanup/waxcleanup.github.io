import fetch from 'node-fetch';

export const checkTomatoFarmPass = async (req, res, next) => {
  const { accountName } = req.body;
  const url = `${process.env.ATOMICASSETS_API_ENDPOINT}/atomicassets/v1/assets?owner=${accountName}&collection_name=${process.env.COLLECTION_NAME}&template_id=${process.env.TOMATO_FARM_PASS_TEMPLATE_ID}`;
  const response = await fetch(url);
  const data = await response.json();
  const hasTomatoFarmPass = data.data && data.data.length > 0;

  if (hasTomatoFarmPass) {
    next();
  } else {
    res.status(403).json({ error: 'Tomato Farm Pass required' });
  }
};
