// routes/nfts.js
import express from 'express';
import {
  getNFTs,
  getNFTStatus,
  getFarmByWallet,
  getBurnableNFTs,
} from '../controllers/nftsController.js';

const router = express.Router();

// ✅ More specific routes must be listed first
router.get('/burnable/:account', getBurnableNFTs);  // MUST be before /:account
router.get('/status/:nftId', getNFTStatus);
router.get('/farm/:wallet', getFarmByWallet);

// 🧠 Catch-all route (must come last)
router.get('/:account', getNFTs);

export default router;
