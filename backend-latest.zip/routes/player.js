// routes/player.js
import express from 'express';
import { getPlayerStatus } from '../controllers/playerStatusController.js';

const router = express.Router();

// GET /api/player/:account/status
router.get('/:account/status', getPlayerStatus);

export default router;
