// routes/incinerators.js
import express from 'express';
import {
  fetchStakedIncinerators,
  fetchUnstakedIncinerators,
  unstakeIncinerator
} from '../services/incineratorService.js';

const router = express.Router();

/**
 * GET /incinerators/staked/:accountName
 * Returns all staked incinerators with full contract stats and metadata.
 */
router.get('/staked/:accountName', async (req, res) => {
  const accountName = req.params.accountName;

  try {
    const incs = await fetchStakedIncinerators(accountName);
    res.json({ success: true, data: incs });
  } catch (err) {
    console.error(`[ERROR] Fetching staked incinerators for ${accountName}:`, err.message);
    res.status(500).json({ success: false, message: 'Failed to fetch staked incinerators.' });
  }
});

/**
 * GET /incinerators/unstaked/:accountName
 * Returns all unstaked incinerator NFTs from AtomicAssets.
 */
router.get('/unstaked/:accountName', async (req, res) => {
  const accountName = req.params.accountName;

  try {
    const incs = await fetchUnstakedIncinerators(accountName);
    res.json({ success: true, data: incs });
  } catch (err) {
    console.error(`[ERROR] Fetching unstaked incinerators for ${accountName}:`, err.message);
    res.status(500).json({ success: false, message: 'Failed to fetch unstaked incinerators.' });
  }
});

/**
 * POST /incinerators/unstake
 * Unstakes a staked incinerator by pushing returnicin to the contract.
 */
router.post('/unstake', async (req, res) => {
  const { owner, incinerator_id } = req.body;

  if (!owner || !incinerator_id) {
    return res.status(400).json({
      success: false,
      message: 'Missing owner or incinerator_id in request body'
    });
  }

  try {
    const result = await unstakeIncinerator(owner, incinerator_id);
    res.json({ success: true, tx: result.transaction_id });
  } catch (err) {
    console.error(`[ERROR] Unstaking incinerator ${incinerator_id}:`, err.message);
    res.status(500).json({ success: false, message: 'Failed to unstake incinerator.' });
  }
});

export default router;
