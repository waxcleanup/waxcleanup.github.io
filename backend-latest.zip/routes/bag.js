// routes/bag.js
import express from 'express';
import { getBag } from '../controllers/bagController.js';

const router = express.Router();

// GET /bag/:account
router.get('/:account', getBag);

export default router;
