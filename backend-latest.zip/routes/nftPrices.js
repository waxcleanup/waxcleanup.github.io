// routes/nftPrices.js
import express from 'express';
import axios from 'axios';
import NFTPrice from '../models/NFTPrice.js';
import mongoose from 'mongoose';
import cron from 'node-cron';

const router = express.Router();

// AtomicMarket and AtomicAssets API base URL (using CryptoLions mirror)
const WAX_API = 'https://atomic-api.wax.cryptolions.io';

// Fetch up to 5 cheapest market prices from AtomicMarket API
const fetchTop5MarketPrices = async (templateId) => {
  try {
    const response = await axios.get(
      `${WAX_API}/atomicmarket/v1/sales/templates?symbol=WAX&template_id=${templateId}&limit=5&order=asc&sort=price`
    );

    if (response.data?.data?.length > 0) {
      return response.data.data.map(sale => ({
        price: sale.listing_price / 100000000, // Convert from 8-decimal WAX
        seller: sale.seller
      }));
    }
  } catch (error) {
    console.error(`❌ Error fetching top 5 prices for template ${templateId}:`, error.message);
  }
  return [];
};

// Fetch template rarity from AtomicAssets API, handle 404 gracefully
const fetchTemplateRarity = async (templateId) => {
  try {
    const url = `${WAX_API}/atomicassets/v1/templates/alien.worlds/${templateId}`;
    const response = await axios.get(url);

    if (response.data?.data?.immutable_data?.rarity) {
      return response.data.data.immutable_data.rarity;
    }
  } catch (error) {
    if (error.response?.status === 404) {
      console.warn(`⚠️ Template ${templateId} not found, defaulting rarity to 'Unknown'`);
      return 'Unknown';
    }
    console.error(`❌ Error fetching rarity for template ${templateId}:`, error.message);
  }
  return 'Unknown';
};

// Update NFT prices and rarity in MongoDB
const updateNFTPrices = async () => {
  try {
    const templates = await NFTPrice.find({});
    for (const template of templates) {
      const listings = await fetchTop5MarketPrices(template.template_id);
      const rarity = await fetchTemplateRarity(template.template_id);

      // Only update if there are listings or rarity changed
      const hasListings = listings.length > 0;
      const hasRarity = Boolean(rarity);
      const listingsChanged = JSON.stringify(template.listings) !== JSON.stringify(listings);
      const rarityChanged = template.rarity !== rarity;

      if ((hasListings && listingsChanged) || rarityChanged) {
        template.listings = listings;
        template.rarity = rarity;
        template.updatedAt = new Date();
        await template.save();
        console.log(`✅ Updated prices & rarity for template: ${template.template_id} (${rarity})`);
      }
    }
    console.log('✅ NFT Prices and rarities checked and updated if necessary');
  } catch (error) {
    console.error('❌ Error updating NFT prices:', error.message);
  }
};

// Route to get top 5 cheapest listings for an NFT template
router.get('/top5/:template_id', async (req, res) => {
  try {
    const { template_id } = req.params;
    let nftPrice = await NFTPrice.findOne({ template_id });

    if (!nftPrice || !nftPrice.listings?.length) {
      const listings = await fetchTop5MarketPrices(template_id);
      const rarity = await fetchTemplateRarity(template_id);

      if (listings.length > 0 || rarity) {
        nftPrice = await NFTPrice.findOneAndUpdate(
          { template_id },
          { $set: { listings, rarity, updatedAt: new Date() } },
          { new: true, upsert: true }
        );
      }
    }

    res.json(nftPrice || { error: 'No price data available' });
  } catch (error) {
    console.error(`❌ Error fetching top 5 NFT prices:`, error.message);
    res.status(500).json({ error: 'Failed to fetch NFT prices' });
  }
});

// Schedule the price & rarity update every 10 minutes
cron.schedule('*/10 * * * *', async () => {
  console.log('⏳ Running scheduled NFT price & rarity update task...');
  await updateNFTPrices();
});

export default router;
