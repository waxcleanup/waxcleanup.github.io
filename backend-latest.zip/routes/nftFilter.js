// routes/nftFilter.js
import express from 'express';
import axios from 'axios';

const router = express.Router();

// AtomicAssets API base URL (using CryptoLions mirror)
const WAX_API = 'https://atomic-api.wax.cryptolions.io';

// Route to fetch NFTs for a specific account and templateId
router.get('/fetch-nfts', async (req, res) => {
  // Log the incoming query parameters for debugging
  console.log('Received Query Params:', req.query);

  const { accountName, templateId } = req.query;
  if (!accountName || !templateId) {
    return res.status(400).json({
      message: 'Error fetching NFTs',
      error: 'Missing accountName or templateId'
    });
  }

  const encodedAccountName = encodeURIComponent(accountName);
  const url = `${WAX_API}/atomicassets/v1/assets?collection_name=farmersworld&template_id=${templateId}&owner=${encodedAccountName}`;
  console.log('Request URL:', url);

  try {
    // Make the request to the AtomicAssets API
    const response = await axios.get(url);

    // Check if the response contains data and return it
    if (response.data && response.data.data) {
      console.log('NFTs Data:', response.data.data);
      return res.json({ nfts: response.data.data });
    } else {
      return res.status(404).json({
        message: 'Error fetching NFTs',
        error: 'No NFTs found for this account and templateId'
      });
    }
  } catch (error) {
    // Log any error during the request
    console.error('Error fetching NFTs:', error.message);
    return res.status(500).json({
      message: 'Error fetching NFTs',
      error: error.message
    });
  }
});

export default router;
