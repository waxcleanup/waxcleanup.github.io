import express from 'express';
import { getUnequippedStakedTools } from '../services/toolsService.js';

const router = express.Router();

/**
 * GET /tools/staked/unequipped/:owner
 * Returns tools that are staked but not equipped
 */
router.get('/staked/unequipped/:owner', async (req, res) => {
  try {
    const owner = req.params.owner.toLowerCase();

    const tools = await getUnequippedStakedTools(owner);

    res.json({
      success: true,
      owner,
      count: tools.length,
      data: tools,
    });
  } catch (err) {
    console.error('❌ unequipped tools route error', err);
    res.status(500).json({
      success: false,
      error: 'Failed to fetch unequipped tools',
    });
  }
});

export default router;
