import express from 'express';
import CryptoJS from 'crypto-js';
import { createMaestroWalletAccount, resetMaestroWalletPassword } from '../services/maestroWalletService.js';
import { searchAccountsByPublicKey } from '../services/blockchainService.js'; 

const router = express.Router();

// Helper function to decrypt AES-encrypted data
const decryptData = (encryptedData) => {
  const encryptionKey = process.env.ENCRYPTION_KEY;
  if (!encryptionKey) {
    throw new Error('Encryption key is not set.');
  }

  try {
    // Decrypt the AES-encrypted data
    const bytes = CryptoJS.AES.decrypt(encryptedData, encryptionKey);
    const decryptedData = bytes.toString(CryptoJS.enc.Utf8);

    if (!decryptedData) {
      throw new Error('Decryption resulted in an empty string or invalid UTF-8 data.');
    }

    console.log('Decrypted data:', decryptedData);  // Log decrypted data for debugging
    return decryptedData;
  } catch (error) {
    console.error('Error during decryption:', error);
    throw new Error('Decryption failed: ' + error.message);
  }
};

// Route to create Maestro Wallet account with imported key
router.post('/create-maestro-wallet', async (req, res) => {
  console.log('Received request body:', JSON.stringify(req.body, null, 2));

  const {
    accountName: providedAccountName,
    publicKey: encryptedPublicKey,
    password: encryptedPassword,
    privateKey: encryptedPrivateKey,
  } = req.body;

  console.log('Extracted values:', {
    providedAccountName: providedAccountName || 'undefined',
    encryptedPublicKey: 'present',
    encryptedPassword: 'present',
    encryptedPrivateKey: 'present',
  });

  try {
    // Ensure all required fields are provided
    if (!encryptedPublicKey || !encryptedPassword || !encryptedPrivateKey) {
      throw new Error('Public key, password, and private key are required.');
    }

    // Decrypt the public key, password, and private key
    const publicKey = decryptData(encryptedPublicKey);
    const password = decryptData(encryptedPassword);
    const privateKey = decryptData(encryptedPrivateKey);

    // Validation after decryption
    if (publicKey.length === 0 || password.length === 0 || privateKey.length === 0) {
      throw new Error('Decrypted data is empty. Please check the encryption process.');
    }

    console.log('Decrypted values:', {
      publicKey: publicKey.substring(0, 10) + '...',  // Log only part of the publicKey for security
      passwordLength: password.length,
      privateKeyLength: privateKey.length,
    });

    // Derive account name from public key if not provided
    let accountName = providedAccountName;
    if (!accountName) {
      console.log('No account name provided, deriving account from public key...');
      const accountNames = await searchAccountsByPublicKey(publicKey);

      if (accountNames.length === 0) {
        throw new Error('No accounts found for this public key.');
      }

      accountName = accountNames[0];
      console.log(`Derived account name: ${accountName}`);
    }

    // Create the Maestro Wallet with the account name, public key, password, and private key
    const result = await createMaestroWalletAccount(accountName, publicKey, password, privateKey);

    console.log('Maestro Wallet created successfully');
    res.status(200).json({ message: 'Maestro Wallet created successfully', result });
  } catch (error) {
    console.error('Error creating Maestro Wallet:', error);
    res.status(400).json({ error: error.message || 'Failed to create Maestro Wallet' });
  }
});

// Route to reset password by verifying the private key
router.post('/reset-password', async (req, res) => {
  const {
    accountName,
    publicKey: encryptedPublicKey,
    newPassword: encryptedNewPassword,
    privateKey: encryptedPrivateKey,
  } = req.body;

  try {
    // Ensure all required fields are provided
    if (!accountName || !encryptedPublicKey || !encryptedNewPassword || !encryptedPrivateKey) {
      throw new Error('Account name, public key, new password, and private key are required.');
    }

    // Decrypt the public key, new password, and private key
    const publicKey = decryptData(encryptedPublicKey);
    const newPassword = decryptData(encryptedNewPassword);
    const privateKey = decryptData(encryptedPrivateKey);

    // Validate decrypted data
    if (!publicKey || !newPassword || !privateKey) {
      throw new Error('Decrypted values are invalid.');
    }

    // Reset the password in the Maestro Wallet
    const result = await resetMaestroWalletPassword(accountName, publicKey, newPassword, privateKey);

    res.status(200).json({ message: 'Password reset successful', result });
  } catch (error) {
    console.error('Error resetting password:', error);
    res.status(400).json({ error: error.message || 'Failed to reset password' });
  }
});

export default router;
