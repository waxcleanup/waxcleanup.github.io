import express from 'express';
import { fetchAllStakes } from '../services/kekStakingService.js';

const router = express.Router();

/**
 * GET /kek-staking/leaderboard
 * Fetch and return leaderboard data
 */
router.get('/leaderboard', async (req, res) => {
  try {
    const allStakes = await fetchAllStakes();

    // Sort by total staked quantity
    const leaderboard = allStakes.sort((a, b) => {
      const stakeA = parseFloat(a.staked_quantity.split(' ')[0]);
      const stakeB = parseFloat(b.staked_quantity.split(' ')[0]);
      return stakeB - stakeA; // Sort in descending order
    });

    // Return the leaderboard (top 100 or paginate)
    res.json(leaderboard.slice(0, 100)); // Top 100 users
  } catch (error) {
    console.error('Error fetching leaderboard data:', error.message);
    res.status(500).json({ error: 'Failed to fetch leaderboard data' });
  }
});

export default router;
