import express from 'express';
import dotenv from 'dotenv';
import { JsonRpc } from 'eosjs';
import fetch from 'node-fetch';
import path from 'path';
import { fileURLToPath } from 'url';

// Set up __dirname for ES modules
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Load environment variables
dotenv.config({ path: path.join(__dirname, '../.env') });

const router = express.Router();

const rpc = new JsonRpc(process.env.WAX_MAINNET_API, { fetch });

// Fetch current weather from your smart contract
router.get('/current', async (req, res) => {
  try {
    const result = await rpc.get_table_rows({
      json: true,
      code: 'rhythmfarmer',     // Replace with your contract name
      scope: 'rhythmfarmer',
      table: 'currentwth',
      limit: 1
    });

    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'No weather data available.' });
    }

    const weather = result.rows[0];

    res.json({
      condition: weather.condition,
      temperature: weather.temperature,
      precip: weather.precip,
      yield_penalty: weather.yield_penalty,
      yield_boost: weather.yield_boost,
      humidity: weather.humidity,
      wind_speed: weather.wind_speed,
      updated_at: weather.updated_at
    });
  } catch (error) {
    console.error('Error fetching weather:', error);
    res.status(500).json({ error: 'Error fetching weather data' });
  }
});

export default router;
