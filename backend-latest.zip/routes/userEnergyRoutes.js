// routes/userEnergyRoutes.js
import express from "express";
import { getUserEnergy } from "../controllers/userEnergyController.js";

const router = express.Router();

// GET /userenergy/:account
router.get("/:account", getUserEnergy);

export default router;
