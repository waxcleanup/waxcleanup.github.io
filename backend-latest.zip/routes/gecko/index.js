import express from 'express';
import axios from 'axios';

const router = express.Router();
const ALCOR_API = 'https://wax.alcor.exchange/api/v2/swap';

router.get('/tokens', async (req, res) => {
  try {
    const { data } = await axios.get(`${ALCOR_API}/tokens`);
    const tokens = data.map(t => ({
      id: t.id.toString(),
      name: t.symbol,
      symbol: t.symbol,
      decimals: t.precision,
      price: t.last_price || null
    }));
    res.json(tokens);
  } catch {
    res.status(500).json({ error: 'Failed to fetch tokens.' });
  }
});

router.get('/pools', async (req, res) => {
  try {
    const { data } = await axios.get(`${ALCOR_API}/pairs`);
    const pools = data.map(p => ({
      id: p.id.toString(),
      name: `${p.token0.symbol}/${p.token1.symbol}`,
      token0: p.token0.symbol,
      token1: p.token1.symbol,
      volume24h: p.volume24 || 0,
      liquidity: Number(p.reserve0) + Number(p.reserve1)
    }));
    res.json(pools);
  } catch {
    res.status(500).json({ error: 'Failed to fetch pools.' });
  }
});

router.get('/trades', async (req, res) => {
  const { pool_id } = req.query;
  if (!pool_id) return res.status(400).json({ error: 'Missing pool_id' });

  try {
    const { data } = await axios.get(`${ALCOR_API}/history?pool_id=${pool_id}`);
    const trades = data.map(t => ({
      timestamp: new Date(t.time * 1000).toISOString(),
      amount0: t.amount_in,
      amount1: t.amount_out,
      price: t.price,
      side: t.type
    }));
    res.json(trades);
  } catch {
    res.status(500).json({ error: 'Failed to fetch trades.' });
  }
});

export default router;
