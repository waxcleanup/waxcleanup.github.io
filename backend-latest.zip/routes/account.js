// routes/account.js
import express from 'express';
import { JsonRpc } from 'eosjs'; // Import eosjs to interact with the blockchain
import fetch from 'node-fetch'; // node-fetch to make HTTP requests

const router = express.Router();
const rpc = new JsonRpc(process.env.WAX_TESTNET_API || 'https://testnet.waxsweden.org', { fetch });

// Function to derive account name(s) from public key
const searchAccountsByPublicKey = async (publicKey) => {
  try {
    // Use EOSIO API to find accounts by public key
    const response = await rpc.history_get_key_accounts(publicKey);
    return response.account_names;
  } catch (error) {
    console.error(`Error fetching account names for public key: ${publicKey}`, error.message || error);
    throw new Error('Failed to fetch account names from blockchain');
  }
};

// Route to get account information from the blockchain using public key
router.get('/public-key/:publicKey', async (req, res) => {
  const { publicKey } = req.params;

  console.log(`Received publicKey: ${publicKey}`);

  try {
    // Get account names from the public key
    const accountNames = await searchAccountsByPublicKey(publicKey);

    if (!accountNames || accountNames.length === 0) {
      throw new Error(`No account found for publicKey: ${publicKey}`);
    }

    const accountName = accountNames[0]; // Get the first account name associated with the public key

    // Fetch account balance and other account details from the blockchain
    const balanceResult = await rpc.get_currency_balance('eosio.token', accountName, 'WAX');
    const balance = balanceResult.length > 0 ? balanceResult[0] : '0 WAX';

    // Fetch detailed account info (CPU, NET, RAM, etc.)
    const accountInfo = await rpc.get_account(accountName);

    const accountData = {
      accountName,
      balance,
      cpu_stake: accountInfo.total_resources?.cpu_weight || '0.0000 WAX',
      net_stake: accountInfo.total_resources?.net_weight || '0.0000 WAX',
      ram_quota: accountInfo.ram_quota || 0,
      ram_usage: accountInfo.ram_usage || 0,
      status: 'Active', // You can modify this based on your logic
    };

    console.log(`Fetched account info for ${accountName}`);
    // Return the fetched account information
    res.json(accountData);
  } catch (error) {
    console.error('Error fetching account data from blockchain:', error.message || error);
    res.status(500).json({ error: `Failed to fetch account information: ${error.message || 'Unknown error'}` });
  }
});

// Route to get account information using account name directly
router.get('/account-name/:accountName', async (req, res) => {
  const { accountName } = req.params;

  console.log(`Received accountName: ${accountName}`);

  try {
    // Fetch account balance and other account details from the blockchain
    const balanceResult = await rpc.get_currency_balance('eosio.token', accountName, 'WAX');
    const balance = balanceResult.length > 0 ? balanceResult[0] : '0 WAX';

    // Fetch detailed account info (CPU, NET, RAM, etc.)
    const accountInfo = await rpc.get_account(accountName);

    const accountData = {
      accountName,
      balance,
      cpu_stake: accountInfo.total_resources?.cpu_weight || '0.0000 WAX',
      net_stake: accountInfo.total_resources?.net_weight || '0.0000 WAX',
      ram_quota: accountInfo.ram_quota || 0,
      ram_usage: accountInfo.ram_usage || 0,
      cpu_limit: {
        used: accountInfo.cpu_limit?.used || 0,
        max: accountInfo.cpu_limit?.max || 1, // Avoid division by zero in frontend
      },
      status: 'Active', // You can modify this based on your logic
    };

    console.log(`Fetched account info for ${accountName}`);
    // Return the fetched account information
    res.json(accountData);
  } catch (error) {
    console.error('Error fetching account data from blockchain:', error.message || error);
    res.status(500).json({ error: `Failed to fetch account information: ${error.message || 'Unknown error'}` });
  }
});

// Default export
export default router;
