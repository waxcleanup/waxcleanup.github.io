import express from 'express';
import { api } from '../services/eosService.js';
import StakedFarm from '../models/StakedFarm.js';
import { handleError } from '../utils/errorHandler.js';

const router = express.Router();

// Stake NFT
router.post('/stakeNFT', async (req, res) => {
  const { user, nft_id, power_level } = req.body;
  try {
    const actions = [{
      account: process.env.REACT_APP_CONTRACT_NAME,
      name: 'stakefarm',
      authorization: [{ actor: user, permission: 'active' }],
      data: { owner: user, nft_id, power_level },
    }];
    const result = await api.transact({ actions }, { blocksBehind: 3, expireSeconds: 30 });
    const newStake = new StakedFarm({
      user,
      nft_id,
      power_level,
      stakedAt: new Date(),
    });
    await newStake.save();
    res.json({ success: true, transaction_id: result.transaction_id });
  } catch (error) {
    handleError(res, error, 'Error staking NFT');
  }
});

export default router;
