import express from 'express';
import axios from 'axios';

const router = express.Router();

// Environment variables
const WAX_API = process.env.WAX_TESTNET_API;
const CONTRACT_NAME = 'stakingdapp1';

/**
 * GET /kek-staking/pools
 * Fetch active KEK staking pools
 */
router.get('/pools', async (req, res) => {
  try {
    const response = await axios.post(`${WAX_API}/v1/chain/get_table_rows`, {
      json: true,
      code: CONTRACT_NAME,
      scope: CONTRACT_NAME,
      table: 'pools',
      limit: 100,
    });

    // Filter active pools
    const pools = response.data.rows.filter(pool => pool.is_active);
    res.json({ pools });
  } catch (error) {
    console.error('Error fetching KEK staking pools:', error.message);
    res.status(500).json({ error: 'Failed to fetch KEK staking pools' });
  }
});

/**
 * GET /kek-staking/user/:username
 * Fetch staking details for a specific user in KEK
 */
router.get('/user/:username', async (req, res) => {
  const { username } = req.params;

  try {
    const response = await axios.post(`${WAX_API}/v1/chain/get_table_rows`, {
      json: true,
      code: CONTRACT_NAME,
      scope: username, // Scope is the user's account name
      table: 'stakeds',
      limit: 100,
    });

    const stakingDetails = response.data.rows;
    res.json({ stakingDetails });
  } catch (error) {
    console.error(`Error fetching KEK staking details for user ${username}:`, error.message);
    res.status(500).json({ error: `Failed to fetch KEK staking details for user ${username}` });
  }
});

export default router;
