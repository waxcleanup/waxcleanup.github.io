// backend/routes/geckoRoutes.js
import express from "express";
import axios from "axios";
import Pool from "../models/Pool.js";
import pLimit from "p-limit";

const router = express.Router();
const limit = pLimit(5);

// ─────────────────────────────────────────────────────────────────────
// Constants & Helpers
// ─────────────────────────────────────────────────────────────────────
const EOS_HISTORY     = "https://wax.eosusa.io/v2/history/get_actions";
const EOS_RPC         = "https://wax.greymass.com/v1/chain/get_currency_stats";
const ALCOR_POOL_BASE = "https://alcor.exchange/api/v2/swap/pools";
const DEX_ACCOUNT     = "swap.alcor";

const http     = axios.create({ timeout: 5000 });
const longHttp = axios.create({ timeout: 60000 });

// GET /latest-block
router.get("/latest-block", async (req, res) => {
  try {
    const { data } = await http.get(EOS_HISTORY, {
      params: { account: DEX_ACCOUNT, limit: 1, sort: "desc" }
    });
    const act = data.actions?.[0];
    if (!act) throw new Error("no actions");
    res.json({
      block: {
        blockNumber:    act.block_num,
        blockTimestamp: Math.floor(new Date(act.timestamp).getTime() / 1000)
      }
    });
  } catch (err) {
    console.error("[latest-block]", err.message);
    res.status(500).json({ error: "Failed to fetch latest block." });
  }
});

// GET /asset?id=SYMBOL@contract
router.get("/asset", async (req, res) => {
  const { id } = req.query;
  if (!id) return res.status(400).json({ error: "Missing asset id" });
  const [symbol, contract] = id.split("@");
  const alcorId = `${symbol.toLowerCase()}-${contract}`;

  try {
    const { data } = await http.get(
      `${ALCOR_POOL_BASE.replace("/swap/pools", "/tokens")}/${alcorId}`
    );
    const t = Array.isArray(data) ? data[0] : data;
    if (!t) return res.status(404).json({ error: `Asset ${id} not found` });

    const asset = {
      id,
      name:       t.symbol.toUpperCase(),
      symbol:     t.symbol.toUpperCase(),
      decimals:   t.decimals,
      totalSupply:       0,
      circulatingSupply:  0,
      coinGeckoId:       t.coin_gecko_id ?? null,
      metadata:          { contract }
    };

    const statsRes = await http.post(EOS_RPC, { code: contract, symbol: t.symbol });
    const entryKey  = `${t.decimals},${t.symbol}`;
    const stats     = statsRes.data[entryKey] || Object.values(statsRes.data)[0] || {};
    if (stats.max_supply) {
      const max = parseFloat(stats.max_supply.split(" ")[0]);
      asset.totalSupply       = max;
      asset.circulatingSupply = max;
    }

    res.json({ asset });
  } catch (err) {
    console.error("[asset]", err.message);
    res.status(500).json({ error: "Failed to fetch asset." });
  }
});

// GET /pairs
router.get("/pairs", async (req, res) => {
  try {
    const dbPools = await Pool.find().lean();
    const out = dbPools.map(p => ({
      id:       p.poolId.toString(),
      asset0Id: `${p.tokenASymbol}@${p.tokenAContract}`,
      asset1Id: `${p.tokenBSymbol}@${p.tokenBContract}`,
      metadata: { feeBps: Math.floor(p.fee / 100) }
    }));
    res.json(out);
  } catch (err) {
    console.error("[pairs]", err.message);
    res.status(500).json({ error: "Failed to fetch pairs." });
  }
});

// GET /pair?id=NUMERIC_POOL_ID
router.get("/pair", async (req, res) => {
  const raw = req.query.id;
  const pid = parseInt(raw, 10);
  if (isNaN(pid)) return res.status(400).json({ error: "Pair ID must be numeric" });

  try {
    const p = await Pool.findOne({ poolId: pid }).lean();
    if (!p) return res.status(404).json({ error: `Pair ${pid} not found` });

    res.json({
      pair: {
        id:       p.poolId.toString(),
        dexKey:   "alcor",
        asset0Id: `${p.tokenASymbol}@${p.tokenAContract}`,
        asset1Id: `${p.tokenBSymbol}@${p.tokenBContract}`,
        metadata: { feeBps: Math.floor(p.fee / 100) }
      }
    });
  } catch (err) {
    console.error("[pair]", err.message);
    res.status(500).json({ error: "Failed to fetch pair." });
  }
});

// ─────────────────────────────────────────────────────────────────────
// In-memory caches & pool map refresh
// ─────────────────────────────────────────────────────────────────────
let pairMap = {};
let poolInfoMap = {};
async function refreshPoolMaps() {
  const pools = await Pool.find().lean();
  const newPairMap = {};
  const newPoolInfo = {};
  pools.forEach(p => {
    const pid = p.poolId.toString();
    newPairMap[`${p.tokenASymbol}@${p.tokenAContract}|${p.tokenBSymbol}@${p.tokenBContract}`] = pid;
    newPairMap[`${p.tokenBSymbol}@${p.tokenBContract}|${p.tokenASymbol}@${p.tokenAContract}`] = pid;
    newPoolInfo[pid] = p;
  });
  pairMap     = newPairMap;
  poolInfoMap = newPoolInfo;
  console.log(`[events] pool maps refreshed: ${Object.keys(pairMap).length/2} pairs`);
}
refreshPoolMaps();
setInterval(refreshPoolMaps, 60_000);

// ─────────────────────────────────────────────────────────────────────
// Reserve cache & retry helper
// ─────────────────────────────────────────────────────────────────────
const reserveCache = new Map();
function getCachedReserves(poolId) {
  const e = reserveCache.get(poolId);
  return e && (Date.now() - e.ts < 5000) ? e.data : null;
}
function setCachedReserves(poolId, data) {
  reserveCache.set(poolId, { data, ts: Date.now() });
}
async function fetchReservesWithRetry(poolId, attempts = 3) {
  let lastError;
  for (let i = 0; i < attempts; i++) {
    try {
      const response = await longHttp.get(
        `${ALCOR_POOL_BASE}/${poolId}`,
        { params: { chain: "wax" } }
      );
      return {
        asset0: response.data.tokenA?.quantity ?? "0",
        asset1: response.data.tokenB?.quantity ?? "0"
      };
    } catch (err) {
      lastError = err;
      await new Promise(r => setTimeout(r, 200 * 2**i));
    }
  }
  throw lastError;
}

// ─────────────────────────────────────────────────────────────────────
// GET /events?fromBlock=X&toBlock=Y
// ─────────────────────────────────────────────────────────────────────
router.get("/events", async (req, res) => {
  const fromBlock = parseInt(req.query.fromBlock || "0", 10);
  const toBlock   = parseInt(req.query.toBlock   || "999999999", 10);

  try {
    // 1) fetch raw actions
    const { data } = await http.get(EOS_HISTORY, {
      params: { account: DEX_ACCOUNT, limit: 1000, sort: "desc" }
    });
    const actions = data.actions || [];

    // 2) group by transaction
    const byTx = actions.reduce((acc, act) => {
      (acc[act.trx_id] ||= []).push(act);
      return acc;
    }, {});

    // 3) collect poolIds
    const poolIds = new Set();
    for (const acts of Object.values(byTx)) {
      if (!acts.length) continue;
      const { block_num } = acts[0];
      if (block_num < fromBlock || block_num > toBlock) continue;

      // join
      const j = acts.find(a => a.act.name === "logmint");
      if (j) poolIds.add(String(j.act.data.poolId));

      // exit candidates
      const x = acts.find(a => a.act.name === "subliquid");
      if (x) poolIds.add(String(x.act.data.poolId));

      // swap candidates
      const inbound  = acts.find(a => a.act.data.to === DEX_ACCOUNT && a.act.data.quantity);
      const outbound = inbound && acts.find(a =>
        a.act.data.from === DEX_ACCOUNT &&
        a.act.data.to   === inbound.act.data.from &&
        a.act.data.quantity
      );
      if (inbound && outbound) {
        const symA = inbound.act.data.quantity.split(" ")[1];
        const symB = outbound.act.data.quantity.split(" ")[1];
        const key  = `${symA}@${inbound.act.account}|${symB}@${outbound.act.account}`;
        if (pairMap[key]) poolIds.add(pairMap[key]);
      }
    }

    // 4) fetch & cache reserves with concurrency limit
    const reserveMap = {};
    await Promise.all(
      [...poolIds].map(pid =>
        limit(async () => {
          let r = getCachedReserves(pid);
          if (!r) {
            try {
              r = await fetchReservesWithRetry(pid);
              setCachedReserves(pid, r);
            } catch (err) {
              console.error(`[events] reserve fetch failed for ${pid}:`, err.message);
              r = { asset0: "0", asset1: "0" };
            }
          }
          reserveMap[pid] = r;
        })
      )
    );

    // 5) build & filter events
    const events        = [];
    const blockCounts   = {};
    const txnEventCount = {};

    const pushEvt = (evt, block_num, timestamp, txnId) => {
      const ts        = Math.floor(new Date(timestamp).getTime() / 1000);
      blockCounts[block_num] = (blockCounts[block_num] || 0) + 1;
      const txnIndex = blockCounts[block_num] - 1;
      txnEventCount[txnId] ||= 0;

      events.push({
        block:       { blockNumber: block_num, blockTimestamp: ts },
        txnId,
        txnIndex,
        eventIndex: txnEventCount[txnId]++,
        ...evt
      });
    };

    for (const [txnId, acts] of Object.entries(byTx)) {
      if (!acts.length) continue;
      const { block_num, timestamp } = acts[0];
      if (block_num < fromBlock || block_num > toBlock) continue;

      // JOIN
      const jEvt = acts.find(a => a.act.name === "logmint");
      if (jEvt) {
        const { poolId, owner, tokenA, tokenB } = jEvt.act.data;
        pushEvt({
          eventType: "join",
          maker:     owner,
          pairId:    String(poolId),
          amount0:   parseFloat(tokenA).toFixed(50),
          amount1:   parseFloat(tokenB).toFixed(50),
          reserves:  reserveMap[String(poolId)]
        }, block_num, timestamp, txnId);
      }

      // EXIT (only if Decrease liquidity transfers exist)
      const xEvt = acts.find(a => a.act.name === "subliquid");
      if (xEvt) {
        const pid = String(xEvt.act.data.poolId);
        const p   = poolInfoMap[pid] || {};
        let a0 = 0, a1 = 0;
        acts
          .filter(a =>
            a.act.name === "transfer" &&
            a.act.data.from === DEX_ACCOUNT &&
            a.act.data.memo?.includes("Decrease liquidity")
          )
          .forEach(o => {
            const [amt, sym] = o.act.data.quantity.split(" ");
            if (sym === p.tokenASymbol) a0 = parseFloat(amt);
            if (sym === p.tokenBSymbol) a1 = parseFloat(amt);
          });
        if (a0 !== 0 || a1 !== 0) {
          const maker = acts.find(a =>
            a.act.name === "transfer" &&
            a.act.data.to !== DEX_ACCOUNT
          )?.act.data.to;
          pushEvt({
            eventType: "exit",
            maker,
            pairId:   pid,
            amount0:  a0.toFixed(50),
            amount1:  a1.toFixed(50),
            reserves: reserveMap[pid]
          }, block_num, timestamp, txnId);
        }
      }

      // SWAP
      const inEvt  = acts.find(a => a.act.data.to === DEX_ACCOUNT && a.act.data.quantity);
      const outEvt = inEvt && acts.find(a =>
        a.act.data.from === DEX_ACCOUNT &&
        a.act.data.to   === inEvt.act.data.from &&
        a.act.data.quantity
      );
      if (inEvt && outEvt) {
        const [iAmt, iSym] = inEvt.act.data.quantity.split(" ");
        const [oAmt, oSym] = outEvt.act.data.quantity.split(" ");
        const key           = `${iSym}@${inEvt.act.account}|${oSym}@${outEvt.act.account}`;
        const pid           = pairMap[key];
        if (pid) {
          const p      = poolInfoMap[pid] || {};
          const inNum  = parseFloat(iAmt);
          const outNum = parseFloat(oAmt);

          if (iSym === p.tokenASymbol && oSym === p.tokenBSymbol) {
            pushEvt({
              eventType:   "swap",
              maker:       inEvt.act.data.from,
              pairId:      pid,
              asset0In:    inNum.toFixed(50),
              asset1Out:   outNum.toFixed(50),
              priceNative: (outNum / inNum).toFixed(50),
              reserves:    reserveMap[pid]
            }, block_num, timestamp, txnId);

          } else if (iSym === p.tokenBSymbol && oSym === p.tokenASymbol) {
            pushEvt({
              eventType:   "swap",
              maker:       inEvt.act.data.from,
              pairId:      pid,
              asset1In:    inNum.toFixed(50),
              asset0Out:   outNum.toFixed(50),
              priceNative: (outNum / inNum).toFixed(50),
              reserves:    reserveMap[pid]
            }, block_num, timestamp, txnId);
          }
        }
      }
    }

    // respond only swap/join/exit
    res.json({
      events: events.filter(e =>
        ["swap","join","exit"].includes(e.eventType)
      )
    });

  } catch (err) {
    console.error("[events] error:", err.message);
    res.status(500).json({ error: "Failed to fetch events." });
  }
});

export default router;
