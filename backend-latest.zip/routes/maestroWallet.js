// routes/maestroWallet.js
import express from 'express';
import { 
  loginWallet, 
  signTransaction,
  transferTokens // Add this new import
} from '../controllers/maestroWalletController.js';

const router = express.Router();

// Route to log in to a Maestro Wallet
router.post('/login', loginWallet);

// Route for signing transactions
router.post('/sign-transaction', signTransaction);

// New route for transferring tokens
router.post('/transfer', transferTokens);

export default router;
