// ~/backend/routes/burnStatus.js
import express from 'express';
import BurnDailyUsage from '../models/BurnDailyUsage.js';

const router = express.Router();

const USER_DAILY_CAP = 1000;
const INCIN_DAILY_CAP = 300;

function utcDayKey() {
  return new Date().toISOString().slice(0, 10); // "YYYY-MM-DD" UTC
}

function nextUtcMidnightIso() {
  const now = new Date();
  return new Date(Date.UTC(
    now.getUTCFullYear(),
    now.getUTCMonth(),
    now.getUTCDate() + 1, 0, 0, 0, 0
  )).toISOString();
}

/**
 * GET /burn-status/:user/:incineratorId
 * Returns both user + incinerator usage for today (UTC).
 */
router.get('/:user/:incineratorId', async (req, res) => {
  try {
    const { user, incineratorId } = req.params;
    const day = utcDayKey();

    const [userDoc, incDoc] = await Promise.all([
      BurnDailyUsage.findOne({ scope: 'user', key: String(user), day }).lean(),
      BurnDailyUsage.findOne({ scope: 'incinerator', key: String(incineratorId), day }).lean(),
    ]);

    const userUsed = userDoc?.count || 0;
    const incUsed = incDoc?.count || 0;

    return res.json({
      success: true,
      data: {
        user: {
          used: userUsed,
          cap: USER_DAILY_CAP,
          remaining: Math.max(0, USER_DAILY_CAP - userUsed),
          resetAt: nextUtcMidnightIso(),
        },
        incinerator: {
          used: incUsed,
          cap: INCIN_DAILY_CAP,
          remaining: Math.max(0, INCIN_DAILY_CAP - incUsed),
          resetAt: nextUtcMidnightIso(),
        },
      },
    });
  } catch (err) {
    console.error('[burn-status] error:', err.message || err);
    return res.status(500).json({ success: false, message: err.message || 'FAILED' });
  }
});

/**
 * (Optional) keep backward compat:
 * GET /burn-status/:user?incineratorId=109...
 */
router.get('/:user', async (req, res) => {
  try {
    const { user } = req.params;
    const { incineratorId } = req.query;
    const day = utcDayKey();

    const userDoc = await BurnDailyUsage.findOne({ scope: 'user', key: String(user), day }).lean();
    const userUsed = userDoc?.count || 0;

    let incUsed = 0;
    if (incineratorId) {
      const incDoc = await BurnDailyUsage.findOne({
        scope: 'incinerator',
        key: String(incineratorId),
        day,
      }).lean();
      incUsed = incDoc?.count || 0;
    }

    return res.json({
      success: true,
      data: {
        user: {
          used: userUsed,
          cap: USER_DAILY_CAP,
          remaining: Math.max(0, USER_DAILY_CAP - userUsed),
          resetAt: nextUtcMidnightIso(),
        },
        incinerator: {
          used: incUsed,
          cap: INCIN_DAILY_CAP,
          remaining: Math.max(0, INCIN_DAILY_CAP - incUsed),
          resetAt: nextUtcMidnightIso(),
        },
      },
    });
  } catch (err) {
    console.error('[burn-status] error:', err.message || err);
    return res.status(500).json({ success: false, message: err.message || 'FAILED' });
  }
});

export default router;
