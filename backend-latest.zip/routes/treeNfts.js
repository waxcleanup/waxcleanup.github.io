// routes/treeNfts.js
import express from 'express';
import {
  getRegisteredTemplates,
  getUserRegisteredNFTs,
  getNFTsByCollection,
  getRegisteredTemplatesByCollection
} from '../controllers/treeNftsController.js';

const router = express.Router();

// Route to fetch all registered NFT templates
router.get('/registered', getRegisteredTemplates);

// Route to fetch user's registered NFTs
router.get('/user-assets/:wallet', getUserRegisteredNFTs);   // ✅ FIXED HERE

// Route to fetch NFTs from a specific collection and wallet
router.get('/collection/:collection/:account', getNFTsByCollection);

// Route to fetch registered templates for a specific collection
router.get('/registered/:collection', getRegisteredTemplatesByCollection);

export default router;
