// collectionRoutes.js
import express from 'express';
import fetch from 'node-fetch';
import crypto from 'crypto';
import {
  syncData,
  syncCollectionSchemasAndTemplates
} from '../services/fetchService.js';
import Collection from '../models/Collection.js';
import Schema from '../models/Schema.js';
import NFTTemplate from '../models/NFTTemplate.js';

const router = express.Router();

const CONTRACT_NAME = process.env.BACKEND_CONTRACT_NAME || 'cleanupcentr';
const RPC_ENDPOINT = process.env.BACKEND_RPC_ENDPOINT || 'https://api.wax.alohaeos.com';

/* ──────────────────────────────────────────────────────────────
   ADMIN guard for dangerous sync endpoints
   - prevents users from spamming full template sync
────────────────────────────────────────────────────────────── */
function requireAdminSyncKey(req, res, next) {
  const key = req.headers['x-admin-key'];

  // If you forgot to set it, fail closed to avoid accidental exposure
  if (!process.env.ADMIN_SYNC_KEY) {
    return res.status(500).json({ error: 'ADMIN_SYNC_KEY not set on server' });
  }

  if (!key || key !== process.env.ADMIN_SYNC_KEY) {
    return res.status(403).json({ error: 'Forbidden' });
  }

  next();
}

/* ──────────────────────────────────────────────────────────────
   Simple in-memory job store for sync tasks
   (survives process lifetime; OK under PM2 which keeps the proc up)
────────────────────────────────────────────────────────────── */
const jobs = new Map(); // jobId -> { status, startedAt, finishedAt, error, progress, collection }

/** Create a new job entry */
function createJob(collection) {
  const jobId = crypto.randomUUID();
  const rec = {
    jobId,
    collection,
    status: 'queued',      // queued | running | succeeded | failed
    startedAt: null,
    finishedAt: null,
    error: null,
    progress: { steps: [], percent: 0 }
  };
  jobs.set(jobId, rec);
  return rec;
}

/** Update job progress helper (optional, you can call this from fetchService if desired) */
function setProgress(job, percent, note) {
  job.progress.percent = Math.max(0, Math.min(100, percent));
  if (note) job.progress.steps.push({ t: Date.now(), note });
}

/** Run the sync work without blocking the HTTP request */
async function runCollectionSync(job) {
  job.status = 'running';
  job.startedAt = new Date().toISOString();
  try {
    // (Optional) incremental progress hints
    setProgress(job, 5, `Starting sync for ${job.collection}…`);
    await syncCollectionSchemasAndTemplates(job.collection);
    setProgress(job, 100, 'Completed');
    job.status = 'succeeded';
    job.finishedAt = new Date().toISOString();
  } catch (err) {
    job.status = 'failed';
    job.error = (err && (err.message || String(err))) || 'Unknown error';
    job.finishedAt = new Date().toISOString();
  }
}

/* ──────────────────────────────────────────────────────────────
   Blockchain-approved templates passthrough
────────────────────────────────────────────────────────────── */
router.get('/approved-templates', async (req, res) => {
  try {
    const response = await fetch(`${RPC_ENDPOINT}/v1/chain/get_table_rows`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        code: CONTRACT_NAME,
        scope: CONTRACT_NAME,
        table: 'approvednfts',
        json: true,
        limit: 1000,
      }),
    });

    if (!response.ok) throw new Error(`Fetch failed with status ${response.status}`);

    const data = await response.json();
    res.status(200).json(data.rows || []);
  } catch (error) {
    console.error('[ERROR] Fetching approved templates:', error.message);
    res.status(500).json({ error: 'Failed to fetch approved templates from blockchain.' });
  }
});

/* ──────────────────────────────────────────────────────────────
   Sync all collections (names only) -> still synchronous but quick
────────────────────────────────────────────────────────────── */
router.post('/sync', async (req, res) => {
  try {
    await syncData();
    res.status(200).json({ message: 'Collections sync initiated successfully.' });
  } catch (error) {
    console.error('Error during collections sync:', error);
    res.status(500).json({ error: 'Failed to initiate collections sync.' });
  }
});

/* ──────────────────────────────────────────────────────────────
   NEW: Async sync for a given collection (no timeout)
   - Returns 202 + jobId immediately
   - Poll GET /collections/sync-jobs/:jobId for status
   ⚠️ PROTECTED: requires x-admin-key header
────────────────────────────────────────────────────────────── */
router.post('/:collectionName/sync-schemas-templates', requireAdminSyncKey, async (req, res) => {
  const { collectionName } = req.params;
  try {
    const job = createJob(collectionName);
    // Detach execution
    setImmediate(() => runCollectionSync(job));
    res.status(202).json({
      message: `Sync queued for ${collectionName}`,
      jobId: job.jobId,
      poll: `/collections/sync-jobs/${job.jobId}`,
      collection: collectionName
    });
  } catch (error) {
    console.error(`Error queueing sync for ${collectionName}:`, error);
    res.status(500).json({ error: 'Failed to queue sync job.' });
  }
});

/* Poll job status */
router.get('/sync-jobs/:jobId', (req, res) => {
  const job = jobs.get(req.params.jobId);
  if (!job) return res.status(404).json({ error: 'Job not found' });
  res.json(job);
});

/* ──────────────────────────────────────────────────────────────
   Paginated collections with optional search
────────────────────────────────────────────────────────────── */
router.get('/', async (req, res) => {
  const limit = parseInt(req.query.limit, 10) || 100;
  const page = parseInt(req.query.page, 10) || 1;
  const search = req.query.search || '';

  try {
    const query = search ? { collection_name: new RegExp(search, 'i') } : {};
    const totalItems = await Collection.countDocuments(query);
    const collections = await Collection.find(query)
      .sort({ collection_name: 1 })
      .skip((page - 1) * limit)
      .limit(limit);

    res.json({
      collections: collections || [],
      pagination: {
        totalItems,
        currentPage: page,
        totalPages: Math.ceil(totalItems / limit),
      },
    });
  } catch (error) {
    console.error('Error fetching collections:', error);
    res.status(500).json({ error: 'Failed to fetch collections.' });
  }
});

/* Schemas for a collection */
router.get('/:collection/schemas', async (req, res) => {
  const { collection } = req.params;
  try {
    const schemas = await Schema.find({ collection_name: collection });
    res.json(schemas || []);
  } catch (error) {
    console.error(`Error fetching schemas for ${collection}:`, error);
    res.status(500).json({ error: 'Failed to fetch schemas.' });
  }
});

/* Templates for a schema */
router.get('/:collection/schemas/:schema/templates', async (req, res) => {
  const { collection, schema } = req.params;
  try {
    const templates = await NFTTemplate.find({ collection_name: collection, schema_name: schema });
    res.json(templates || []);
  } catch (error) {
    console.error(`Error fetching templates for ${schema} in ${collection}:`, error);
    res.status(500).json({ error: 'Failed to fetch templates.' });
  }
});

/* Detailed template info */
router.get('/:collection/templates/:templateId', async (req, res) => {
  const { collection, templateId } = req.params;

  try {
    const template = await NFTTemplate.findOne({
      collection_name: collection,
      template_id: Number(templateId),
    });

    if (!template) return res.status(404).json({ error: 'Template not found' });

    res.json({
      template_id: template.template_id,
      collection_name: template.collection_name,
      schema_name: template.schema_name,
      template_name: template.template_name,
      supply: template.supply,
      circulating_supply: template.circulating_supply,
      img: template.img || '',
      video: template.video || '',
      updatedAt: template.updatedAt,
    });
  } catch (error) {
    console.error(`Error fetching template ${templateId} in ${collection}:`, error);
    res.status(500).json({ error: 'Failed to fetch template details' });
  }
});

export default router;
