// routes/alcorPools.js

import express from 'express';
import axios from 'axios';
import NodeCache from 'node-cache';

const router = express.Router();

const WAX_MAINNET_API = process.env.WAX_MAINNET_API || 'https://wax.greymass.com';
const ALCOR_HISTORY_API = process.env.ALCOR_HISTORY_API || 'https://wax.eosrio.io/v2/history/get_actions';
const cache = new NodeCache({ stdTTL: 300 }); // Cache valid for 5 minutes

const delay = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

// Retry logic for handling rate limits
const fetchWithRetry = async (url, retries = 3, delayMs = 1000) => {
    for (let attempt = 0; attempt < retries; attempt++) {
        try {
            const response = await axios.get(url);
            return response.data;
        } catch (error) {
            if (error.response && error.response.status === 429 && attempt < retries - 1) {
                console.log('Rate limit hit, retrying...');
                await delay(delayMs);
            } else {
                throw error;
            }
        }
    }
};

// Helper function to fetch pool positions
const fetchPoolPositions = async (poolId, account) => {
    console.log(`Fetching positions for poolId: ${poolId}, account: ${account}`);

    try {
        const response = await axios.post(`${WAX_MAINNET_API}/v1/chain/get_table_rows`, {
            json: true,
            code: 'swap.alcor',
            scope: poolId,
            table: 'positions',
            limit: 1000,
        });

        const userPositions = response.data.rows.filter((row) => row.owner === account);
        console.log(`Found ${userPositions.length} positions for poolId ${poolId}`);
        return userPositions;
    } catch (error) {
        console.error(`Error fetching positions for pool ${poolId}:`, error.message);
        throw new Error(`Failed to fetch positions for pool ${poolId}`);
    }
};

// Fetch all pools you've added liquidity to
const fetchUserPools = async (account) => {
    const cacheKey = `userPools-${account}`;
    const cachedPools = cache.get(cacheKey);

    if (cachedPools) {
        console.log(`Cache hit for ${cacheKey}`);
        return cachedPools;
    }

    try {
        let poolIds = [];
        let page = 1;

        while (true) {
            const url = `${ALCOR_HISTORY_API}?account=${account}&filter=swap.alcor:addliquid&page=${page}`;
            console.log(`Fetching page ${page} for user pools`);
            const data = await fetchWithRetry(url, 5, 2000); // Retry logic with 5 attempts

            if (!data.actions || data.actions.length === 0) break;

            poolIds.push(...data.actions.map((action) => action.act.data.poolId));

            if (data.actions.length < 100) break; // No more pages
            page++;
            await delay(500); // Add a delay between requests to avoid hitting rate limits
        }

        const uniquePoolIds = [...new Set(poolIds)];
        cache.set(cacheKey, uniquePoolIds); // Cache the pool IDs
        return uniquePoolIds;
    } catch (error) {
        console.error('Error fetching user pools:', error);
        throw new Error('Failed to fetch user pools');
    }
};

// Route to fetch all pools and positions for a user
router.get('/user-pools/:account', async (req, res) => {
    const { account } = req.params;
    console.log(`Fetching all pools and positions for account: ${account}`);

    try {
        const poolIds = await fetchUserPools(account);
        const positions = await Promise.all(
            poolIds.map(async (poolId) => {
                const userPositions = await fetchPoolPositions(poolId, account);
                return { poolId, positions: userPositions };
            })
        );

        console.log(`Total pools fetched for ${account}: ${positions.length}`);
        res.json({ pools: positions });
    } catch (error) {
        console.error(`Error fetching pools for ${account}:`, error.message);
        res.status(500).json({ error: error.message });
    }
});

// Export `fetchUserPools` so other files (like `burnReward.js`) can use it
export { fetchUserPools };

export default router;
