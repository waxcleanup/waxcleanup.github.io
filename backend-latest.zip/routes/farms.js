// routes/farms.js
import express from 'express';
import { getAllFarms, unstakeFarm } from '../controllers/farmController.js';
import { getFarmPlots } from '../controllers/farmPlotsController.js';

const router = express.Router();

router.get('/', getAllFarms);
router.post('/unstake', unstakeFarm);

// NEW: plots for a specific farm
router.get('/:farmId/plots', getFarmPlots);

export default router;
