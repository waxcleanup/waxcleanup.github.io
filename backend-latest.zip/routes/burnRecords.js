import express from 'express';
import { fetchBurnRecords, fetchAllBurnRecords, fetchBurnRecordsByAssetId } from '../services/burnRecords.js';

const router = express.Router();

// Endpoint to fetch burn records for a specific user
router.get('/:user', async (req, res) => {
    const { user } = req.params;
    try {
        const records = await fetchBurnRecords(user);
        res.status(200).json({ success: true, records });
    } catch (error) {
        console.error(`Error fetching burn records for user ${user}:`, error.message);
        res.status(500).json({ success: false, error: 'Failed to fetch burn records' });
    }
});

// Endpoint to fetch all burn records
router.get('/all', async (req, res) => {
    try {
        const records = await fetchAllBurnRecords();
        res.status(200).json({ success: true, records });
    } catch (error) {
        console.error('Error fetching all burn records:', error.message);
        res.status(500).json({ success: false, error: 'Failed to fetch all burn records' });
    }
});

// Endpoint to fetch burn records by asset ID
router.get('/asset/:assetId', async (req, res) => {
    const { assetId } = req.params;
    try {
        const records = await fetchBurnRecordsByAssetId(assetId);
        res.status(200).json({ success: true, records });
    } catch (error) {
        console.error(`Error fetching burn records for asset ID ${assetId}:`, error.message);
        res.status(500).json({ success: false, error: 'Failed to fetch burn records by asset ID' });
    }
});

export default router;
