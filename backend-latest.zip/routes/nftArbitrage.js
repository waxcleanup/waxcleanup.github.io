import express from 'express';
import axios from 'axios';
import NFTPrice from '../models/NFTPrice.js';
import NFTArbitrage from '../models/NFTArbitrage.js';
import mongoose from 'mongoose';

const router = express.Router();

// Fetch latest TLM price in WAX from CoinGecko
const fetchTLMPriceInWAX = async () => {
    try {
        const response = await axios.get("https://api.coingecko.com/api/v3/simple/price?ids=alien-worlds,wax&vs_currencies=usd");
        const tlmUSD = response.data["alien-worlds"].usd;
        const waxUSD = response.data["wax"].usd;
        return tlmUSD / waxUSD; // Convert TLM to WAX
    } catch (error) {
        console.error('❌ Error fetching TLM/WAX price:', error);
        return null;
    }
};

// Fetch NFT market data
const fetchNFTMarketData = async (templateId) => {
    try {
        const response = await axios.get(`https://maestrobeatz.servegame.com:3003/nft-prices/top5/${templateId}`);
        return response.data;
    } catch (error) {
        console.error(`❌ Error fetching NFT market data for template ${templateId}:`, error);
        return null;
    }
};

// Function to recursively check multi-step arbitrage paths
const checkMultiStepArbitrage = async (source, finalTarget, blendSteps, tlmToWAX) => {
    let totalBuyCost = 0;
    let totalBlendCost = 0;
    let currentTemplate = source;
    let marketData = [];

    for (const step of blendSteps) {
        const nftSource = await fetchNFTMarketData(currentTemplate);
        const nftTarget = await fetchNFTMarketData(step.target);

        if (!nftSource || !nftSource.listings.length || !nftTarget || !nftTarget.listings.length) {
            console.log(`❌ Missing market data for templates ${currentTemplate} or ${step.target}. Skipping.`);
            return null;
        }

        const singleBuyPrice = nftSource.listings[0].price;
        const stepBuyCost = parseFloat(singleBuyPrice) * 4; // 4-to-1 blend multiplier
        const stepBlendCost = (step.tlmCost * tlmToWAX).toFixed(4);

        totalBuyCost += stepBuyCost;
        totalBlendCost += parseFloat(stepBlendCost);
        marketData.push({
            step: `${currentTemplate} → ${step.target}`,
            buyListings: nftSource.listings,
            sellListings: nftTarget.listings,
            blendCostTLM: step.tlmCost,
            blendCostWAX: stepBlendCost
        });

        currentTemplate = step.target; // Move to the next blend step
    }

    // Final sale price
    const nftFinalTarget = await fetchNFTMarketData(finalTarget);
    if (!nftFinalTarget || !nftFinalTarget.listings.length) {
        console.log(`❌ Missing final sale data for template ${finalTarget}. Skipping.`);
        return null;
    }

    const finalSellPrice = nftFinalTarget.listings[0].price;
    const totalCost = totalBuyCost + totalBlendCost;
    const profit = (finalSellPrice - totalCost).toFixed(4);

    const recommendedSellPrice = (finalSellPrice * 0.97).toFixed(4); // 3% discount
    const aggressiveSellPrice = (finalSellPrice * 0.95).toFixed(4); // 5% discount

    if (totalCost < finalSellPrice) {
        console.log(`🚀 Full Arbitrage Opportunity! Buy ${source} (4x) for ${totalBuyCost} WAX, blend for ${totalBlendCost} WAX, and sell ${finalTarget} for ${finalSellPrice} WAX. Profit: ${profit} WAX`);

        // Save to MongoDB
        await NFTArbitrage.findOneAndUpdate(
            { sourceTemplate: source, targetTemplate: finalTarget },
            { $set: { buyPrice: totalBuyCost, blendCost: totalBlendCost, sellPrice: finalSellPrice, profit, recommendedSellPrice, aggressiveSellPrice, flaggedAt: new Date(), marketData } },
            { new: true, upsert: true }
        );

        return {
            sourceTemplate: source,
            targetTemplate: finalTarget,
            buyPrice: totalBuyCost,
            blendCost: totalBlendCost,
            sellPrice: finalSellPrice,
            profit,
            recommendedSellPrice,
            aggressiveSellPrice,
            marketData
        };
    }
    return null;
};

// Function to check all arbitrage opportunities
const checkArbitrage = async () => {
    try {
        const tlmToWAX = await fetchTLMPriceInWAX();
        if (!tlmToWAX) {
            console.error("❌ Unable to fetch TLM price. Skipping arbitrage check.");
            return { success: false, message: "TLM price unavailable" };
        }

        const arbitragePaths = [
            {
                source: 19554,
                finalTarget: 48183,
                blendSteps: [
                    { target: 48155, tlmCost: 20 },
                    { target: 48183, tlmCost: 40 }
                ]
            },
            {
                source: 19553,
                finalTarget: 48154,
                blendSteps: [
                    { target: 48154, tlmCost: 20 }
                ]
            },
            {
                source: 19552,
                finalTarget: 48153,
                blendSteps: [
                    { target: 48153, tlmCost: 20 }
                ]
            }
        ];

        let opportunities = [];
        for (const path of arbitragePaths) {
            const result = await checkMultiStepArbitrage(path.source, path.finalTarget, path.blendSteps, tlmToWAX);
            if (result) opportunities.push(result);
        }

        return opportunities.length > 0
            ? { success: true, message: "Arbitrage opportunities found", opportunities }
            : { success: false, message: "No arbitrage opportunities" };
    } catch (error) {
        console.error('❌ Error checking arbitrage:', error);
        return { success: false, message: "Error checking arbitrage" };
    }
};

// **✅ Add a GET Route to Trigger Arbitrage Check Manually**
router.get('/', async (req, res) => {
    console.log("🔍 Manual NFT arbitrage check triggered...");
    const result = await checkArbitrage();
    res.json(result);
});

// **📜 New Route to Fetch Arbitrage History**
router.get('/history', async (req, res) => {
    try {
        const history = await NFTArbitrage.find().sort({ flaggedAt: -1 }).limit(20);
        res.json({ success: true, history });
    } catch (error) {
        console.error('❌ Error fetching arbitrage history:', error);
        res.status(500).json({ success: false, message: "Failed to fetch history" });
    }
});

// **✅ Schedule Arbitrage Check Every 10 Minutes**
import cron from 'node-cron';
cron.schedule('*/10 * * * *', async () => {
    console.log('⏳ Running scheduled NFT arbitrage check...');
    await checkArbitrage();
});

export default router;
