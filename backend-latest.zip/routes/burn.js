import express from 'express';
import { calculateBurnReward } from '../services/burnReward.js'; // Import the function

const router = express.Router();

// API Route to get burn reward
router.get('/burn-reward/:templateId/:percentage?', async (req, res) => {
    const templateId = parseInt(req.params.templateId);
    if (isNaN(templateId)) {
        return res.status(400).json({ error: 'Invalid template ID' });
    }

    // Get custom percentage if provided
    const customPercentage = req.params.percentage ? parseFloat(req.params.percentage) / 100 : null;

    // Calculate burn reward
    const reward = await calculateBurnReward(templateId, customPercentage);
    
    if (reward === null) {
        return res.status(404).json({ error: 'Template not approved or data unavailable' });
    }

    // Return reward in WAX and CINDER
    res.json({ 
        templateId, 
        rewardPercentage: customPercentage ? customPercentage * 100 : 80, // Default 80% if not provided
        burnRewardWax: reward.wax, 
        burnRewardCinder: reward.cinder 
    });
});

export default router;
