// routes/cleanup.js
import express from "express";
import {
  fetchProposals,
  fetchApprovedCollections,
  fetchOpenProposals,
  fetchSchemaBurns,
} from "../controllers/cleanupController.js";

const router = express.Router();

/**
 * READ-ONLY routes (contract handles execution; users sign on frontend)
 */
router.get("/proposals", fetchProposals);
router.get("/proposals/open", fetchOpenProposals);

// Template burns (approvednfts + tplcaps)
router.get("/approved-collections", fetchApprovedCollections);

// Schema burns (schemaburns + schemacaps)
router.get("/schema-burns", fetchSchemaBurns);

export default router;
