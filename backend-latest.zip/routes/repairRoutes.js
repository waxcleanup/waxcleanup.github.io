// routes/repairRoutes.js
import express from 'express';
import fetch from 'node-fetch';
import { transact } from '../services/eosService.js'; // <-- we'll set this up next

const router = express.Router();
const RPC = 'https://wax.greymass.com';
const CONTRACT = 'cleanupcentr';
const TABLE = 'repairtrack';

// GET: Check repair status
router.get('/repair-status/:id', async (req, res) => {
  const { id } = req.params;

  try {
    const response = await fetch(`${RPC}/v1/chain/get_table_rows`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        json: true,
        code: CONTRACT,
        scope: CONTRACT,
        table: TABLE,
        lower_bound: id,
        upper_bound: id,
        limit: 1
      })
    });

    const data = await response.json();
    const row = data.rows?.[0];
    if (!row || String(row.incinerator_id) !== String(id)) {
      return res.status(404).json({ error: 'Not found' });
    }

    res.json({
      incinerator_id: row.incinerator_id,
      user: row.user,
      repair_time: row.repair_time,
      repair_points: row.repair_points
    });
  } catch (err) {
    console.error('[repair-status] error', err);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// ✅ NEW: POST /finalize-repair (backend triggers contract)
router.post('/finalize-repair', async (req, res) => {
  const { user, incinerator_id } = req.body;

  if (!user || !incinerator_id) {
    return res.status(400).json({ error: 'Missing user or incinerator_id' });
  }

  try {
    const result = await transact(CONTRACT, 'repairfinal', {
      user,
      incinerator_id: Number(incinerator_id)
    });

    res.json({ success: true, result });
  } catch (err) {
    console.error('[finalize-repair] error', err.message);
    res.status(500).json({ error: err.message || 'Failed to finalize repair' });
  }
});

export default router;
