// models/NFTTemplate.js
import mongoose from 'mongoose';

const nftTemplateSchema = new mongoose.Schema({
  template_id: { type: Number, unique: true, required: true },
  collection_name: { type: String, required: true },
  schema_name: { type: String, required: true },
  template_name: { type: String, default: 'Unnamed Template' },
  supply: { type: Number, default: 0 },
  circulating_supply: { type: Number, default: 0 },
  img: { type: String, default: '' },
  video: { type: String, default: '' },  // Added video field
  updatedAt: { type: Date, default: Date.now }
});

export default mongoose.model('NFTTemplate', nftTemplateSchema);
