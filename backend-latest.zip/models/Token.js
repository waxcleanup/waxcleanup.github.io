// models/Token.js
import mongoose from 'mongoose';

const tokenSchema = new mongoose.Schema({
  id: String,                         // e.g. "CINDER@cleanuptoken"
  createdAtBlockNumber: Number,
  createdAtBlockTimestamp: Number
}, { collection: 'tokens' });

export default mongoose.model('Token', tokenSchema);
