import mongoose from 'mongoose';

const burnRecordSchema = new mongoose.Schema({
    burn_id: { type: Number, required: true, unique: true }, // Matches the blockchain field
    user: { type: String, required: true },
    asset_id: { type: String, required: true },
    collection: { type: String },
    schema: { type: String },
    template_id: { type: Number },
    trash_fee: { type: String },
    cinder_reward: { type: String },
    status: { type: String },
    burned_at: { type: Date },
});

const BurnRecord = mongoose.models.BurnRecord || mongoose.model('BurnRecord', burnRecordSchema);

export default BurnRecord;
