import mongoose from 'mongoose';

const StakedNFTSchema = new mongoose.Schema({
  nft_id: { type: String, required: true, unique: true },
  owner: { type: String, required: true },
  power_level: { type: Number, required: true },
  staked_at: { type: Date, default: Date.now },
});

export default mongoose.model('StakedNFT', StakedNFTSchema);
