import mongoose from 'mongoose';

const FarmerSchema = new mongoose.Schema({
  accountName: { type: String, required: true, unique: true },
  username: { type: String, required: true }, // Change nickname to username
  createdAt: { type: Date, default: Date.now }
});

export default mongoose.model('Farmer', FarmerSchema);
