import mongoose from 'mongoose';

const NFTArbitrageSchema = new mongoose.Schema({
    sourceTemplate: { type: Number, required: true },
    targetTemplate: { type: Number, required: true },
    buyPrice: { type: Number, required: true },
    blendCost: { type: Number, required: true },  // Cost for one shine step
    totalBlendCost: { type: Number, required: true },  // Total cost through all shine stages
    sellPrice: { type: Number, required: true },
    profit: { type: Number, required: true },
    flaggedAt: { type: Date, default: Date.now }
});

const NFTArbitrage = mongoose.model('NFTArbitrage', NFTArbitrageSchema);
export default NFTArbitrage;
