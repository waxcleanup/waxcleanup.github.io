// ~/backend/models/BurnDailyUsage.js
import mongoose from 'mongoose';

const BurnDailyUsageSchema = new mongoose.Schema(
  {
    day: { type: String, required: true, index: true }, // UTC "YYYY-MM-DD"
    scope: { type: String, required: true, enum: ['user', 'incinerator'], index: true },
    key: { type: String, required: true, index: true }, // username OR incineratorId
    count: { type: Number, default: 0 },
  },
  { timestamps: true }
);

BurnDailyUsageSchema.index({ day: 1, scope: 1, key: 1 }, { unique: true });

export default mongoose.model('BurnDailyUsage', BurnDailyUsageSchema);
