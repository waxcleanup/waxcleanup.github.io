import mongoose from 'mongoose';

const InventorySchema = new mongoose.Schema({
  user: { type: String, required: true, unique: true },
  items: [
    {
      itemName: { type: String, required: true },
      quantity: { type: Number, required: true }
    }
  ]
});

const Inventory = mongoose.model('Inventory', InventorySchema);
export default Inventory;
