import mongoose from 'mongoose';

const PlotSchema = new mongoose.Schema({
  owner: { type: String, required: true },
  plotId: { type: Number, required: true },
  status: { type: String, required: true },
  // Add other fields as needed
});

const Plot = mongoose.model('Plot', PlotSchema);
export default Plot;
