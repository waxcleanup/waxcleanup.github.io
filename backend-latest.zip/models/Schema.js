import mongoose from 'mongoose';

const schemaSchema = new mongoose.Schema({
  collection_name: String,
  schema_name: String,
  templates: [{ type: mongoose.Schema.Types.ObjectId, ref: 'NFTTemplate' }],
  lastSyncedKey: { type: String, default: '' }, // Track last synced key
  updatedAt: { type: Date, default: Date.now } // Remove expiration
});

export default mongoose.model('Schema', schemaSchema);
