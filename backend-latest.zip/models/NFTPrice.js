import mongoose from 'mongoose';

const NFTPriceSchema = new mongoose.Schema({
    template_id: { type: Number, required: true, unique: true },
    rarity: { type: String, required: true, default: 'Unknown' }, // Added rarity tracking
    listings: [
        {
            price: { type: Number, required: true },
            seller: { type: String, required: true }
        }
    ],
    updatedAt: { type: Date, default: Date.now }
});

const NFTPrice = mongoose.model('NFTPrice', NFTPriceSchema);
export default NFTPrice;
