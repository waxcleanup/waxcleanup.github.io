// models/Wallet.js

import mongoose from 'mongoose';

const walletSchema = new mongoose.Schema({
  accountName: { type: String, required: true, unique: true }, // WAX blockchain account name
  publicKey: { type: String, required: true },                 // WAX public key
  encryptedPrivateKey: { type: String, required: true },       // Encrypted private key for secure storage
  passwordHash: { type: String, required: true },              // Hashed password (previously password)
  createdAt: { type: Date, default: Date.now },                // Date when the account was created
  preferences: {                                               // Optional user settings or game preferences
    notificationsEnabled: { type: Boolean, default: true }
  }
});

const WalletModel = mongoose.model('Wallet', walletSchema);
export default WalletModel;
