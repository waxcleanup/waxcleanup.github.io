// models/Collection.js
import mongoose from 'mongoose';

const collectionSchema = new mongoose.Schema({
  collection_name: { type: String, unique: true, required: true },
  schemas: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Schema' }],
  lastSyncedKey: { type: String, default: '' },
  updatedAt: { type: Date, default: Date.now }
});

export default mongoose.model('Collection', collectionSchema);
