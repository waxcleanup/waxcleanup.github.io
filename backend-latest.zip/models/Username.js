import mongoose from 'mongoose';

const { Schema } = mongoose;

// Define the schema for storing usernames
const usernameSchema = new Schema({
  accountName: {
    type: String,
    required: true,
    unique: true,
  },
  username: {
    type: String,
    required: false, // Allow blank fields for existing farmers without usernames
  },
});

// Create and export the Username model
const Username = mongoose.model('Username', usernameSchema);

export default Username;
