// models/Pool.js
import mongoose from 'mongoose';

const currSlotSchema = new mongoose.Schema({
  sqrtPriceX64: { type: String, required: true },
  tick: { type: Number, required: true },
  lastObservationTimestamp: { type: Number, required: true },
  currentObservationNum: { type: Number, required: true },
  maxObservationNum: { type: Number, required: true }
}, { _id: false });

const poolSchema = new mongoose.Schema({
  poolId: {
    type: Number,
    required: true,
    unique: true  // Alcor's numeric pool ID
  },
  active: {
    type: Boolean,
    required: true
  },
  tokenASymbol: {
    type: String,
    required: true  // e.g. "WAX"
  },
  tokenAContract: {
    type: String,
    required: true  // e.g. "eosio.token"
  },
  tokenBSymbol: {
    type: String,
    required: true  // e.g. "CEE"
  },
  tokenBContract: {
    type: String,
    required: true  // e.g. "token.brpg"
  },
  fee: {
    type: Number,
    required: true  // fee in basis points
  },
  feeProtocol: {
    type: Number,
    default: 0      // protocol fee in basis points
  },
  tickSpacing: {
    type: Number,
    default: null
  },
  maxLiquidityPerTick: {
    type: String,
    default: null
  },
  currSlot: {
    type: currSlotSchema,
    required: true
  },
  feeGrowthGlobalAX64: {
    type: String,
    required: true
  },
  feeGrowthGlobalBX64: {
    type: String,
    required: true
  },
  protocolFeeA: {
    type: String,
    required: true
  },
  protocolFeeB: {
    type: String,
    required: true
  },
  liquidity: {
    type: String,
    required: true
  },
  createdAtBlockNumber: {
    type: Number,
    required: true
  },
  createdAtBlockTimestamp: {
    type: Number,
    required: true  // seconds since epoch
  },
  createdAtTxnId: {
    type: String,
    required: true  // transaction ID of createpool action
  }
}, { collection: 'pools' });

export default mongoose.model('Pool', poolSchema);
