// jobs/backfillPoolCreationTimestamps.js
import mongoose from 'mongoose';
import dotenv from 'dotenv';
import axios from 'axios';
import Pool from '../models/Pool.js';

dotenv.config();
(async () => {
  try {
    await mongoose.connect(process.env.MONGODB_URI);
    console.log('🔁 Starting backfill of pool creation data…');

    // 1) fetch full list of pools (numeric IDs + on-chain fields)
    const { data: pools } = await axios.get(
      'https://alcor.exchange/api/v2/swap/pools?chain=wax',
      { timeout: 60000 }
    );

    // 2) for each pool, fetch its on-chain creation action
    const EOS_HISTORY = 'https://wax.eosusa.io/v2/history/get_actions';
    for (const p of pools) {
      const {
        id: poolId,
        active,
        tokenA,
        tokenB,
        fee,
        feeProtocol,
        tickSpacing,
        maxLiquidityPerTick,
        currSlot,
        feeGrowthGlobalAX64,
        feeGrowthGlobalBX64,
        protocolFeeA,
        protocolFeeB,
        liquidity
      } = p;

      // backfill creation metadata if missing
      let createdAtBlockNumber;
      let createdAtBlockTimestamp;
      let createdAtTxnId;
      try {
        const resp = await axios.get(EOS_HISTORY, {
          params: {
            account: 'swap.alcor',
            filter:  'swap.alcor::createpool',
            sort:    'asc',
            limit:   1000
          }
        });
        const action = resp.data.actions?.find(a =>
          a.act.name === 'createpool' &&
          a.act.data.tokenA.contract === tokenA.contract &&
          a.act.data.tokenB.contract === tokenB.contract
        );
        if (action) {
          createdAtBlockNumber   = action.block_num;
          createdAtBlockTimestamp= Math.floor(new Date(action.timestamp).getTime()/1000);
          createdAtTxnId         = action.trx_id;
        }
      } catch (err) {
        console.warn(`⚠️ History lookup failed for pool ${poolId}:`, err.message);
      }

      // Prepare document
      const doc = {
        poolId,
        active: Boolean(active),
        tokenASymbol: tokenA.symbol,
        tokenAContract: tokenA.contract,
        tokenBSymbol: tokenB.symbol,
        tokenBContract: tokenB.contract,
        fee,
        feeProtocol,
        tickSpacing,
        maxLiquidityPerTick,
        currSlot,
        feeGrowthGlobalAX64,
        feeGrowthGlobalBX64,
        protocolFeeA,
        protocolFeeB,
        liquidity: String(liquidity),
        ...(createdAtTxnId ? {
          createdAtBlockNumber,
          createdAtBlockTimestamp,
          createdAtTxnId
        } : {})
      };

      // 3) Upsert into Mongo
      await Pool.updateOne({ poolId }, { $set: doc }, { upsert: true });
      console.log(`✅ Upserted pool ${poolId}`);
    }

    console.log('🎉 Backfill complete');
  } catch (err) {
    console.error('❌ Error in backfill job:', err);
  } finally {
    await mongoose.connection.close();
  }
})();
