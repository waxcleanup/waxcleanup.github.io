// jobs/backfillTokenCreationTimestamps.js
import mongoose from 'mongoose';
import dotenv from 'dotenv';
import axios from 'axios';
import { fileURLToPath } from 'url';
import path from 'path';

// ─── Setup __dirname & load .env ──────────────────────────────────────────────
const __filename = fileURLToPath(import.meta.url);
const __dirname  = path.dirname(__filename);
dotenv.config({ path: path.join(__dirname, '../.env') });

// ─── Connect to MongoDB ──────────────────────────────────────────────────────
mongoose.connect(process.env.MONGODB_URI)
  .then(() => console.log('✅ Connected to MongoDB'))
  .catch(err => {
    console.error('❌ MongoDB connection error:', err);
    process.exit(1);
  });

// ─── Define Token model ──────────────────────────────────────────────────────
const tokenSchema = new mongoose.Schema({
  id:                     String,  // alcor ID, e.g. "cinder-cleanuptoken"
  contract:               String,  // token contract account
  symbol:                 String,  // token symbol
  createdAtBlockNumber:   Number,
  createdAtBlockTimestamp:Number
}, { collection: 'tokens' });

const Token = mongoose.model('Token', tokenSchema);

// ─── Constants ────────────────────────────────────────────────────────────────
const ALCOR_TOKENS_V2 = 'https://alcor.exchange/api/v2/tokens';
const EOS_HISTORY     = 'https://wax.eosusa.io/v2/history/get_actions';

// ─── Main Backfill ────────────────────────────────────────────────────────────
(async () => {
  console.log('🔁 Starting backfill of token creation timestamps…');

  try {
    // 1) fetch all tokens
    const { data: tokens } = await axios.get(ALCOR_TOKENS_V2);
    let updated = 0;

    for (const t of tokens) {
      const alcorId  = t.id;        // e.g. "cinder-cleanuptoken"
      const contract = t.contract;  // e.g. "cleanuptoken"
      const symbol   = t.symbol;    // e.g. "CINDER"

      // 2) query the very first `create` action on that contract
      let firstAction;
      try {
        const resp = await axios.get(EOS_HISTORY, {
          params: {
            account: contract,
            filter:  `${contract}::create`,
            limit:   1,
            sort:    'asc'
          }
        });
        firstAction = resp.data.actions?.[0];
      } catch (err) {
        console.warn(`⚠️  history lookup failed for ${contract}:`, err.message);
        continue;
      }

      if (!firstAction) {
        console.log(`– no “create” action found for ${alcorId}`);
        continue;
      }

      const blockNumber = firstAction.block_num;
      const blockTs     = Math.floor(new Date(firstAction.timestamp).getTime()/1000);

      // 3) upsert into Mongo
      await Token.updateOne(
        { id: alcorId },
        {
          $set: {
            id:                     alcorId,
            contract,
            symbol,
            createdAtBlockNumber:   blockNumber,
            createdAtBlockTimestamp:blockTs
          }
        },
        { upsert: true }
      );

      console.log(`✅ ${alcorId} → block ${blockNumber} @ ${blockTs}`);
      updated++;
    }

    console.log(`🎉 Finished; updated ${updated} tokens.`);
  } catch (err) {
    console.error('❌ Error in backfill job:', err);
  } finally {
    mongoose.connection.close();
  }
})();
