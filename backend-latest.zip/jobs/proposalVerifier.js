// backend/jobs/proposalVerifier.js
import cron from 'node-cron';
import dotenv from 'dotenv';
import { Api, JsonRpc } from 'eosjs';
import { JsSignatureProvider } from 'eosjs/dist/eosjs-jssig.js';
import fetch from 'node-fetch';
import { getTableRows } from '../services/blockchainService.js';
import path from 'path';
import { fileURLToPath } from 'url';

// Load environment variables
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
dotenv.config({ path: path.join(__dirname, '..', '.env') });

// Validate required env vars
if (!process.env.MAINNET_PRIVATE_KEY_CLEANUPTOKEN || !process.env.WAX_MAINNET_API) {
  console.error("❌ Missing MAINNET_PRIVATE_KEY_CLEANUPTOKEN or WAX_MAINNET_API in .env");
  process.exit(1);
}

// Setup EOSJS
const rpc = new JsonRpc(process.env.WAX_MAINNET_API, { fetch });
const cleanuptokenSignatureProvider = new JsSignatureProvider([process.env.MAINNET_PRIVATE_KEY_CLEANUPTOKEN]);
const cleanuptokenApi = new Api({
  rpc,
  signatureProvider: cleanuptokenSignatureProvider,
  textDecoder: new TextDecoder(),
  textEncoder: new TextEncoder(),
});

// Constants
const CHECK_INTERVAL = '*/2 * * * *'; // Every 2 minutes
const CONTRACT_ACCOUNT = 'cleanupcentr';
const CLEANUPTOKEN_ACCOUNT = 'cleanuptoken';
const VOTING_PERIOD_MS = 24 * 60 * 60 * 1000; // 24 hours

// Main cron job task
const checkAndProcessProposals = async () => {
  console.log("🔁 Checking proposals...");

  try {
    const proposals = await getTableRows(CONTRACT_ACCOUNT, CONTRACT_ACCOUNT, 'proposals', 100);

    const pendingProposals = proposals.filter(p => p.status === 'pending');
    const verifiedProposals = proposals.filter(p =>
      p.status === 'verified' && isVotingPeriodComplete(p)
    );

    // ✅ Verify proposals
    for (const proposal of pendingProposals) {
      try {
        await cleanuptokenApi.transact({
          actions: [{
            account: CONTRACT_ACCOUNT,
            name: 'verifyprop',
            authorization: [{ actor: CLEANUPTOKEN_ACCOUNT, permission: 'active' }],
            data: { prop_id: proposal.prop_id },
          }],
        }, { blocksBehind: 3, expireSeconds: 30 });

        console.log(`✅ Verified proposal: ${proposal.prop_id}`);
      } catch (err) {
        console.error(`❌ Failed to verify proposal ${proposal.prop_id}:`, err.message);
      }
    }

    // ✅ Execute proposals
    for (const proposal of verifiedProposals) {
      try {
        await cleanuptokenApi.transact({
          actions: [{
            account: CONTRACT_ACCOUNT,
            name: 'execprop',
            authorization: [{ actor: CLEANUPTOKEN_ACCOUNT, permission: 'active' }],
            data: { prop_id: proposal.prop_id },
          }],
        }, { blocksBehind: 3, expireSeconds: 30 });

        console.log(`🚀 Executed proposal: ${proposal.prop_id}`);
      } catch (err) {
        console.error(`❌ Failed to execute proposal ${proposal.prop_id}:`, err.message);
      }
    }

  } catch (error) {
    console.error('🔥 Error in proposal verification job:', error.message || error);
  }
};

// Utility: Check voting period
const isVotingPeriodComplete = (proposal) => {
  if (!proposal.created_at) return false;
  const timeElapsed = Date.now() - new Date(proposal.created_at).getTime();
  return timeElapsed >= VOTING_PERIOD_MS;
};

// Schedule job
cron.schedule(CHECK_INTERVAL, checkAndProcessProposals);
console.log('🕒 Proposal Verifier & Executor cron job scheduled.');
