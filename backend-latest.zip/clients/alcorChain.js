// backend/clients/alcorChain.js
import { JsonRpc } from 'eosjs'
import fetch from 'node-fetch'

// pick your node endpoint
const RPC_URL = process.env.EOS_RPC_NODE_URL || 'https://wax.greymass.com'
const rpc     = new JsonRpc(RPC_URL, { fetch })

/**
 * Fetch the reserves for a given Alcor pool
 */
export async function fetchPoolReserves(poolId) {
  const resp = await rpc.get_table_rows({
    json:        true,
    code:        'swap.alcor',
    scope:       'swap.alcor',
    table:       'pools',
    lower_bound: poolId,
    limit:       1
  })
  const row = resp.rows[0]
  if (!row || Number(row.id) !== Number(poolId)) {
    throw new Error(`Pool ${poolId} not found on chain`)
  }
  return {
    asset0: row.tokenA.quantity.split(' ')[0],
    asset1: row.tokenB.quantity.split(' ')[0],
  }
}
