// utils/errorHandler.js

export const handleError = (error, res, message = 'An error occurred') => {
  console.error(`${message}:`, error);

  if (res && typeof res.status === 'function') {
    res.status(500).json({
      message,
      error: error.message || 'Unknown error',
      details: error.stack || error.toString(),
    });
  } else {
    console.error("Response object is invalid or status is not a function.");
  }
};
