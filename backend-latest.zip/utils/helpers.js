import axios from 'axios';
import { rpc } from './eosApi.js';

export async function getAssetMetadata(assetId) {
  try {
    const endpoint = process.env.NODE_ENV === 'production'
      ? process.env.ATOMICASSETS_MAINNET_API_ENDPOINT
      : process.env.ATOMICASSETS_API_ENDPOINT;
    console.log(`Fetching metadata for asset ID ${assetId} from ${endpoint}`);
    const response = await axios.get(`${endpoint}/atomicassets/v1/assets/${assetId}`);
    if (response.data.success) {
      console.log(`Metadata retrieved for asset ID ${assetId}`);
      return response.data.data;
    } else {
      console.error(`Failed to fetch metadata for asset ID ${assetId}: ${response.data.message || 'Unknown error'}`);
    }
  } catch (error) {
    console.error(`Error fetching metadata for asset ID ${assetId}:`, error.message);
  }
  return null;
}

export async function getIncinerator(incineratorId) {
  try {
    const response = await rpc.get_table_rows({
      json: true,
      code: process.env.CLEANUPCENTR_ACCOUNT || 'cleanupcentr',
      scope: process.env.CLEANUPCENTR_ACCOUNT || 'cleanupcentr',
      table: 'incinerators',
      lower_bound: incineratorId,
      upper_bound: incineratorId,
      limit: 1,
    });
    if (response.rows.length > 0) {
      console.log(`Incinerator details retrieved:`, response.rows[0]);
      return response.rows[0];
    } else {
      console.error(`Incinerator ${incineratorId} not found.`);
      return null;
    }
  } catch (error) {
    console.error(`Error fetching incinerator ${incineratorId}:`, error.message);
    return null;
  }
}

export async function getProposal(templateId) {
  try {
    let lower_bound = 0;
    const limit = 1000;
    let hasMore = true;
    while (hasMore) {
      const response = await rpc.get_table_rows({
        json: true,
        code: process.env.CLEANUPCENTR_ACCOUNT || 'cleanupcentr',
        scope: process.env.CLEANUPCENTR_ACCOUNT || 'cleanupcentr',
        table: 'proposals',
        lower_bound,
        limit,
      });
      if (response.rows.length > 0) {
        const proposal = response.rows.find(row => row.template_id === templateId && row.status === 'approved');
        if (proposal) {
          console.log(`Approved proposal retrieved for template ID ${templateId}:`, proposal);
          return proposal;
        }
        lower_bound = response.next_key;
        hasMore = response.more;
      } else {
        hasMore = false;
      }
    }
    console.error(`Approved proposal for template ID ${templateId} not found.`);
    return null;
  } catch (error) {
    console.error(`Error fetching proposal for template ID ${templateId}:`, error.message);
    return null;
  }
}

export function validateAsset(asset, expectedSymbol, expectedPrecision) {
  const [amount, symbol] = asset.split(" ");
  const decimalPlaces = amount.split(".")[1]?.length || 0;
  if (symbol !== expectedSymbol || decimalPlaces !== expectedPrecision) {
    throw new Error(`Asset precision mismatch: expected ${expectedPrecision} decimal places for ${expectedSymbol}, got "${asset}"`);
  }
}
