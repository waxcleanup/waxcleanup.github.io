// backend/utils/config.js
// Centralized configuration for CleanupCentr transfer processing

import dotenv from 'dotenv';
dotenv.config();

export default {
  // Contract account names
  cleanupContract: process.env.CLEANUPCENTR_ACCOUNT || 'cleanupcentr',
  atomicAssetsContract: process.env.ATOMICASSETS_CONTRACT || 'atomicassets',
  cleanuptokenContract: process.env.CLEANUPTOKEN_CONTRACT || 'cleanuptoken',

  // Memo prefixes
  incinerateMemo: 'Incinerate NFT',
  stakeMemo: 'Stake NFT',
  loadFuelMemo: 'loadfuel',
  loadEnergyMemo: 'loadenergy',
  repairMemo: 'repairincin',
  proposalMemo: 'proposal',

  // Polling interval (ms) for monitor
  pollIntervalMs: parseInt(process.env.POLL_INTERVAL_MS, 10) || 500
};
