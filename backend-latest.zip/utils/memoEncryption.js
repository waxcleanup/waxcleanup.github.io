// ~/backend/utils/memoEncryption.js

import CryptoJS from 'crypto-js';

/**
 * Decrypt a memo encrypted using AES-256-CBC with IV.
 *
 * Expected encryptedMemo format:
 *   ENC:<ivBase64>:<cipherBase64>
 *
 * The frontend will:
 *   1) JSON.stringify(payload)
 *   2) Generate random IV
 *   3) Encrypt via AES-256-CBC
 *   4) Output: `ENC:${ivBase64}:${cipherBase64}`
 */
export const decryptMemo = (encryptedMemo) => {
  if (!encryptedMemo || typeof encryptedMemo !== 'string') {
    throw new Error('Invalid encrypted memo');
  }

  if (!encryptedMemo.startsWith('ENC:')) {
    throw new Error('Memo is not encrypted with ENC: prefix');
  }

  const parts = encryptedMemo.split(':');
  if (parts.length !== 3) {
    throw new Error('Encrypted memo format must be ENC:iv:cipher');
  }

  const ivBase64 = parts[1];
  const cipherBase64 = parts[2];

  const key = process.env.ENCRYPTION_KEY;
  if (!key) {
    throw new Error('ENCRYPTION_KEY is not set');
  }

  // CryptoJS expects WordArray
  const iv = CryptoJS.enc.Base64.parse(ivBase64);
  const cipherText = CryptoJS.enc.Base64.parse(cipherBase64);

  const decrypted = CryptoJS.AES.decrypt(
    {
      ciphertext: cipherText,
      salt: '', // Not using salt mode
    },
    CryptoJS.enc.Utf8.parse(key),
    {
      iv,
      mode: CryptoJS.mode.CBC,
      padding: CryptoJS.pad.Pkcs7
    }
  );

  const jsonStr = decrypted.toString(CryptoJS.enc.Utf8);

  try {
    return JSON.parse(jsonStr);
  } catch (e) {
    throw new Error('Decrypted memo is not valid JSON');
  }
};
