export function utcDayKey() {
  return new Date().toISOString().slice(0, 10);
}

export function nextUtcMidnightIso() {
  const now = new Date();
  const next = new Date(Date.UTC(
    now.getUTCFullYear(),
    now.getUTCMonth(),
    now.getUTCDate() + 1, 0, 0, 0, 0
  ));
  return next.toISOString();
}
