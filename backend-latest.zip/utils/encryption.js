import CryptoJS from 'crypto-js';

export const decryptPrivateKey = (encryptedPrivateKey) => {
  const decryptionKey = process.env.ENCRYPTION_KEY; // Use ENCRYPTION_KEY instead of PRIVATE_KEY_ENCRYPTION_KEY
  console.log('Decryption Key:', decryptionKey); // Log the key to ensure it is being loaded
  if (!decryptionKey) {
    throw new Error('Private key encryption key is not set');
  }
  const bytes = CryptoJS.AES.decrypt(encryptedPrivateKey, decryptionKey);
  return bytes.toString(CryptoJS.enc.Utf8);
};

