import { Api, JsonRpc } from 'eosjs';
import { JsSignatureProvider } from 'eosjs/dist/eosjs-jssig.js';
import { TextDecoder, TextEncoder } from 'util';
import fetch from 'node-fetch';
import * as dotenv from 'dotenv';

dotenv.config({ path: '/home/ubuntu/backend/.env' });

// Setup EOSIO RPC using the testnet API as default
const rpc = new JsonRpc(process.env.WAX_MAINNET_API || process.env.WAX_TESTNET_API, { fetch });

// Signer for cleanupcentr contract
const cleanupKey = process.env.PRIVATE_KEY;
const cleanupProvider = new JsSignatureProvider([cleanupKey]);
const api = new Api({
  rpc,
  signatureProvider: cleanupProvider,
  textDecoder: new TextDecoder(),
  textEncoder: new TextEncoder()
});

// Signer for rhythmfarmer contract
const rhythmKey = process.env.RHYTHMFARMER_PRIVATE_KEY;
const rhythmProvider = new JsSignatureProvider([rhythmKey]);
const rhythmApi = new Api({
  rpc,
  signatureProvider: rhythmProvider,
  textDecoder: new TextDecoder(),
  textEncoder: new TextEncoder()
});

export { rpc, api, rhythmApi };
