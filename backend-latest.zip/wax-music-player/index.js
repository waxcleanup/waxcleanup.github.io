// ~/backend/wax-music-player/index.js
import dotenv from "dotenv";
dotenv.config();

import express from "express";
import cors from "cors";
import bodyParser from "body-parser";
import musicRoutes from "./routes/musicRoutes.js";
import ipfsRoutes from "./routes/ipfsRoutes.js";
import musicOnlyRoutes from "./routes/musicOnlyRoutes.js";

const app = express();
const PORT = process.env.MUSIC_PORT || 4002;

// ✅ Allow CORS from local dev, LAN IP, and public site
const allowedOrigins = [
  'http://localhost:3000',
  'http://192.168.1.166:3000',
  'https://waxcleanup.github.io',
];

app.use(cors({
  origin: function (origin, callback) {
    if (!origin || allowedOrigins.includes(origin)) {
      callback(null, true);
    } else {
      callback(new Error(`CORS blocked: ${origin}`));
    }
  },
  methods: ['GET', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Range'],
  exposedHeaders: ['Content-Length', 'Content-Range']
}));

app.use(bodyParser.json());
app.use("/waxmusic", musicRoutes);
app.use("/ipfs", ipfsRoutes);
app.use("/waxmusic/audio", musicOnlyRoutes);

app.listen(PORT, () => {
  console.log(`🎵  WAX Music Player API running on port ${PORT}`);
});
