// ~/backend/wax-music-player/musicCollectionScanner.js

import fetch from 'node-fetch';
import sqlite3 from 'sqlite3';
import { open } from 'sqlite';

const DB_PATH      = '/mnt/musicplayer/music.db';
const TEMPLATE_API = 'https://wax.api.atomicassets.io/atomicassets/v1/templates?collection_name=';

async function openDb() {
  return open({ filename: DB_PATH, driver: sqlite3.Database });
}

function isMusicTemplate(imm) {
  return typeof imm.audio === 'string' || typeof imm.video === 'string';
}

function getMediaIpfsHash(imm) {
  if (typeof imm.audio === 'string') return imm.audio;
  if (typeof imm.video === 'string') return imm.video;
  return '';
}

async function createTables(db) {
  await db.exec(`
    CREATE TABLE IF NOT EXISTS music_collections (
      collection_name TEXT PRIMARY KEY,
      active INTEGER DEFAULT 1,
      note TEXT,
      last_scanned_at INTEGER
    );

    CREATE TABLE IF NOT EXISTS music_nfts (
      id INTEGER PRIMARY KEY,
      template_id TEXT UNIQUE,
      collection_name TEXT,
      author TEXT,
      song_name TEXT,
      media_type TEXT,
      ipfs_hash TEXT,
      img TEXT,
      description TEXT,
      added_at INTEGER DEFAULT (strftime('%s','now')),
      updated_at INTEGER DEFAULT (strftime('%s','now'))
    );
  `);
}

async function getActiveCollections(db) {
  return db.all(`SELECT collection_name FROM music_collections WHERE active = 1`);
}

async function scanCollection(db, collectionName) {
  let page = 1;
  let matched = 0;
  const now = Math.floor(Date.now() / 1000);

  while (true) {
    console.log(`→ [${collectionName}] fetching templates page ${page}…`);
    const res = await fetch(`${TEMPLATE_API}${collectionName}&limit=100&page=${page}`);
    const json = await res.json();
    const templates = json.data || [];
    if (templates.length === 0) break;

    for (const tmpl of templates) {
      const imm = tmpl.immutable_data || {};
      if (!isMusicTemplate(imm)) continue;

      const templateId  = tmpl.template_id;
      const author      = tmpl.collection?.author || '';
      const songName    = imm.name || imm.title || 'Untitled';
      const mediaType   = typeof imm.audio === 'string' ? 'audio' : 'video';
      const ipfsHash    = getMediaIpfsHash(imm);
      const img         = imm.img || imm.image || '';
      const description = imm.description || '';

      if (!ipfsHash) continue;

      await db.run(
        `INSERT INTO music_nfts (
           template_id, collection_name, author, song_name,
           media_type, ipfs_hash, img, description, added_at, updated_at
         ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
         ON CONFLICT(template_id) DO UPDATE SET
           author=excluded.author,
           song_name=excluded.song_name,
           media_type=excluded.media_type,
           ipfs_hash=excluded.ipfs_hash,
           img=excluded.img,
           description=excluded.description,
           updated_at=excluded.updated_at`,
        [
          templateId,
          collectionName,
          author,
          songName,
          mediaType,
          ipfsHash,
          img,
          description,
          now,
          now
        ]
      );
      matched++;
    }

    console.log(`[${collectionName}] Page ${page} → ${templates.length} templates, ${matched} matched`);
    page++;
  }

  await db.run(
    `UPDATE music_collections SET last_scanned_at = ? WHERE collection_name = ?`,
    [now, collectionName]
  );
}

async function main() {
  const db = await openDb();
  await createTables(db);

  // **Only** scan collections you’ve manually added to music_collections.
  const collections = await getActiveCollections(db);
  if (collections.length === 0) {
    console.warn('⚠️ No active collections found. Insert into music_collections table to scan.');
    await db.close();
    return;
  }

  for (const { collection_name } of collections) {
    console.log(`\n🎵 Scanning collection: ${collection_name}`);
    await scanCollection(db, collection_name);
  }

  console.log('\n✅ Done.');
  await db.close();
}

main().catch(console.error);
