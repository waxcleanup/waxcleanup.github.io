// ~/backend/wax-music-player/musicNFTCollector.js

import fetch from 'node-fetch';
import sqlite3 from 'sqlite3';
import { open } from 'sqlite';

// Base URL for fetching template data
const TEMPLATE_URL = 'https://wax.api.atomicassets.io/atomicassets/v1/templates?limit=100&page=';

// Opens or creates the SQLite database
async function openDb() {
  return open({ filename: '/mnt/musicplayer/music.db', driver: sqlite3.Database });
}

// Detects if a template's metadata has an explicit audio or video field
function isMusicTemplate(imm) {
  return typeof imm.audio === 'string' || typeof imm.video === 'string';
}

// Retrieves the IPFS hash from the correct media field
function getMediaIpfsHash(imm) {
  if (typeof imm.audio === 'string') return imm.audio;
  if (typeof imm.video === 'string') return imm.video;
  return '';
}

// Main collector function for templates
async function collectMusicNFTs() {
  const db = await openDb();

  // Reset the music_nfts table
  await db.exec(`
    DROP TABLE IF EXISTS music_nfts;
    CREATE TABLE music_nfts (
      id INTEGER PRIMARY KEY,
      template_id TEXT UNIQUE,
      collection_name TEXT,
      author TEXT,
      song_name TEXT,
      media_type TEXT,
      ipfs_hash TEXT,
      img TEXT,
      description TEXT,
      added_at INTEGER
    );
  `);

  let page = 1;
  let hasMore = true;
  let matchedCount = 0;

  while (hasMore) {
    console.log(`🔍 Scanning template page ${page}`);
    const response = await fetch(`${TEMPLATE_URL}${page}`);
    const { data: templates } = await response.json();
    if (!templates || templates.length === 0) break;

    for (const tmpl of templates) {
      const imm = tmpl.immutable_data || {};
      if (!isMusicTemplate(imm)) continue;
      matchedCount++;

      const templateId     = tmpl.template_id;
      const collectionName = tmpl.collection?.collection_name || tmpl.collection?.name || '';
      const author         = tmpl.collection?.author || '';
      const songName       = imm.name || imm.title || 'Untitled';
      const mediaType      = typeof imm.audio === 'string' ? 'audio' : 'video';
      const ipfsHash       = getMediaIpfsHash(imm);
      if (!ipfsHash) continue;
      const img            = imm.img || imm.image || '';
      const description    = imm.description || '';
      const addedAt        = Math.floor(Date.now() / 1000);

      await db.run(
        `INSERT OR IGNORE INTO music_nfts (
          template_id, collection_name, author, song_name,
          media_type, ipfs_hash, img, description, added_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
        [
          templateId,
          collectionName,
          author,
          songName,
          mediaType,
          ipfsHash,
          img,
          description,
          addedAt
        ]
      );
    }

    console.log(`✅ Page ${page} processed ${templates.length} templates (${matchedCount} matched so far)`);
    page++;
    hasMore = templates.length === 100;
  }

  console.log(`🎶 Finished collecting music templates.`);
  console.log(`📊 Total pages scanned: ${page - 1}`);
  console.log(`📊 Total audio/video templates matched: ${matchedCount}`);

  await db.close();
}

collectMusicNFTs().catch(err => console.error(err));
