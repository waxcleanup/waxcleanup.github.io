// ~/backend/wax-music-player/routes/musicOnlyRoutes.js

import express from 'express';
import sqlite3 from 'sqlite3';
import { open } from 'sqlite';

const router = express.Router();
const DB_PATH = '/mnt/musicplayer/music.db';

// sensible defaults + caps
const DEFAULT_LIMIT = 25;
const MAX_LIMIT     = 100;

async function openDatabase() {
  return open({ filename: DB_PATH, driver: sqlite3.Database });
}

// helper to parse & sanitize pagination params
function parsePagination(query) {
  let limit = parseInt(query.limit, 10);
  if (isNaN(limit) || limit < 1) limit = DEFAULT_LIMIT;
  if (limit > MAX_LIMIT) limit = MAX_LIMIT;

  let page = parseInt(query.page, 10);
  if (isNaN(page) || page < 1) page = 1;

  const offset = (page - 1) * limit;
  return { limit, offset, page };
}

// ── GET /waxmusic/audio/latest?limit=&page= ──
router.get('/latest', async (req, res) => {
  const { limit, offset, page } = parsePagination(req.query);

  try {
    const db = await openDatabase();
    const rows = await db.all(
      `
      SELECT template_id,
             collection_name AS collection,
             author,
             song_name      AS title,
             media_type,
             ipfs_hash,
             img,
             description,
             added_at
      FROM music_nfts
      WHERE media_type = 'audio'
      ORDER BY added_at DESC
      LIMIT ? OFFSET ?
      `,
      [limit, offset]
    );
    await db.close();

    res.json({
      meta: { page, limit, count: rows.length },
      data: rows
    });
  } catch (err) {
    console.error('[music-audio] /latest error:', err);
    res.status(500).json({ error: 'Failed to fetch audio NFTs' });
  }
});

// ── GET /waxmusic/audio/search?q=&limit=&page= ──
router.get('/search', async (req, res) => {
  const { q } = req.query;
  if (!q) return res.status(400).json({ error: 'Missing search query' });

  const { limit, offset, page } = parsePagination(req.query);
  const like = `%${q}%`;

  try {
    const db = await openDatabase();
    const rows = await db.all(
      `
      SELECT template_id,
             collection_name AS collection,
             author,
             song_name      AS title,
             media_type,
             ipfs_hash,
             img,
             description,
             added_at
      FROM music_nfts
      WHERE media_type = 'audio'
        AND (
          song_name       LIKE ?
          OR author       LIKE ?
          OR collection_name LIKE ?
        )
      ORDER BY added_at DESC
      LIMIT ? OFFSET ?
      `,
      [like, like, like, limit, offset]
    );
    await db.close();

    res.json({
      meta: { page, limit, count: rows.length, query: q },
      data: rows
    });
  } catch (err) {
    console.error('[music-audio] /search error:', err);
    res.status(500).json({ error: 'Search failed' });
  }
});

export default router;
