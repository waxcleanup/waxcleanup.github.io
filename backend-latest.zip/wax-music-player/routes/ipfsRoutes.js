// ~/backend/wax-music-player/routes/ipfsRoutes.js
import express from 'express';
import axios from 'axios';

const router = express.Router();

// Forward IPFS hash to your local IPFS daemon
router.get('/:hash', async (req, res) => {
  const { hash } = req.params;

  try {
    const response = await axios({
      method: 'get',
      url: `http://127.0.0.1:8080/ipfs/${hash}`, // Local IPFS gateway
      responseType: 'stream',
      timeout: 60000 // Timeout for local IPFS fetch
    });

    // Set response headers
    res.setHeader('Content-Type', response.headers['content-type']);

    // 🔒 Stream timeout safeguard (12 seconds)
    res.setTimeout(60000, () => {
      console.warn(`[ipfs timeout] hash=${hash} took too long, closing connection`);
      if (!res.headersSent) {
        res.status(504).send('Gateway Timeout');
      }
      res.end();
    });

    // Pipe the stream to the response
    response.data.pipe(res);
  } catch (err) {
    console.error('[ipfs proxy] error:', err.message);
    res.status(502).json({ error: 'Failed to fetch from local IPFS gateway' });
  }
});

export default router;
