// ~/backend/wax-music-player/routes/musicRoutes.js

import express from 'express';
import sqlite3 from 'sqlite3';
import { open } from 'sqlite';
import axios from 'axios';

const router = express.Router();
const DB_PATH = '/mnt/musicplayer/music.db';

// helper to open the DB
async function openDatabase() {
  return open({ filename: DB_PATH, driver: sqlite3.Database });
}

// ─── GET /waxmusic/templates?limit=20&offset=0 ───
router.get('/templates', async (req, res) => {
  const limit  = parseInt(req.query.limit, 10) || 20;
  const offset = parseInt(req.query.offset, 10) || 0;
  try {
    const db = await openDatabase();
    const rows = await db.all(
      `SELECT
         template_id,
         collection_name AS collection,
         author,
         song_name AS title,
         media_type,
         ipfs_hash,
         img,
         description,
         added_at
       FROM music_nfts
       ORDER BY added_at DESC
       LIMIT ? OFFSET ?`,
      [limit, offset]
    );
    await db.close();
    res.json({ data: rows, count: rows.length });
  } catch (err) {
    console.error('[music] /templates error:', err);
    res.status(500).json({ error: 'Failed to fetch templates' });
  }
});

// ─── GET /waxmusic/latest ───
router.get('/latest', async (req, res) => {
  try {
    const db = await openDatabase();
    const rows = await db.all(
      `SELECT
         template_id,
         collection_name AS collection,
         author,
         song_name AS title,
         media_type,
         ipfs_hash,
         img,
         description,
         added_at
       FROM music_nfts
       ORDER BY added_at DESC
       LIMIT 25`
    );
    await db.close();
    res.json({ data: rows });
  } catch (err) {
    console.error('[music] /latest error:', err);
    res.status(500).json({ error: 'Internal error' });
  }
});

// ─── GET /waxmusic/search?q=term ───
router.get('/search', async (req, res) => {
  const { q } = req.query;
  if (!q) return res.status(400).json({ error: 'Missing search query.' });

  try {
    const db = await openDatabase();
    const like = `%${q}%`;
    const rows = await db.all(
      `SELECT
         template_id,
         collection_name AS collection,
         author,
         song_name AS title,
         media_type,
         ipfs_hash,
         img,
         description,
         added_at
       FROM music_nfts
       WHERE
         song_name      LIKE ? OR
         author         LIKE ? OR
         collection_name LIKE ?
       ORDER BY added_at DESC
       LIMIT 25`,
      [like, like, like]
    );
    await db.close();
    res.json({ data: rows });
  } catch (err) {
    console.error('[music] /search error:', err);
    res.status(500).json({ error: 'Search failed' });
  }
});

// ─── GET /waxmusic/:template_id ───
router.get('/:template_id', async (req, res) => {
  const { template_id } = req.params;

  try {
    const db = await openDatabase();
    const row = await db.get(
      `SELECT
         template_id,
         collection_name AS collection,
         author,
         song_name AS title,
         media_type,
         ipfs_hash,
         img,
         description,
         added_at
       FROM music_nfts
       WHERE template_id = ?`,
      [template_id]
    );
    await db.close();

    if (!row) return res.status(404).json({ error: 'Not found' });
    res.json({ data: row });
  } catch (err) {
    console.error('[music] fetch by ID error:', err);
    res.status(500).json({ error: 'Failed to fetch template' });
  }
});

// ─── GET /waxmusic/stream/:ipfs_hash ───
router.get('/stream/:ipfs_hash', async (req, res) => {
  const { ipfs_hash } = req.params;

  // Use gateways that support direct content without redirect
  const gateways = [
    `https://gateway.pinata.cloud/ipfs/${ipfs_hash}`,
    `https://dweb.link/ipfs/${ipfs_hash}`,
    `https://cloudflare-ipfs.com/ipfs/${ipfs_hash}`,
    `https://ipfs.io/ipfs/${ipfs_hash}`
  ];

  for (const url of gateways) {
    try {
      const response = await axios({
        method: 'get',
        url,
        responseType: 'stream',
        timeout: 8000,
        headers: { Range: req.headers.range || '' }
      });

      const contentType = response.headers['content-type'] || 'application/octet-stream';
      res.setHeader('Content-Type', contentType);
      res.setHeader('X-IPFS-Content-Type', contentType);

      if (/^(audio|video|image)\//.test(contentType)) {
        response.data.pipe(res);
        return;
      }
      console.warn(`[stream] unsupported content-type ${contentType} from ${url}`);
    } catch (err) {
      console.warn(`[stream] ${url} failed: ${err.message}`);
    }
  }

  res.status(415).json({ error: 'No playable media at this hash' });
});

export default router;
