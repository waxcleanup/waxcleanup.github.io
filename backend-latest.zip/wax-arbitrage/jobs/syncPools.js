// ~/backend/wax-arbitrage/jobs/syncPools.js

import sqlite3 from 'sqlite3';
import { open } from 'sqlite';
import axios from 'axios';
import fs from 'fs';
import path from 'path';

const DB_PATH = '/mnt/gecko-data/arbitrage.db';
const TABLE_API = 'https://wax.greymass.com/v1/chain/get_table_rows';
const ALCOR_CONTRACT = 'swap.alcor';
const TACO_CONTRACT = 'swap.taco';

if (!fs.existsSync('/mnt/gecko-data')) fs.mkdirSync('/mnt/gecko-data', { recursive: true });

async function openDb() {
  const db = await open({ filename: DB_PATH, driver: sqlite3.Database });
  await db.exec(`
    CREATE TABLE IF NOT EXISTS pools (
      poolId    TEXT    PRIMARY KEY,
      dexKey    TEXT    NOT NULL,
      asset0Id  TEXT    NOT NULL,
      asset1Id  TEXT    NOT NULL,
      reserve0  REAL    NOT NULL,
      reserve1  REAL    NOT NULL,
      feeBps    INTEGER NOT NULL
    );
    CREATE INDEX IF NOT EXISTS idx_assets ON pools(asset0Id, asset1Id);
    CREATE INDEX IF NOT EXISTS idx_dex    ON pools(dexKey);
  `);
  return db;
}

function parseToken(quantity, contract) {
  if (!quantity || typeof quantity !== 'string') return { symbol: null, contract, decimals: 0 };
  const [amount, symbol] = quantity.split(' ');
  const decimals = amount.includes('.') ? amount.split('.')[1].length : 0;
  return { symbol, contract, decimals };
}

async function fetchTableRows(contract, table) {
  let rows = [], lower_bound = '', more = true;
  while (more) {
    const { data } = await axios.post(TABLE_API, {
      json: true,
      code: contract,
      scope: contract,
      table,
      limit: 1000,
      lower_bound,
    });
    rows.push(...(data.rows || []));
    more = data.more;
    lower_bound = data.next_key;
  }
  return rows;
}

async function syncAlcorPools(db) {
  const pools = await fetchTableRows(ALCOR_CONTRACT, 'pools');
  console.log(`[arbitrage] Found ${pools.length} Alcor pools`);

  for (const pool of pools) {
    const tokenA = parseToken(pool.tokenA?.quantity, pool.tokenA?.contract);
    const tokenB = parseToken(pool.tokenB?.quantity, pool.tokenB?.contract);
    if (!tokenA.symbol || !tokenB.symbol) continue;

    const asset0Id = `${tokenA.symbol}@${tokenA.contract}`;
    const asset1Id = `${tokenB.symbol}@${tokenB.contract}`;
    const feeBps = Math.floor(pool.fee / 100);
    const reserve0 = parseFloat(pool.tokenA?.quantity?.split(' ')[0]) || 0;
    const reserve1 = parseFloat(pool.tokenB?.quantity?.split(' ')[0]) || 0;

    await db.run(
      `REPLACE INTO pools (poolId, dexKey, asset0Id, asset1Id, reserve0, reserve1, feeBps)
       VALUES (?, ?, ?, ?, ?, ?, ?)`,
      [pool.id, ALCOR_CONTRACT, asset0Id, asset1Id, reserve0, reserve1, feeBps]
    );
  }

  console.log(`[arbitrage] Synced ${pools.length} Alcor pools`);
}

async function syncTacoPairs(db) {
  const pairs = await fetchTableRows(TACO_CONTRACT, 'pairs');
  console.log(`[arbitrage] Found ${pairs.length} Taco pairs`);

  for (const pair of pairs) {
    const tokenA = parseToken(pair.pool1?.quantity, pair.pool1?.contract);
    const tokenB = parseToken(pair.pool2?.quantity, pair.pool2?.contract);
    if (!tokenA.symbol || !tokenB.symbol) continue;

    const asset0Id = `${tokenA.symbol}@${tokenA.contract}`;
    const asset1Id = `${tokenB.symbol}@${tokenB.contract}`;
    const feeBps = 30; // TacoSwap default: 0.3%
    const reserve0 = parseFloat(pair.pool1?.quantity?.split(' ')[0]) || 0;
    const reserve1 = parseFloat(pair.pool2?.quantity?.split(' ')[0]) || 0;

    await db.run(
      `REPLACE INTO pools (poolId, dexKey, asset0Id, asset1Id, reserve0, reserve1, feeBps)
       VALUES (?, ?, ?, ?, ?, ?, ?)`,
      [pair.id, TACO_CONTRACT, asset0Id, asset1Id, reserve0, reserve1, feeBps]
    );
  }

  console.log(`[arbitrage] Synced ${pairs.length} Taco pairs`);
}

async function syncPools() {
  const db = await openDb();
  await syncAlcorPools(db);
  await syncTacoPairs(db);
  await db.close();
}

syncPools().catch(console.error);
