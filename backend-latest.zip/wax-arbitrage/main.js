// ~/backend/wax-arbitrage/main.js

import sqlite3 from 'sqlite3';
import { open } from 'sqlite';

const DB_PATH = '/mnt/gecko-data/arbitrage.db';
const SCAN_INTERVAL_MS = 60 * 1000;
const TEST_AMOUNT = 1;
const MIN_OUTPUT = 0.000001;
const MIN_RESERVE = 0.01;

function parseSymbol(assetId) {
  const [symbol, contract] = assetId.split('@');
  return { symbol, contract };
}

async function openDb() {
  return await open({ filename: DB_PATH, driver: sqlite3.Database });
}

async function fetchPrices(db, dexKey) {
  console.log(`[arbitrage] Fetching ${dexKey} prices...`);

  const rows = await db.all(`
    SELECT asset0Id, asset1Id, reserve0, reserve1, feeBps
    FROM pools WHERE dexKey = ?
  `, [dexKey]);

  const prices = {};

  for (const { asset0Id, asset1Id, reserve0, reserve1, feeBps } of rows) {
    if (reserve0 <= MIN_RESERVE || reserve1 <= MIN_RESERVE) continue;

    const key = `${asset0Id}/${asset1Id}`;
    const reverseKey = `${asset1Id}/${asset0Id}`;

    prices[key] = {
      asset0Id,
      asset1Id,
      reserve0,
      reserve1,
      fee: feeBps / 10000
    };

    prices[reverseKey] = {
      asset0Id: asset1Id,
      asset1Id: asset0Id,
      reserve0: reserve1,
      reserve1: reserve0,
      fee: feeBps / 10000
    };
  }

  return prices;
}

function simulateSwap(inputAmount, reserveIn, reserveOut, fee) {
  const amountInWithFee = inputAmount * (1 - fee);
  const numerator = amountInWithFee * reserveOut;
  const denominator = reserveIn + amountInWithFee;
  return numerator / denominator;
}

function compareAndLog(alcorPools, tacoPools) {
  console.log('[arbitrage] Scanning for arbitrage opportunities...\n');

  const allPairs = new Set([...Object.keys(alcorPools), ...Object.keys(tacoPools)]);

  for (const pair of allPairs) {
    const alcor = alcorPools[pair];
    const taco = tacoPools[pair];
    if (!alcor || !taco) continue;

    // Try Alcor ➜ Taco
    const alcorOut = simulateSwap(TEST_AMOUNT, alcor.reserve0, alcor.reserve1, alcor.fee);
    const tacoBack = simulateSwap(alcorOut, taco.reserve1, taco.reserve0, taco.fee);
    const gain1 = tacoBack - TEST_AMOUNT;
    const spread1 = (gain1 / TEST_AMOUNT) * 100;

    console.log(`🧪 ALCOR ➜ TACO: ${pair}`);
    console.log(`   Alcor ➜ ${alcorOut}, Taco ➜ ${tacoBack}, Gain ➜ ${gain1}, Spread ➜ ${spread1.toFixed(2)}%`);
    if (alcorOut > MIN_OUTPUT && tacoBack > MIN_OUTPUT) {
      if (spread1 > 0.5) {
        console.log(`🪙 ${alcor.asset0Id}/${alcor.asset1Id}`);
        console.log(`   🔵 Alcor out: ${alcorOut}`);
        console.log(`   🟡 Taco back: ${tacoBack}`);
        console.log(`   📊 Net gain: ${spread1.toFixed(2)}%`);
        console.log(`   💰 Opportunity: Buy on Alcor → Sell on Taco [${spread1.toFixed(2)}%]\n`);
      } else {
        console.log(`   ⚠️ No profit. Spread = ${spread1.toFixed(2)}%\n`);
      }
    }

    // Try Taco ➜ Alcor
    const tacoOut = simulateSwap(TEST_AMOUNT, taco.reserve0, taco.reserve1, taco.fee);
    const alcorBack = simulateSwap(tacoOut, alcor.reserve1, alcor.reserve0, alcor.fee);
    const gain2 = alcorBack - TEST_AMOUNT;
    const spread2 = (gain2 / TEST_AMOUNT) * 100;

    console.log(`🧪 TACO ➜ ALCOR: ${pair}`);
    console.log(`   Taco ➜ ${tacoOut}, Alcor ➜ ${alcorBack}, Gain ➜ ${gain2}, Spread ➜ ${spread2.toFixed(2)}%`);
    if (tacoOut > MIN_OUTPUT && alcorBack > MIN_OUTPUT) {
      if (spread2 > 0.5) {
        console.log(`🪙 ${taco.asset0Id}/${taco.asset1Id}`);
        console.log(`   🟡 Taco out: ${tacoOut}`);
        console.log(`   🔵 Alcor back: ${alcorBack}`);
        console.log(`   📊 Net gain: ${spread2.toFixed(2)}%`);
        console.log(`   💰 Opportunity: Buy on Taco → Sell on Alcor [${spread2.toFixed(2)}%]\n`);
      } else {
        console.log(`   ⚠️ No profit. Spread = ${spread2.toFixed(2)}%\n`);
      }
    }
  }
}

async function scanArbitrage() {
  const db = await openDb();
  console.log('[arbitrage] Loaded total pools from DB');

  const alcorPools = await fetchPrices(db, 'swap.alcor');
  const tacoPools = await fetchPrices(db, 'swap.taco');

  compareAndLog(alcorPools, tacoPools);

  await db.close();
}

async function startArbitrageScanner() {
  while (true) {
    console.log('\n[arbitrage] Starting scan @', new Date().toLocaleTimeString());
    try {
      await scanArbitrage();
    } catch (err) {
      console.error('[arbitrage] Error:', err.message);
    }
    console.log('[arbitrage] Waiting for next scan...\n');
    await new Promise(res => setTimeout(res, SCAN_INTERVAL_MS));
  }
}

startArbitrageScanner();
