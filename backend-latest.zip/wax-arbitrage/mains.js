// ~/backend/wax-arbitrage/main.js

import sqlite3 from 'sqlite3';
import { open } from 'sqlite';

const DB_PATH = '/mnt/gecko-data/arbitrage.db';
const SCAN_INTERVAL_MS = 60 * 1000;
const TEST_AMOUNT = 1;
const MIN_OUTPUT = 0.000001;
const MIN_RESERVE = 0.01;
const SIMULATION_STEPS = 100;

function parseSymbol(assetId) {
  const [symbol, contract] = assetId.split('@');
  return { symbol, contract };
}

function isWAX(assetId) {
  return assetId.startsWith('WAX@');
}

async function openDb() {
  return await open({ filename: DB_PATH, driver: sqlite3.Database });
}

async function fetchPrices(db, dexKey) {
  console.log(`[arbitrage] Fetching ${dexKey} prices...`);

  const rows = await db.all(`
    SELECT asset0Id, asset1Id, reserve0, reserve1, feeBps
    FROM pools WHERE dexKey = ?
  `, [dexKey]);

  const prices = {};

  for (const { asset0Id, asset1Id, reserve0, reserve1, feeBps } of rows) {
    if (reserve0 <= MIN_RESERVE || reserve1 <= MIN_RESERVE) continue;

    const key = `${asset0Id}/${asset1Id}`;
    const reverseKey = `${asset1Id}/${asset0Id}`;

    prices[key] = {
      asset0Id,
      asset1Id,
      reserve0,
      reserve1,
      fee: feeBps / 10000
    };

    prices[reverseKey] = {
      asset0Id: asset1Id,
      asset1Id: asset0Id,
      reserve0: reserve1,
      reserve1: reserve0,
      fee: feeBps / 10000
    };
  }

  return prices;
}

function simulateSwapWithImpact(inputAmount, reserveIn, reserveOut, fee, steps = SIMULATION_STEPS) {
  let amountRemaining = inputAmount;
  let totalOutput = 0;

  for (let i = 0; i < steps; i++) {
    const stepIn = amountRemaining / (steps - i);
    const amountInWithFee = stepIn * (1 - fee);
    const numerator = amountInWithFee * reserveOut;
    const denominator = reserveIn + amountInWithFee;
    const stepOut = numerator / denominator;

    if (stepOut <= 0) break;

    totalOutput += stepOut;
    reserveIn += amountInWithFee;
    reserveOut -= stepOut;
    amountRemaining -= stepIn;
  }

  return totalOutput;
}

function logOpportunity(label, fromDex, outAmount, toDex, backAmount, spread, direction) {
  console.log(`🪙 ${label}`);
  console.log(`   ${fromDex} out: ${outAmount}`);
  console.log(`   ${toDex} back: ${backAmount}`);
  console.log(`   📊 Net gain: ${spread.toFixed(2)}%`);
  console.log(`   💰 Opportunity: Buy on ${fromDex} → Sell on ${toDex} [${spread.toFixed(2)}%]\n`);
}

function compareAndLog(alcorPools, tacoPools) {
  console.log('[arbitrage] Scanning for arbitrage opportunities...\n');

  const allPairs = new Set([...Object.keys(alcorPools), ...Object.keys(tacoPools)]);

  for (const pair of allPairs) {
    const alcor = alcorPools[pair];
    const taco = tacoPools[pair];
    if (!alcor || !taco) continue;

    // --- Alcor → Taco ---
    const alcorIn = isWAX(alcor.asset0Id) ? alcor.reserve0 : alcor.reserve1;
    const alcorOut = isWAX(alcor.asset0Id) ? alcor.reserve1 : alcor.reserve0;

    const tacoIn = isWAX(taco.asset1Id) ? taco.reserve1 : taco.reserve0;
    const tacoOut = isWAX(taco.asset1Id) ? taco.reserve0 : taco.reserve1;

    const outFromAlcor = simulateSwapWithImpact(TEST_AMOUNT, alcorIn, alcorOut, alcor.fee);
    const backFromTaco = simulateSwapWithImpact(outFromAlcor, tacoIn, tacoOut, taco.fee);

    const spread1 = ((backFromTaco - TEST_AMOUNT) / TEST_AMOUNT) * 100;
    logOpportunity(`${alcor.asset0Id}/${alcor.asset1Id}`, '🔵 Alcor', outFromAlcor, '🟡 Taco', backFromTaco, spread1, 'Alcor → Taco');

    // --- Taco → Alcor ---
    const tacoBackIn = isWAX(taco.asset0Id) ? taco.reserve0 : taco.reserve1;
    const tacoBackOut = isWAX(taco.asset0Id) ? taco.reserve1 : taco.reserve0;

    const alcorBackIn = isWAX(alcor.asset1Id) ? alcor.reserve1 : alcor.reserve0;
    const alcorBackOut = isWAX(alcor.asset1Id) ? alcor.reserve0 : alcor.reserve1;

    const outFromTaco = simulateSwapWithImpact(TEST_AMOUNT, tacoBackIn, tacoBackOut, taco.fee);
    const backFromAlcor = simulateSwapWithImpact(outFromTaco, alcorBackIn, alcorBackOut, alcor.fee);

    const spread2 = ((backFromAlcor - TEST_AMOUNT) / TEST_AMOUNT) * 100;
    logOpportunity(`${taco.asset0Id}/${taco.asset1Id}`, '🟡 Taco', outFromTaco, '🔵 Alcor', backFromAlcor, spread2, 'Taco → Alcor');
  }
}

async function scanArbitrage() {
  const db = await openDb();
  console.log('[arbitrage] Loaded total pools from DB');

  const alcorPools = await fetchPrices(db, 'swap.alcor');
  const tacoPools = await fetchPrices(db, 'swap.taco');

  compareAndLog(alcorPools, tacoPools);

  await db.close();
}

async function startArbitrageScanner() {
  while (true) {
    console.log('\n[arbitrage] Starting scan @', new Date().toLocaleTimeString());
    try {
      await scanArbitrage();
    } catch (err) {
      console.error('[arbitrage] Error:', err.message);
    }
    console.log('[arbitrage] Waiting for next scan...\n');
    await new Promise(res => setTimeout(res, SCAN_INTERVAL_MS));
  }
}

startArbitrageScanner();
