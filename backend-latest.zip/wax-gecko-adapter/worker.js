// worker.js

import { runSyncJob } from './jobs/syncJob.js';

async function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

async function main() {
  console.log("[worker] ▶ Sync job started");

  while (true) {
    try {
      await runSyncJob();                    // Run sync logic
    } catch (err) {
      console.error("[worker] ❌ Sync failed:", err.message);
    }

    await sleep(2000); // GeckoTerminal recommends polling every 2s
  }
}

main();
