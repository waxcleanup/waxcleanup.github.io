// eventsWorkerFullSync.js (final with txnIndex, eventIndex, global_sequence schema and population)

import fs from 'fs';
import fetch from 'node-fetch';
import sqlite3 from 'sqlite3';
import { open } from 'sqlite';

const HISTORY_API = 'https://wax.eosusa.io/v2/history/get_actions';
const ACCOUNT     = 'swap.alcor';
const LIMIT       = 500;

let db;

// ─── INIT / OPEN DB ─────────────────────────────────────
async function initDb() {
  db = await open({
    filename: '/mnt/gecko-data/gecko.db',
    driver:   sqlite3.Database,
    mode:     sqlite3.OPEN_READWRITE | sqlite3.OPEN_CREATE,
  });

  await db.exec('PRAGMA journal_mode = WAL;');
  await db.exec('PRAGMA busy_timeout = 5000;');

  await db.exec(`
    CREATE TABLE IF NOT EXISTS events (
      id             INTEGER PRIMARY KEY AUTOINCREMENT,
      blockNumber    INTEGER NOT NULL,
      blockTimestamp INTEGER NOT NULL,
      txnId          TEXT    NOT NULL,
      txnIndex       INTEGER NOT NULL,
      eventIndex     INTEGER NOT NULL,
      eventType      TEXT    NOT NULL,
      pairId         INTEGER,
      maker          TEXT,
      asset0In       TEXT,
      asset1In       TEXT,
      asset0Out      TEXT,
      asset1Out      TEXT,
      priceNative    TEXT,
      reserve0       TEXT,
      reserve1       TEXT,
      amount0        TEXT,
      amount1        TEXT,
      global_sequence INTEGER UNIQUE
    );
  `);
}

// ─── FETCH A PAGE OF ACTIONS ────────────────────────────
async function fetchActions(lowerBound) {
  const url = new URL(HISTORY_API);
  url.searchParams.set('account', ACCOUNT);
  url.searchParams.set('limit', String(LIMIT));
  url.searchParams.set('sort', 'asc');
  url.searchParams.set('after', String(lowerBound));

  const res = await fetch(url.toString());
  if (!res.ok) throw new Error(`HTTP ${res.status}`);
  const json = await res.json();
  return json.actions || [];
}

function groupByTx(actions) {
  const map = {};
  actions.forEach(a => (map[a.trx_id] ||= []).push(a));
  return map;
}

async function handleAction(a, ctx) {
  const seq     = a.global_sequence;
  const d       = a.act.data;
  let type;
  if (a.act.name === 'logswap') type = 'swap';
  else if (a.act.name === 'logmint') type = 'join';
  else if (a.act.name === 'logburn') type = 'exit';
  else return;

  const common  = [ctx.blockNum, ctx.blockTs, ctx.txnId, ctx.txnIndex, ctx.eventIndex, type, parseInt(d.poolId, 10), d.sender || d.owner || null];
  let params;

  if (type === 'swap') {
    const [inRaw]  = d.tokenA.split(' ');
    const [outRaw] = d.tokenB.split(' ');
    const absIn    = Math.abs(+inRaw).toFixed(50);
    const absOut   = Math.abs(+outRaw).toFixed(50);
    const [r0]     = d.reserveA.split(' ');
    const [r1]     = d.reserveB.split(' ');
    const price    = (absOut / absIn).toFixed(50);

    params = [...common, absIn, null, absOut, null, price, r0, r1, absIn, absOut, seq];
    console.log(`seq=${seq} swap @ block#${ctx.blockNum} tx=${ctx.txnId} eIdx=${ctx.eventIndex}`);
  } else if (type === 'join' || type === 'exit') {
    const [r0] = d.reserveA.split(' ');
    const [r1] = d.reserveB.split(' ');
    const [a0] = d.tokenA.split(' ');
    const [a1] = d.tokenB.split(' ');

    params = [...common, null, null, null, null, null, r0, r1, a0, a1, seq];
    console.log(`seq=${seq} ${type} @ block#${ctx.blockNum} tx=${ctx.txnId} eIdx=${ctx.eventIndex}`);
  }

  const stmt = `INSERT OR IGNORE INTO events(
    blockNumber,blockTimestamp,txnId,txnIndex,eventIndex,eventType,
    pairId,maker,asset0In,asset1In,asset0Out,asset1Out,
    priceNative,reserve0,reserve1,amount0,amount1,global_sequence
  ) VALUES(${new Array(18).fill('?').join(',')});`;

  await db.run(stmt, params);
}

async function processGroupedBatch(grouped) {
  const blockTxCount = {};
  const txEventCount = {};

  for (const [txnId, acts] of Object.entries(grouped)) {
    const blockNum = acts[0].block_num;
    const blockTs  = Math.floor(new Date(acts[0].timestamp).getTime() / 1000);

    blockTxCount[blockNum] = (blockTxCount[blockNum] || 0) + 1;
    const txnIndex = blockTxCount[blockNum] - 1;

    txEventCount[txnId] ||= 0;
    let eventIndex = txEventCount[txnId];

    for (const a of acts) {
      const ctx = { blockNum, blockTs, txnId, txnIndex, eventIndex };
      await handleAction(a, ctx);
      eventIndex++;
    }
    txEventCount[txnId] = eventIndex;
  }
}

(async () => {
  try {
    await initDb();
    console.log('[sync] starting backfill…');

    const row = await db.get('SELECT MAX(global_sequence) AS seq FROM events');
    const lastSeq = row && row.seq != null ? row.seq : 0;
    let bound = lastSeq > 0 ? lastSeq + 1 : 1;
    if (!lastSeq) console.log('[sync] no existing sequence found, starting from seq=1');
    else console.log(`[sync] resuming from seq=${bound}`);

    let batch;
    let prevLastSeq = null;

    do {
      console.log(`[debug] Fetching from seq=${bound}`);
      batch = await fetchActions(bound);

      if (!batch.length) {
        console.warn(`[warn] No actions returned at seq=${bound}, incrementing and retrying...`);
        bound++;
        continue;
      }

      const grouped = groupByTx(batch);
      await db.exec('BEGIN');
      await processGroupedBatch(grouped);
      await db.exec('COMMIT');

      const lastSeqInBatch = batch[batch.length - 1].global_sequence;
      if (lastSeqInBatch === prevLastSeq) {
        console.warn('[warn] Stuck batch loop detected. Exiting to prevent infinite loop.');
        break;
      }

      prevLastSeq = lastSeqInBatch;
      bound = lastSeqInBatch + 1;
      console.log(`[sync] backfilled up to seq ${lastSeqInBatch} — ${batch.length} action(s)`);
    } while (batch.length === LIMIT);

    console.log('[sync] backfill complete; exiting');
    process.exit(0);
  } catch (err) {
    console.error('Fatal error:', err);
    process.exit(1);
  }
})();
