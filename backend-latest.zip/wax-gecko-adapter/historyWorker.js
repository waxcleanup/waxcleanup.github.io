// backend/historyWorker.js

import fs from "fs";
import path from "path";
import axios from "axios";
import sqlite3 from "sqlite3";
import { open } from "sqlite";

const { OPEN_READWRITE, OPEN_CREATE } = sqlite3;
const MNT_DIR = "/mnt/gecko-data";
const HOME_DIR = path.resolve(process.env.HOME, "gecko-data");
const DB_DIR = fs.existsSync(MNT_DIR) && (() => {
  try { fs.accessSync(MNT_DIR, fs.constants.W_OK); return true; } catch { return false; }
})() ? MNT_DIR : HOME_DIR;
const DB_PATH = path.join(DB_DIR, "history.db");
const EOS_HISTORY = "https://wax.eosusa.io/v2/history/get_actions";
const DEX_ACCOUNT = "swap.alcor";
const BATCH_SIZE = 1000;
const PAUSE_MS = 1000; // 1s between batches

const http = axios.create({ timeout: 5000 });
// Reset flag: delete existing DB to start at offset 0
const forceReset = process.argv.includes("--reset");
if (forceReset && fs.existsSync(DB_PATH)) {
  fs.unlinkSync(DB_PATH);
  console.log(`[historyWorker] reset: deleted ${DB_PATH}`);
}

// Ensure schema with actionOrdinal
async function ensureSchema(conn) {
  await conn.exec(`
    CREATE TABLE IF NOT EXISTS events (
      id              INTEGER PRIMARY KEY AUTOINCREMENT,
      actionOrdinal   INTEGER NOT NULL,
      blockNumber     INTEGER NOT NULL,
      blockTimestamp  INTEGER NOT NULL,
      txnId           TEXT    NOT NULL,
      txnIndex        INTEGER NOT NULL,
      eventIndex      INTEGER NOT NULL,
      eventType       TEXT    NOT NULL,
      pairId          INTEGER,
      maker           TEXT,
      asset0In        TEXT,
      asset1In        TEXT,
      asset0Out       TEXT,
      asset1Out       TEXT,
      priceNative     TEXT,
      reserve0        TEXT,
      reserve1        TEXT,
      amount0         TEXT,
      amount1         TEXT,
      UNIQUE(actionOrdinal, txnId, eventType)
    );
  `);
  await conn.exec("CREATE INDEX IF NOT EXISTS idx_offset ON events(actionOrdinal);");
}

let db;
async function openDatabase() {
  if (db) return db;
  if (!fs.existsSync(DB_DIR)) fs.mkdirSync(DB_DIR, { recursive: true });
  const conn = await open({ filename: DB_PATH, driver: sqlite3.Database, mode: OPEN_READWRITE | OPEN_CREATE });
  await conn.exec("PRAGMA journal_mode = WAL;");
  await conn.exec("PRAGMA busy_timeout = 5000;");
  await ensureSchema(conn);
  db = conn;
  return db;
}

function parseSwapData(data) {
  const [inRaw] = data.tokenA.split(" ");
  const [outRaw] = data.tokenB.split(" ");
  const absIn = Math.abs(+inRaw);
  const absOut = Math.abs(+outRaw);
  return {
    asset0In: absIn.toFixed(50),
    asset1Out: absOut.toFixed(50),
    priceNative: (absOut / absIn).toFixed(50)
  };
}

async function handleSwap(d, ctx, conn) {
  const { asset0In, asset1Out, priceNative } = parseSwapData(d);
  const params = [
    ctx.offset, ctx.blockNum, ctx.blockTs, ctx.txnId, ctx.txnIndex, ctx.eventIndex, 'swap',
    parseInt(d.poolId, 10), d.sender,
    asset0In, null, null, asset1Out, priceNative,
    d.reserveA.split(' ')[0], d.reserveB.split(' ')[0], null, null
  ];
  await conn.run(
    `INSERT OR IGNORE INTO events(
      actionOrdinal,blockNumber,blockTimestamp,txnId,txnIndex,eventIndex,eventType,
      pairId,maker,asset0In,asset1In,asset0Out,asset1Out,priceNative,reserve0,reserve1,amount0,amount1
    ) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?);`,
    params
  );
}

async function handleJoin(d, ctx, conn) {
  const [a0] = d.tokenA.split(' ');
  const [a1] = d.tokenB.split(' ');
  const params = [
    ctx.offset, ctx.blockNum, ctx.blockTs, ctx.txnId, ctx.txnIndex, ctx.eventIndex, 'join',
    parseInt(d.poolId, 10), d.owner,
    a0, a1, null, null, null,
    d.reserveA.split(' ')[0], d.reserveB.split(' ')[0], null, null
  ];
  await conn.run(
    `INSERT OR IGNORE INTO events(
      actionOrdinal,blockNumber,blockTimestamp,txnId,txnIndex,eventIndex,eventType,
      pairId,maker,asset0In,asset1In,asset0Out,asset1Out,priceNative,reserve0,reserve1,amount0,amount1
    ) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?);`,
    params
  );
}

async function handleExit(d, ctx, conn) {
  const [a0] = d.tokenA.split(' ');
  const [a1] = d.tokenB.split(' ');
  const params = [
    ctx.offset, ctx.blockNum, ctx.blockTs, ctx.txnId, ctx.txnIndex, ctx.eventIndex, 'exit',
    parseInt(d.poolId, 10), d.owner,
    null, null, a0, a1, null,
    d.reserveA.split(' ')[0], d.reserveB.split(' ')[0], null, null
  ];
  await conn.run(
    `INSERT OR IGNORE INTO events(
      actionOrdinal,blockNumber,blockTimestamp,txnId,txnIndex,eventIndex,eventType,
      pairId,maker,asset0In,asset1In,asset0Out,asset1Out,priceNative,reserve0,reserve1,amount0,amount1
    ) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?);`,
    params
  );
}

async function processBatch(actions, conn) {
  const byOffset = {};
  for (const a of actions) {
    const off = a.action_ordinal;
    byOffset[off] = byOffset[off] || [];
    byOffset[off].push(a);
  }
  const offsets = Object.keys(byOffset).map(Number).sort((a, b) => a - b);
  for (const off of offsets) {
    const acts = byOffset[off];
    let eventIndex = 0;
    const ctxBase = {
      offset: off,
      blockNum: acts[0].block_num,
      blockTs: Math.floor(new Date(acts[0].timestamp).getTime() / 1000),
      txnId: acts[0].trx_id,
      txnIndex: 0
    };
    for (const a of acts) {
      const ctx = { ...ctxBase, eventIndex };
      if (a.act.name === 'logswap') await handleSwap(a.act.data, ctx, conn);
      if (a.act.name === 'logmint') await handleJoin(a.act.data, ctx, conn);
      if (a.act.name === 'logburn') await handleExit(a.act.data, ctx, conn);
      eventIndex++;
    }
  }
}

async function backfillLoop() {
  const conn = await openDatabase();
  while (true) {
    const row = await conn.get(`SELECT MAX(actionOrdinal) AS maxOffset FROM events`);
    const lastOffset = forceReset ? 0 : (row?.maxOffset ?? -1) + 1;
    console.log(`[historyWorker] fetching from offset ${lastOffset}`);

    const resp = await http.get(EOS_HISTORY, {
      params: { account: DEX_ACCOUNT, pos: lastOffset, limit: BATCH_SIZE, sort: 'asc' }
    });
    const actions = resp.data.actions || [];
    if (!actions.length) {
      console.log("[historyWorker] no more actions");
      return;
    }

    console.log(
      `[historyWorker] backfilling ${actions.length} actions ` +
      `from block ${actions[0].block_num} to ${actions[actions.length - 1].block_num}`
    );

    await conn.exec("BEGIN");
    await processBatch(actions, conn);
    await conn.exec("COMMIT");
    await new Promise(r => setTimeout(r, PAUSE_MS));
  }
}

console.log("[historyWorker] starting historical backfill");
backfillLoop();
