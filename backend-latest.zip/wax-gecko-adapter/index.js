// ~/backend/wax-gecko-adapter/index.js
import dotenv from "dotenv";
dotenv.config();

import express from "express";
import cors from "cors";
import bodyParser from "body-parser";
import geckoRoutes from "./routes/geckoRoutes.js";

const app = express();
const PORT = process.env.GECKO_PORT || 3004;

app.use(cors());
app.use(bodyParser.json());
app.use("/waxgecko", geckoRoutes);

app.listen(PORT, () => {
  console.log(`🦎  Gecko adapter running on port ${PORT}`);
});
