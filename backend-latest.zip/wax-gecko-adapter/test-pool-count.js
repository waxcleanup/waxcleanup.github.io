// wax-gecko-adapter/test-pool-count.js
import dotenv from "dotenv";
dotenv.config();

import mongoose from "mongoose";
import Pool from "../models/Pool.js";

(async () => {
  if (!process.env.MONGODB_URI) {
    console.error("⚠️ MONGODB_URI is not set");
    process.exit(1);
  }

  try {
    await mongoose.connect(process.env.MONGODB_URI);
    const count = await Pool.countDocuments();
    console.log("🔢 Number of Pool documents in MongoDB:", count);
  } catch (e) {
    console.error("❌ Failed to query Pool collection:", e.message);
  } finally {
    mongoose.connection.close();
  }
})();
