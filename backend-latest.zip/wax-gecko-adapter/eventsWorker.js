// eventsWorker.js (updated)

import fs from "fs";
import path from "path";
import axios from "axios";
import sqlite3 from "sqlite3";
import { open } from "sqlite";

const { OPEN_READWRITE, OPEN_CREATE } = sqlite3;
const MNT_DIR       = "/mnt/gecko-data";
const HOME_DIR      = path.resolve(process.env.HOME, "gecko-data");
const DB_DIR        = fs.existsSync(MNT_DIR) && fs.accessSync(MNT_DIR, fs.constants.W_OK) === undefined
                     ? MNT_DIR
                     : HOME_DIR;
const DB_PATH       = path.join(DB_DIR, "gecko.db");
const EOS_HISTORY   = "https://wax.eosusa.io/v2/history/get_actions";
const DEX_ACCOUNT   = "swap.alcor";
const BATCH_SIZE    = 500;
const POLL_MS       = 5000;

const http           = axios.create({ timeout: 5000 });
let   isProcessing   = false;
let   db;  // singleton connection

// Ensure the directory exists
if (!fs.existsSync(DB_DIR)) {
  fs.mkdirSync(DB_DIR, { recursive: true });
  console.log(`[eventsWorker] created DB directory: ${DB_DIR}`);
} else {
  console.log(`[eventsWorker] DB directory exists: ${DB_DIR}`);
}

// ───── Schema Setup ───────────────────────────────────────────────────────
async function ensureSchema(conn) {
  await conn.exec(`
    CREATE TABLE IF NOT EXISTS events (
      id            INTEGER PRIMARY KEY AUTOINCREMENT,
      blockNumber   INTEGER NOT NULL,
      blockTimestamp INTEGER NOT NULL,
      txnId         TEXT NOT NULL,
      txnIndex      INTEGER NOT NULL,
      eventIndex    INTEGER NOT NULL,
      eventType     TEXT NOT NULL,
      pairId        INTEGER,
      maker         TEXT,
      asset0In      TEXT,
      asset1In      TEXT,
      asset0Out     TEXT,
      asset1Out     TEXT,
      priceNative   TEXT,
      reserve0      TEXT,
      reserve1      TEXT,
      amount0       TEXT,
      amount1       TEXT,
      UNIQUE(txnId, eventIndex, eventType)
    );
  `);
}

// ───── Open / Init DB (singleton) ─────────────────────────────────────────
async function openDatabase() {
  if (db) return db;

  const conn = await open({
    filename: DB_PATH,
    driver:   sqlite3.Database,
    mode:     OPEN_READWRITE | OPEN_CREATE
  });

  await conn.exec("PRAGMA journal_mode = WAL;");
  await conn.exec("PRAGMA busy_timeout = 5000;");
  await ensureSchema(conn);

  db = conn;
  return db;
}

// ───── Event Parsers & Handlers ───────────────────────────────────────────
function parseSwapData(data) {
  const [inRaw]  = data.tokenA.split(" ");
  const [outRaw] = data.tokenB.split(" ");
  const absIn    = Math.abs(+inRaw);
  const absOut   = Math.abs(+outRaw);
  return {
    asset0In:    absIn.toFixed(50),
    asset1Out:   absOut.toFixed(50),
    priceNative: (absOut / absIn).toFixed(50),
  };
}

async function handleSwap(d, ctx, conn) {
  const { asset0In, asset1Out, priceNative } = parseSwapData(d);
  const params = [
    ctx.blockNum, ctx.blockTs, ctx.txnId, ctx.txnIndex, ctx.eventIndex, "swap",
    parseInt(d.poolId, 10), d.sender,
    asset0In, null, null, asset1Out,
    priceNative,
    d.reserveA.split(" ")[0], d.reserveB.split(" ")[0],
    null, null
  ];
  await conn.run(
    `INSERT OR IGNORE INTO events(
       blockNumber,blockTimestamp,txnId,txnIndex,eventIndex,eventType,
       pairId,maker,asset0In,asset1In,asset0Out,asset1Out,
       priceNative,reserve0,reserve1,amount0,amount1
     ) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`,
    params
  );
  console.log(`[eventsWorker] inserted swap — block:${ctx.blockNum} tx:${ctx.txnId} eventIdx:${ctx.eventIndex}`);
}

async function handleJoin(d, ctx, conn) {
  const [a0] = d.tokenA.split(" ");
  const [a1] = d.tokenB.split(" ");
  const params = [
    ctx.blockNum, ctx.blockTs, ctx.txnId, ctx.txnIndex, ctx.eventIndex, "join",
    parseInt(d.poolId, 10), d.owner,
    null, null, null, null, null,
    d.reserveA.split(" ")[0], d.reserveB.split(" ")[0],
    a0, a1
  ];
  await conn.run(
    `INSERT OR IGNORE INTO events(
       blockNumber,blockTimestamp,txnId,txnIndex,eventIndex,eventType,
       pairId,maker,asset0In,asset1In,asset0Out,asset1Out,
       priceNative,reserve0,reserve1,amount0,amount1
     ) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`,
    params
  );
  console.log(`[eventsWorker] inserted join — block:${ctx.blockNum} tx:${ctx.txnId} eventIdx:${ctx.eventIndex}`);
}

async function handleExit(d, ctx, conn) {
  const [a0] = d.tokenA.split(" ");
  const [a1] = d.tokenB.split(" ");
  const params = [
    ctx.blockNum, ctx.blockTs, ctx.txnId, ctx.txnIndex, ctx.eventIndex, "exit",
    parseInt(d.poolId, 10), d.owner,
    null, null, null, null, null,
    d.reserveA.split(" ")[0], d.reserveB.split(" ")[0],
    a0, a1
  ];
  await conn.run(
    `INSERT OR IGNORE INTO events(
       blockNumber,blockTimestamp,txnId,txnIndex,eventIndex,eventType,
       pairId,maker,asset0In,asset1In,asset0Out,asset1Out,
       priceNative,reserve0,reserve1,amount0,amount1
     ) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`,
    params
  );
  console.log(`[eventsWorker] inserted exit — block:${ctx.blockNum} tx:${ctx.txnId} eventIdx:${ctx.eventIndex}`);
}

// ───── Batch Processor ─────────────────────────────────────────────────────
async function processBatch(actions, conn) {
  const byTx    = {};
  const blockCounts = {};
  const txnCounts   = {};

  actions.forEach(a => (byTx[a.trx_id] ||= []).push(a));

  for (const [txnId, acts] of Object.entries(byTx)) {
    const { block_num, timestamp } = acts[0];
    const blockTs = Math.floor(new Date(timestamp).getTime() / 1000);
    blockCounts[block_num] = (blockCounts[block_num] || 0) + 1;
    const txnIndex   = blockCounts[block_num] - 1;
    txnCounts[txnId] ||= 0;
    let eventIndex  = txnCounts[txnId];

    const ctx = { blockNum: block_num, blockTs, txnId, txnIndex, eventIndex };
    for (const [name, fn] of [["logswap", handleSwap], ["logmint", handleJoin], ["logburn", handleExit]]) {
      for (const e of acts.filter(a => a.act.name === name)) {
        ctx.eventIndex = eventIndex;
        await fn(e.act.data, ctx, conn);
        eventIndex++;
      }
    }
    txnCounts[txnId] = eventIndex;
  }
}

// ───── Polling Loop ─────────────────────────────────────────────────────────
async function fetchAndStoreEvents() {
  if (isProcessing) return;
  isProcessing = true;

  try {
    const conn = await openDatabase();
    const { maxBlock = 0 } = (await conn.get(`SELECT MAX(blockNumber) AS maxBlock FROM events`)) || {};

    const resp    = await http.get(EOS_HISTORY, {
      params: { account: DEX_ACCOUNT, pos: maxBlock, limit: BATCH_SIZE }
    });
    const actions = (resp.data.actions || [])
                      .filter(a => a.block_num > maxBlock)
                      .slice(0, BATCH_SIZE);

    if (actions.length) {
      await conn.exec("BEGIN");
      for (let i = 0; i < actions.length; i += 50) {
        await processBatch(actions.slice(i, i + 50), conn);
        await new Promise(r => setTimeout(r, 10));
      }
      await conn.exec("COMMIT");
    }
  } catch (err) {
    console.error("[eventsWorker] error:", err);
  } finally {
    isProcessing = false;
    setTimeout(fetchAndStoreEvents, POLL_MS);
  }
}

// ───── Startup ─────────────────────────────────────────────────────────────
console.log("[eventsWorker] starting worker");
fetchAndStoreEvents();
