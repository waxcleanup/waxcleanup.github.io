// ~/backend/wax-gecko-adapter/poolsWorker.js
// Updated: dedicated DBs for pools and assets, batched transactions, WAL mode, busy timeout, slower polling
// Only fetch the most recent 1000 pools every cycle

import fs from "fs";
import path from "path";
import axios from "axios";
import sqlite3 from "sqlite3";
import { open } from "sqlite";

// Configuration
const BASE_DIR = "/mnt/gecko-data";
const POOLS_DB = path.join(BASE_DIR, "alcorpools.db");
const ASSETS_DB = path.join(BASE_DIR, "assets.db");
const TABLE_API      = "https://wax.greymass.com/v1/chain/get_table_rows";
const SUPPLY_API     = "https://wax.greymass.com/v1/chain/get_currency_stats";
const DEX_CONTRACT   = "swap.alcor";
const POLL_INTERVAL_MS = 30000; // 30 seconds

// Ensure base directory exists
if (!fs.existsSync(BASE_DIR)) {
  fs.mkdirSync(BASE_DIR, { recursive: true });
}

// Utility: parse "123.456 SYMBOL" into { symbol, contract, decimals }
function parseTokenQuantity(quantity, contract) {
  if (!quantity || typeof quantity !== "string") {
    return { symbol: null, contract, decimals: 0 };
  }
  const [amount, symbol] = quantity.split(" ");
  const decimals = amount.includes(".") ? amount.split(".")[1].length : 0;
  return { symbol, contract, decimals };
}

// Open (or create) SQLite DB and enable WAL and busy timeout
async function openDatabase(file) {
  const db = await open({ filename: file, driver: sqlite3.Database });
  await db.exec(`PRAGMA journal_mode = WAL;`);
  await db.exec(`PRAGMA busy_timeout = 5000;`);
  return db;
}

// Create pools table if missing
async function ensurePoolsTable(db) {
  await db.exec(`
    CREATE TABLE IF NOT EXISTS pools (
      poolId    INTEGER PRIMARY KEY,
      dexKey    TEXT    NOT NULL,
      asset0Id  TEXT    NOT NULL,
      asset1Id  TEXT    NOT NULL,
      feeBps    INTEGER NOT NULL
    );
    CREATE INDEX IF NOT EXISTS idx_pools_assets ON pools(asset0Id, asset1Id);
    CREATE INDEX IF NOT EXISTS idx_pools_dex    ON pools(dexKey);
  `);
}

// Create assets table if missing
async function ensureAssetsTable(db) {
  await db.exec(`
    CREATE TABLE IF NOT EXISTS assets (
      assetId          TEXT    PRIMARY KEY,
      name             TEXT    NOT NULL,
      symbol           TEXT    NOT NULL,
      decimals         INTEGER NOT NULL,
      totalSupply      REAL,
      circulatingSupply REAL,
      updatedAt        INTEGER NOT NULL
    );
    CREATE INDEX IF NOT EXISTS idx_assets_symbol ON assets(symbol);
    CREATE INDEX IF NOT EXISTS idx_assets_name   ON assets(name);
  `);
}

// Fetch latest pool rows from chain (most recent 1000 records)
async function fetchLatestPoolRows(limit = 1000) {
  const resp = await axios.post(TABLE_API, {
    json: true,
    code: DEX_CONTRACT,
    scope: DEX_CONTRACT,
    table: "pools",
    limit,
    reverse: true,
    show_payer: false
  });
  return resp.data.rows || [];
}

// Fetch supply and max for a token
async function fetchSupplyData(symbol, contract) {
  try {
    const response = await axios.post(SUPPLY_API, { code: contract, symbol });
    const stats = response.data[symbol] || {};
    const parseAmount = (qty) => parseFloat(qty.split(' ')[0]);
    return {
      supply: stats.supply ? parseAmount(stats.supply) : null,
      max:    stats.max_supply ? parseAmount(stats.max_supply) : null
    };
  } catch (err) {
    console.warn(`Failed to fetch supply for ${symbol}@${contract}: ${err.message}`);
    return { supply: null, max: null };
  }
}

// Main sync routine
async function syncPoolsAndAssets() {
  try {
    const poolsDb = await openDatabase(POOLS_DB);
    const assetsDb = await openDatabase(ASSETS_DB);
    await ensurePoolsTable(poolsDb);
    await ensureAssetsTable(assetsDb);

    // Determine the current highest poolId in local DB
    const { maxId = 0 } = await poolsDb.get(
      `SELECT MAX(poolId) AS maxId FROM pools`
    ) || {};

    // Fetch latest pool rows, filter only new ones
    const rows = await fetchLatestPoolRows(1000);
    const newRows = rows.filter(r => r.id > maxId);
    if (!newRows.length) {
      console.log('[poolsWorker] No new pools to sync.');
      await poolsDb.close();
      await assetsDb.close();
      return;
    }
    console.log(`[poolsWorker] Syncing ${newRows.length} new pools (IDs > ${maxId})`);

    // Batch pool writes in transaction (insert new only)
    await poolsDb.exec('BEGIN TRANSACTION;');
    const insertPool = await poolsDb.prepare(
      `INSERT OR IGNORE INTO pools (poolId, dexKey, asset0Id, asset1Id, feeBps)
       VALUES (?, ?, ?, ?, ?);`
    );
    for (const row of newRows) {
      const tokenA = parseTokenQuantity(row.tokenA?.quantity, row.tokenA?.contract);
      const tokenB = parseTokenQuantity(row.tokenB?.quantity, row.tokenB?.contract);
      if (!tokenA.symbol || !tokenB.symbol) continue;
      const asset0Id = `${tokenA.symbol}@${tokenA.contract}`;
      const asset1Id = `${tokenB.symbol}@${tokenB.contract}`;
      const feeBps = Math.floor(row.fee / 100);
      await insertPool.run(row.id, 'alcor', asset0Id, asset1Id, feeBps);
    }
    await insertPool.finalize();
    await poolsDb.exec('COMMIT;');

    // Batch asset writes in transaction (update assets for new pools)
    await assetsDb.exec('BEGIN TRANSACTION;');
    const now = Math.floor(Date.now() / 1000);
    const upsertAsset = await assetsDb.prepare(
      `INSERT INTO assets (assetId, name, symbol, decimals, totalSupply, circulatingSupply, updatedAt)
       VALUES (?, ?, ?, ?, ?, ?, ?)
       ON CONFLICT(assetId) DO UPDATE SET
         totalSupply = excluded.totalSupply,
         circulatingSupply = excluded.circulatingSupply,
         updatedAt = excluded.updatedAt;`
    );
    for (const row of newRows) {
      for (const token of [
        parseTokenQuantity(row.tokenA?.quantity, row.tokenA?.contract),
        parseTokenQuantity(row.tokenB?.quantity, row.tokenB?.contract)
      ]) {
        if (!token.symbol) continue;
        const assetId = `${token.symbol}@${token.contract}`;
        const { supply, max } = await fetchSupplyData(token.symbol, token.contract);
        await upsertAsset.run(
          assetId, token.symbol, token.symbol, token.decimals, max, supply, now
        );
      }
    }
    await upsertAsset.finalize();
    await assetsDb.exec('COMMIT;');

    await poolsDb.close();
    await assetsDb.close();
    console.log('✅ poolsWorker: synced new pools and updated assets.');
  } catch (err) {
    console.error(`[poolsWorker] Error: ${err.message}`);
  }
}

// Kick off and schedule
syncPoolsAndAssets();
setInterval(syncPoolsAndAssets, POLL_INTERVAL_MS);
syncPoolsAndAssets();
setInterval(syncPoolsAndAssets, POLL_INTERVAL_MS);
