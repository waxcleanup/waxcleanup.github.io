// ~/backend/wax-gecko-adapter/test-mongo.js
import dotenv from 'dotenv';
import mongoose from 'mongoose';

dotenv.config(); // will pick up MONGODB_URI from wax-gecko-adapter/.env

(async () => {
  try {
    await mongoose.connect(process.env.MONGODB_URI, {
      useNewUrlParser: true,
      useUnifiedTopology: true,
    });
    console.log('✅  Successfully connected to MongoDB!');
    process.exit(0);
  } catch (e) {
    console.error('❌  MongoDB connection error:', e.message);
    process.exit(1);
  }
})();

