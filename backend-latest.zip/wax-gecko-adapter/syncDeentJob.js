// ~/backend/wax-gecko-adapter/syncDeentJob.js
// ──────────────────────────────────────────────────────────────────────────────
// Copies new rows from `events` → `deent` every 1.2 seconds.

import Database from 'better-sqlite3';

// 1) Open the SQLite DB (same path as geckoRoutes uses)
const DB_PATH = '/mnt/gecko-data/gecko.db';
const db = new Database(DB_PATH);

// 2) Ensure tables exist (skip if you already ran the SQL manually)
db.exec(`
  PRAGMA foreign_keys = OFF;
  BEGIN TRANSACTION;

  CREATE TABLE IF NOT EXISTS deent (
    id               INTEGER PRIMARY KEY AUTOINCREMENT,
    blockNumber      INTEGER NOT NULL,
    blockTimestamp   INTEGER NOT NULL,
    txnId            TEXT    NOT NULL,
    txnIndex         INTEGER NOT NULL,
    eventIndex       INTEGER NOT NULL,
    eventType        TEXT    NOT NULL,
    pairId           TEXT    NOT NULL,
    maker            TEXT    NOT NULL,
    asset0In         TEXT,
    asset1In         TEXT,
    asset0Out        TEXT,
    asset1Out        TEXT,
    priceNative      TEXT,
    reserve0         TEXT,
    reserve1         TEXT,
    amount0          TEXT,
    amount1          TEXT,
    UNIQUE(blockNumber, txnIndex, eventIndex)
  );

  CREATE TABLE IF NOT EXISTS sync_meta (
    key   TEXT PRIMARY KEY,
    value TEXT
  );
  INSERT OR IGNORE INTO sync_meta (key, value) VALUES ('lastSyncedBlock','0');

  COMMIT;
`);

// 3) Prepare statements to get/update lastSyncedBlock
const getLastBlockStmt = db.prepare(`
  SELECT value FROM sync_meta WHERE key = 'lastSyncedBlock'
`);
const updateLastBlockStmt = db.prepare(`
  UPDATE sync_meta SET value = @block WHERE key = 'lastSyncedBlock'
`);

// 4) Select all events with blockNumber > :fromBlock
const selectNewEventsStmt = db.prepare(`
  SELECT
    blockNumber,
    blockTimestamp,
    txnId,
    txnIndex,
    eventIndex,
    eventType,
    pairId,
    maker,
    asset0In, asset1In, asset0Out, asset1Out, priceNative, reserve0, reserve1,
    amount0, amount1
  FROM events
  WHERE blockNumber > @fromBlock
  ORDER BY blockNumber ASC, txnIndex ASC, eventIndex ASC
`);

// 5) Insert into `deent` with “INSERT OR IGNORE” so duplicates skip
const insertIntoDeentStmt = db.prepare(`
  INSERT OR IGNORE INTO deent (
    blockNumber, blockTimestamp, txnId, txnIndex, eventIndex,
    eventType, pairId, maker,
    asset0In, asset1In, asset0Out, asset1Out, priceNative,
    reserve0, reserve1, amount0, amount1
  ) VALUES (
    @blockNumber, @blockTimestamp, @txnId, @txnIndex, @eventIndex,
    @eventType, @pairId, @maker,
    @asset0In, @asset1In, @asset0Out, @asset1Out, @priceNative,
    @reserve0, @reserve1, @amount0, @amount1
  )
`);

// 6) This function does one “sync round”
function syncToDeent() {
  try {
    // a) Get lastSyncedBlock from sync_meta
    const row = getLastBlockStmt.get();
    let lastSyncedBlock = parseInt(row.value || '0', 10);

    // b) Query events table for any new rows
    const newEvents = selectNewEventsStmt.all({ fromBlock: lastSyncedBlock });

    if (!newEvents.length) {
      console.log(`[syncDeent] No new events (lastSyncedBlock=${lastSyncedBlock}).`);
      return;
    }

    console.log(`[syncDeent] Found ${newEvents.length} new event(s) > block ${lastSyncedBlock}.`);

    // c) Insert all new events inside a transaction
    const insertMany = db.transaction((eventsArray) => {
      let maxBlock = lastSyncedBlock;
      for (const ev of eventsArray) {
        insertIntoDeentStmt.run({
          blockNumber:    ev.blockNumber,
          blockTimestamp: ev.blockTimestamp,
          txnId:          ev.txnId,
          txnIndex:       ev.txnIndex,
          eventIndex:     ev.eventIndex,
          eventType:      ev.eventType,
          pairId:         ev.pairId,
          maker:          ev.maker,
          asset0In:       ev.asset0In,
          asset1In:       ev.asset1In,
          asset0Out:      ev.asset0Out,
          asset1Out:      ev.asset1Out,
          priceNative:    ev.priceNative,
          reserve0:       ev.reserve0,
          reserve1:       ev.reserve1,
          amount0:        ev.amount0,
          amount1:        ev.amount1
        });
        if (ev.blockNumber > maxBlock) {
          maxBlock = ev.blockNumber;
        }
      }
      // d) Update lastSyncedBlock in sync_meta
      updateLastBlockStmt.run({ block: maxBlock.toString() });
      console.log(`[syncDeent] Updated lastSyncedBlock → ${maxBlock}`);
    });

    insertMany(newEvents);
  }
  catch (err) {
    console.error('[syncDeent] Error while syncing to deent:', err);
  }
}

// 7) Immediately run once, then schedule every 1.2 seconds
syncToDeent();
setInterval(() => {
  const timestamp = new Date().toISOString();
  console.log(`[syncDeent] Interval tick at ${timestamp}`);
  syncToDeent();
}, 1200);

console.log('✅ syncDeentJob initialized (copies events → deent every 1.2 seconds).');
