// ~/backend/wax-gecko-adapter/jobs/syncPoolsJob.js

import sqlite3 from 'sqlite3';
import { open } from 'sqlite';
import axios from 'axios';
import fs from 'fs';
import path from 'path';

// Paths for separate databases
const DATA_DIR = '/mnt/gecko-data';
const POOLS_DB_PATH = path.join(DATA_DIR, 'alcorpools.db');
const ASSETS_DB_PATH = path.join(DATA_DIR, 'assets.db');

const TABLE_API = 'https://wax.greymass.com/v1/chain/get_table_rows';
const SUPPLY_API = 'https://wax.greymass.com/v1/chain/get_currency_stats';
const DEX_CONTRACT = 'swap.alcor';

// Ensure data directory exists
if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });

function parseTokenQuantity(quantity, contract) {
  if (!quantity || typeof quantity !== 'string') {
    return { symbol: null, contract, decimals: 0 };
  }
  const [amount, symbol] = quantity.split(' ');
  const decimals = amount.includes('.') ? amount.split('.')[1].length : 0;
  return { symbol, contract, decimals };
}

async function openDatabase(dbPath) {
  const db = await open({ filename: dbPath, driver: sqlite3.Database });
  await db.exec('PRAGMA journal_mode = WAL;');
  return db;
}

async function ensureTables(db) {
  await db.exec(`
    CREATE TABLE IF NOT EXISTS pools (
      poolId    INTEGER PRIMARY KEY,
      dexKey    TEXT    NOT NULL,
      asset0Id  TEXT    NOT NULL,
      asset1Id  TEXT    NOT NULL,
      feeBps    INTEGER NOT NULL
    );
    CREATE INDEX IF NOT EXISTS idx_pools_assets ON pools(asset0Id, asset1Id);
    CREATE INDEX IF NOT EXISTS idx_pools_dex    ON pools(dexKey);

    CREATE TABLE IF NOT EXISTS assets (
      assetId          TEXT    PRIMARY KEY,
      name             TEXT    NOT NULL,
      symbol           TEXT    NOT NULL,
      decimals         INTEGER NOT NULL,
      totalSupply      REAL    NOT NULL,
      circulatingSupply REAL   NOT NULL,
      updatedAt        INTEGER NOT NULL
    );
    CREATE INDEX IF NOT EXISTS idx_assets_symbol ON assets(symbol);
    CREATE INDEX IF NOT EXISTS idx_assets_name   ON assets(name);
  `);
}

async function fetchSupplyData(symbol, contract, retries = 2) {
  for (let attempt = 0; attempt <= retries; attempt++) {
    try {
      const response = await axios.post(SUPPLY_API, { code: contract, symbol });
      const stats = response.data[symbol];
      if (!stats || !stats.supply || !stats.max_supply) return { supply: null, max: null };
      const parseAmt = qty => parseFloat(qty.split(' ')[0]);
      return { supply: parseAmt(stats.supply), max: parseAmt(stats.max_supply) };
    } catch (err) {
      if (attempt < retries) await new Promise(r => setTimeout(r, 500));
      else return { supply: null, max: null };
    }
  }
}

async function fetchAllPools() {
  let rows = [], lower_bound = '', more = true;
  while (more) {
    const { data } = await axios.post(TABLE_API, {
      json: true, code: DEX_CONTRACT, scope: DEX_CONTRACT,
      table: 'pools', limit: 1000, lower_bound, reverse: false, show_payer: false
    });
    rows.push(...(data.rows || []));
    more = data.more;
    lower_bound = data.next_key;
  }
  return rows;
}

async function syncPools() {
  const poolsDb  = await openDatabase(POOLS_DB_PATH);
  const assetsDb = await openDatabase(ASSETS_DB_PATH);
  await ensureTables(poolsDb);
  await ensureTables(assetsDb);

  const pools = await fetchAllPools();
  console.log(`[syncPoolsJob] Loaded ${pools.length} pools.`);

  const seen = new Set(); let assetCount = 0;
  for (const pool of pools) {
    const tokenA = parseTokenQuantity(pool.tokenA?.quantity, pool.tokenA?.contract);
    const tokenB = parseTokenQuantity(pool.tokenB?.quantity, pool.tokenB?.contract);
    if (!tokenA.symbol || !tokenB.symbol) continue;

    const poolId   = pool.id;
    const dexKey   = DEX_CONTRACT;
    const asset0Id = `${tokenA.symbol}@${tokenA.contract}`;
    const asset1Id = `${tokenB.symbol}@${tokenB.contract}`;
    const feeBps   = Math.floor(pool.fee / 100);

    await poolsDb.run(
      `REPLACE INTO pools (poolId,dexKey,asset0Id,asset1Id,feeBps) VALUES (?,?,?,?,?)`,
      [poolId,dexKey,asset0Id,asset1Id,feeBps]
    );

    for (const tk of [tokenA, tokenB]) {
      const assetId = `${tk.symbol}@${tk.contract}`;
      if (seen.has(assetId)) continue;
      seen.add(assetId);
      const { supply, max } = await fetchSupplyData(tk.symbol, tk.contract);
      if (supply != null && max != null) {
        await assetsDb.run(
          `REPLACE INTO assets (assetId,name,symbol,decimals,totalSupply,circulatingSupply,updatedAt)
           VALUES (?,?,?,?,?,?,strftime('%s','now'))`,
          [assetId, tk.symbol, tk.symbol, tk.decimals, max, supply]
        );
        assetCount++;
      }
    }
  }

  console.log(`[syncPoolsJob] Synced ${pools.length} pools, ${assetCount} assets.`);
  await poolsDb.close();
  await assetsDb.close();
}

syncPools().catch(err => console.error(err));
