// ~/backend/wax-gecko-adapter/jobs/cleanupWorker.js

import { open } from "sqlite";
import sqlite3 from "sqlite3";
import fs from "fs/promises";

const DB_PATH = "/mnt/gecko-data/gecko.db";
// 4 GiB in bytes:
const MAX_DB_BYTES = 4 * 1024 * 1024 * 1024;
// How many rows to delete in each pass
const BATCH_SIZE = 10_000;
// Interval for re-checking (milliseconds). Here: once per hour.
const CHECK_INTERVAL = 1000 * 60 * 60;

async function openDatabase() {
  return open({ filename: DB_PATH, driver: sqlite3.Database });
}

async function fileSizeBytes() {
  try {
    const stat = await fs.stat(DB_PATH);
    return stat.size;
  } catch (err) {
    console.error("[cleanupWorker] Cannot stat DB file:", err.message);
    return 0;
  }
}

function humanReadable(bytes) {
  if (bytes < 1024) return bytes + " B";
  const units = ["KiB", "MiB", "GiB", "TiB"];
  let i = -1;
  let num = bytes;
  do {
    num /= 1024;
    i++;
  } while (num >= 1024 && i < units.length - 1);
  return `${num.toFixed(2)} ${units[i]}`;
}

async function deleteOldestBatch(db) {
  // Delete oldest BATCH_SIZE rows by `id`.
  const res = await db.run(
    `
    DELETE FROM events
    WHERE id IN (
      SELECT id
      FROM events
      ORDER BY id ASC
      LIMIT ?
    )
    `,
    BATCH_SIZE
  );
  return res.changes || 0;
}

async function checkAndClean() {
  try {
    console.log("------------------------------------------------------------");
    console.log("[cleanupWorker] Starting cleanup check...");
    const sizeBefore = await fileSizeBytes();
    console.log(
      `[cleanupWorker] Current DB size: ${humanReadable(sizeBefore)}`
    );
    if (sizeBefore < MAX_DB_BYTES) {
      console.log(
        `[cleanupWorker] DB size is below threshold (${humanReadable(
          MAX_DB_BYTES
        )}). No deletion needed.`
      );
      return;
    }

    console.log(
      `[cleanupWorker] DB size ${humanReadable(sizeBefore)} ≥ threshold ${humanReadable(
        MAX_DB_BYTES
      )}. Proceeding to delete oldest ${BATCH_SIZE.toLocaleString()} rows…`
    );

    const db = await openDatabase();
    await db.exec("BEGIN");
    const deleted = await deleteOldestBatch(db);
    await db.exec("COMMIT");
    await db.close();

    if (deleted > 0) {
      console.log(
        `[cleanupWorker] Deleted ${deleted.toLocaleString()} rows from events.`
      );
    } else {
      console.log("[cleanupWorker] No rows deleted (table may already be empty).");
    }

    // Check size again (quick stat) to see how much free pages were reclaimed logically
    const sizeAfter = await fileSizeBytes();
    console.log(
      `[cleanupWorker] Size after deletion (free pages not reclaimed on disk): ${humanReadable(
        sizeAfter
      )}`
    );
    console.log(
      "[cleanupWorker] Note: SQLite will reuse freed pages for future inserts without VACUUM."
    );
  } catch (err) {
    console.error("[cleanupWorker] Error during cleanup:", err.message);
  }
}

(async () => {
  console.log("✅ cleanupWorker: checking DB size every hour.");
  // Run immediately once:
  await checkAndClean();
  // Then every CHECK_INTERVAL:
  setInterval(checkAndClean, CHECK_INTERVAL);
})();
