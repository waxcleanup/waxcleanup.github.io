#!/usr/bin/env bash
# clearDatabase.sh
# Script to clear the gecko.db database for a fresh backfill

DB_PATH="/mnt/gecko-data/gecko.db"

# Check if DB exists
if [ -f "$DB_PATH" ]; then
  echo "Deleting existing database at $DB_PATH"
  rm "$DB_PATH"
  echo "Database cleared. A new empty one will be created on next worker run."
else
  echo "No database file found at $DB_PATH. Nothing to clear."
fi
