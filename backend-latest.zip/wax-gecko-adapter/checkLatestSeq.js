// Quick script to query the latest global_sequence manually from the API

import fetch from 'node-fetch';

const HISTORY_API = 'https://wax.eosusa.io/v2/history/get_actions';
const ACCOUNT     = 'swap.alcor';
const LIMIT       = 1;

(async () => {
  try {
    const url = new URL(HISTORY_API);
    url.searchParams.set('account', ACCOUNT);
    url.searchParams.set('limit', String(LIMIT));
    url.searchParams.set('sort', 'desc');

    const res = await fetch(url.toString());
    if (!res.ok) throw new Error(`HTTP ${res.status}`);

    const json = await res.json();
    const top = json.actions?.[0];

    if (top) {
      console.log(`Latest global_sequence: ${top.global_sequence}`);
      console.log(`Action type: ${top.act.name} @ block ${top.block_num}`);
    } else {
      console.log('No actions returned.');
    }
  } catch (err) {
    console.error('Error:', err);
  }
})();
