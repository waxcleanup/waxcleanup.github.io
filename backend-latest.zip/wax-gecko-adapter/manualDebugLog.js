// Add a manual comparison log to see where sync is vs. current

import sqlite3 from 'sqlite3';
import { open } from 'sqlite';

(async () => {
  const db = await open({
    filename: '/mnt/gecko-data/gecko.db',
    driver: sqlite3.Database,
  });

  const row = await db.get('SELECT MAX(global_sequence) AS seq FROM events');
  console.log(`[db] Current max global_sequence in DB: ${row?.seq}`);
})();
