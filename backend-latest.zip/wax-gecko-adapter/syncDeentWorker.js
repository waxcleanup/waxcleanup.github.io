// ~/backend/wax-gecko-adapter/syncDeentWorker.js
// ──────────────────────────────────────────────────────────────────────────────
// Copies new rows from `events` → `deent` every 1.2 seconds,
// but first reads MAX(blockNumber) from `events` to know the sync range.

import sqlite3 from 'sqlite3';
import { open } from 'sqlite';

async function ensureTables() {
  const db = await open({
    filename: '/mnt/gecko-data/gecko.db',
    driver: sqlite3.Database
  });

  await db.exec(`
    PRAGMA foreign_keys = OFF;
    BEGIN TRANSACTION;

    CREATE TABLE IF NOT EXISTS deent (
      id               INTEGER PRIMARY KEY AUTOINCREMENT,
      blockNumber      INTEGER NOT NULL,
      blockTimestamp   INTEGER NOT NULL,
      txnId            TEXT    NOT NULL,
      txnIndex         INTEGER NOT NULL,
      eventIndex       INTEGER NOT NULL,
      eventType        TEXT    NOT NULL,
      pairId           TEXT    NOT NULL,
      maker            TEXT    NOT NULL,
      asset0In         TEXT,
      asset1In         TEXT,
      asset0Out        TEXT,
      asset1Out        TEXT,
      priceNative      TEXT,
      reserve0         TEXT,
      reserve1         TEXT,
      amount0          TEXT,
      amount1          TEXT,
      UNIQUE(blockNumber, txnIndex, eventIndex)
    );

    CREATE TABLE IF NOT EXISTS sync_meta (
      key   TEXT PRIMARY KEY,
      value TEXT
    );
    INSERT OR IGNORE INTO sync_meta (key, value) VALUES ('lastSyncedBlock','0');

    COMMIT;
  `);

  await db.close();
}

async function syncToDeent() {
  const db = await open({
    filename: '/mnt/gecko-data/gecko.db',
    driver: sqlite3.Database
  });

  // 1) Read lastSyncedBlock from sync_meta
  const row = await db.get(`SELECT value FROM sync_meta WHERE key = 'lastSyncedBlock'`);
  let lastSyncedBlock = parseInt(row?.value || '0', 10);

  // 2) Find the maximum blockNumber currently in `events`
  const maxRow = await db.get(`SELECT MAX(blockNumber) AS maxBlock FROM events`);
  const latestInEvents = parseInt(maxRow?.maxBlock || '0', 10);

  // If nothing new, bail out
  if (latestInEvents <= lastSyncedBlock) {
    console.log(`[syncDeent] No new blocks: lastSyncedBlock=${lastSyncedBlock}, latestInEvents=${latestInEvents}`);
    await db.close();
    return;
  }

  console.log(`[syncDeent] Syncing range ${lastSyncedBlock + 1} → ${latestInEvents}`);

  // 3) Select only events where blockNumber is in (lastSyncedBlock+1 … latestInEvents)
  const newEvents = await db.all(
    `SELECT
       blockNumber,
       blockTimestamp,
       txnId,
       txnIndex,
       eventIndex,
       eventType,
       pairId,
       maker,
       asset0In,
       asset1In,
       asset0Out,
       asset1Out,
       priceNative,
       reserve0,
       reserve1,
       amount0,
       amount1
     FROM events
     WHERE blockNumber BETWEEN ? AND ?
     ORDER BY blockNumber ASC, txnIndex ASC, eventIndex ASC`,
    lastSyncedBlock + 1,
    latestInEvents
  );

  // 4) Bulk insert them into `deent`, then update lastSyncedBlock = latestInEvents
  await db.exec('BEGIN TRANSACTION;');
  for (const ev of newEvents) {
    await db.run(
      `INSERT OR IGNORE INTO deent (
         blockNumber, blockTimestamp, txnId, txnIndex, eventIndex,
         eventType, pairId, maker,
         asset0In, asset1In, asset0Out, asset1Out, priceNative,
         reserve0, reserve1, amount0, amount1
       ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      ev.blockNumber,
      ev.blockTimestamp,
      ev.txnId,
      ev.txnIndex,
      ev.eventIndex,
      ev.eventType,
      ev.pairId,
      ev.maker,
      ev.asset0In,
      ev.asset1In,
      ev.asset0Out,
      ev.asset1Out,
      ev.priceNative,
      ev.reserve0,
      ev.reserve1,
      ev.amount0,
      ev.amount1
    );
  }
  await db.run(
    `UPDATE sync_meta SET value = ? WHERE key = 'lastSyncedBlock'`,
    latestInEvents.toString()
  );
  await db.exec('COMMIT;');

  console.log(`[syncDeent] Synced up to block ${latestInEvents}`);
  await db.close();
}

(async () => {
  await ensureTables();

  // Run once immediately
  await syncToDeent();

  // Then every 1.2 seconds
  setInterval(() => {
    syncToDeent().catch(err => {
      console.error('[syncDeent] Error in sync loop:', err);
    });
  }, 1200);

  console.log('✅ syncDeentWorker: sync loop started (every 1.2 seconds).');
})();
