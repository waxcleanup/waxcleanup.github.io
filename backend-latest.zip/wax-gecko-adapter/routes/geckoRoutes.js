// backend/geckoRoutes.js

import express  from "express";
import sqlite3  from "sqlite3";
import { open } from "sqlite";
import path     from "path";

const router    = express.Router();
const BASE_DIR  = "/mnt/gecko-data";
const EVENTS_DB = path.join(BASE_DIR, "gecko.db");
const POOLS_DB  = path.join(BASE_DIR, "alcorpools.db");
const ASSETS_DB = path.join(BASE_DIR, "assets.db");

// ─── Connection & Schema Init ────────────────────────────────────────
const dbCache = {};

async function openDatabase(file) {
  if (dbCache[file]) return dbCache[file];

  const db = await open({
    filename: file,
    driver:   sqlite3.Database,
    mode:     sqlite3.OPEN_READWRITE | sqlite3.OPEN_CREATE
  });

  await db.exec("PRAGMA journal_mode = WAL;");
  await db.exec("PRAGMA busy_timeout = 5000;");

  if (file === EVENTS_DB) {
    await db.exec(`ATTACH DATABASE '${POOLS_DB}' AS poolsdb;`);
    await db.exec(`CREATE INDEX IF NOT EXISTS idx_events_block ON events(blockNumber);`);
    await db.exec(`CREATE INDEX IF NOT EXISTS idx_events_pair  ON events(pairId);`);
  }

  dbCache[file] = db;
  return db;
}

function asString(val) {
  return val != null ? String(val) : null;
}

// ─── /latest-block ────────────────────────────────────────────────────
router.get("/latest-block", async (req, res) => {
  try {
    const db = await openDatabase(EVENTS_DB);
    const row = await db.get(
      `
      SELECT
        MAX(e.blockNumber)    AS blockNumber,
        MAX(e.blockTimestamp) AS blockTimestamp
      FROM events e
      JOIN poolsdb.pools p
        ON e.pairId = p.poolId
      WHERE p.asset0Id = 'WAX@eosio.token'
         OR p.asset1Id = 'WAX@eosio.token'
      `
    );
    res.json({
      block: {
        blockNumber:   row?.blockNumber   || 0,
        blockTimestamp: row?.blockTimestamp || 0,
      }
    });
  } catch (err) {
    console.error("[GET /latest-block] Error:", err.message);
    res.status(500).json({ error: "Failed to fetch latest WAX block" });
  }
});

// ─── /asset?id=… ──────────────────────────────────────────────────────
router.get("/asset", async (req, res) => {
  const id = req.query.id;
  if (!id) return res.status(400).json({ error: "Missing asset id" });

  try {
    const db    = await openDatabase(ASSETS_DB);
    const asset = await db.get(
      `
      SELECT
        assetId           AS id,
        name,
        symbol,
        decimals,
        totalSupply,
        circulatingSupply
      FROM assets
      WHERE assetId = ?
      `,
      id
    );

    if (!asset) return res.status(404).json({ error: "Asset not found" });

    // wrap in { asset: … } per spec
    res.json({
      asset: {
        id:               asset.id,
        name:             asset.name,
        symbol:           asset.symbol,
        decimals:         asset.decimals,
        totalSupply:      asset.totalSupply,
        circulatingSupply: asset.circulatingSupply,
        coinGeckoId:      null,
        metadata:         {}
      }
    });
  } catch (err) {
    console.error("[GET /asset] Error:", err.message);
    res.status(500).json({ error: "Failed to fetch asset" });
  }
});

// ─── /pair?id=… ───────────────────────────────────────────────────────
router.get("/pair", async (req, res) => {
  const id = req.query.id;
  if (!id) return res.status(400).json({ error: "Missing pair id" });

  try {
    const db   = await openDatabase(POOLS_DB);
    const pool = await db.get(`
      SELECT
        poolId   AS id,
        dexKey,
        asset0Id,
        asset1Id,
        feeBps
      FROM pools
      WHERE poolId = ?
    `, id);

    if (!pool) return res.status(404).json({ error: "Pair not found" });

    res.json({
      pair: {
        id:       asString(pool.id),
        dexKey:   pool.dexKey,
        asset0Id: pool.asset0Id,
        asset1Id: pool.asset1Id,
        feeBps:   pool.feeBps,
        metadata: {}
      }
    });
  } catch (err) {
    console.error("[GET /pair] Error:", err.message);
    res.status(500).json({ error: "Failed to fetch pair" });
  }
});

// ─── /events?fromBlock=…&toBlock=…[&limit=…] ─────────────────────────────
router.get("/events", async (req, res) => {
  const db = await openDatabase(EVENTS_DB);
  const { blockNumber: latestBlock } =
    (await db.get(`SELECT MAX(blockNumber) AS blockNumber FROM events`)) || { blockNumber: 0 };

  let { fromBlock, toBlock, limit = "100" } = req.query;
  if (!fromBlock && !toBlock) {
    toBlock   = String(latestBlock);
    fromBlock = String(Math.max(0, latestBlock - 1000));
  }

  const fb = parseInt(fromBlock, 10);
  const tb = parseInt(toBlock,   10);
  if (isNaN(fb) || isNaN(tb)) {
    return res.status(400).json({ error: "fromBlock/toBlock must be integers" });
  }
  if (tb - fb > 10_000) {
    return res.status(400).json({ error: "Block range too large: max span is 10000 blocks" });
  }
  const L = Math.min(Math.max(parseInt(limit, 10) || 1, 1), 1000);

  try {
    const rows = await db.all(
      `
      SELECT
        e.blockNumber, e.blockTimestamp,
        e.txnId, e.txnIndex, e.eventIndex,
        e.eventType, e.maker, e.pairId,
        e.reserve0, e.reserve1,
        e.asset0In, e.asset1In,
        e.asset0Out, e.asset1Out,
        e.priceNative, e.amount0, e.amount1
      FROM events e
      JOIN poolsdb.pools p
        ON e.pairId = p.poolId
      WHERE e.blockNumber BETWEEN ? AND ?
        AND (p.asset0Id = 'WAX@eosio.token' OR p.asset1Id = 'WAX@eosio.token')
      ORDER BY e.blockNumber DESC, e.eventIndex ASC
      LIMIT ?
      `,
      fb, tb, L
    );

    const events = rows.map(r => {
      const base = {
        block: {
          blockNumber:   r.blockNumber,
          blockTimestamp: r.blockTimestamp,
        },
        eventType:  r.eventType,
        txnId:      r.txnId,
        txnIndex:   r.txnIndex,
        eventIndex: r.eventIndex,
        maker:      r.maker,
        pairId:     String(r.pairId),
      };

      if (r.eventType === "swap") {
        return {
          ...base,
          asset0In:    r.asset0In   || null,
          asset1In:    r.asset1In   || null,
          asset0Out:   r.asset0Out  || null,
          asset1Out:   r.asset1Out  || null,
          priceNative: r.priceNative|| null,
          reserves: {
            asset0: r.reserve0 || "0",
            asset1: r.reserve1 || "0",
          },
          metadata: {},
        };
      }

      // <— only this join/exit block changed:
      return {
        ...base,
        amount0: r.amount0 != null ? r.amount0 : "0",
        amount1: r.amount1 != null ? r.amount1 : "0",
        reserves: {
          asset0: r.reserve0 || "0",
          asset1: r.reserve1 || "0",
        },
        metadata: {},
      };
    });

    console.log(`[GET /events] returning ${events.length}/${L} events from ${fb}–${tb}`);
    res.json({ events });
  } catch (err) {
    console.error("[GET /events] Error:", err.message);
    res.status(500).json({ error: "Failed to fetch WAX@eosio.token events." });
  }
});

export default router;
