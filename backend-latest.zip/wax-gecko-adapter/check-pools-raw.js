// wax-gecko-adapter/check-pools-raw.js
import dotenv from "dotenv";
dotenv.config();

import mongoose from "mongoose";

(async () => {
  const uri = process.env.MONGODB_URI;
  console.log("📋 MONGODB_URI =", uri);

  if (!uri) {
    console.error("❌  No MONGODB_URI found in .env. Exiting.");
    process.exit(1);
  }

  try {
    // connect to Atlas
    await mongoose.connect(uri);
    console.log("🔗  Connected to MongoDB");

    const db = mongoose.connection.db;
    // directly ask for the “pools” collection (not using any model)
    const count = await db.collection("pools").countDocuments();
    console.log("🔢  Raw count of 'pools' documents:", count);
  } catch (e) {
    console.error("❌  Error while counting raw 'pools':", e.message);
  } finally {
    mongoose.connection.close();
  }
})();
